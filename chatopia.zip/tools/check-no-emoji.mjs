// tools/check-no-emoji.mjs
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const pictographic = new RegExp('\\p{Extended_Pictographic}', 'u');
const emoji = new RegExp('\\p{Emoji}', 'u');
const excluded = new Set([
  '.git', 'node_modules', 'vendor', 'dist', 'build', 'coverage', '.cache'
]);
const binaryExtensions = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.avif', '.ico', '.bmp',
  '.tif', '.tiff', '.wav', '.mp3', '.ogg', '.mp4', '.webm', '.woff',
  '.woff2', '.ttf', '.otf', '.jar', '.class', '.zip', '.gz', '.pdf', '.bin'
]);

function prohibited(symbol) {
  const cp = symbol.codePointAt(0);
  if (pictographic.test(symbol)) return true;
  if (emoji.test(symbol) && !/^[0-9#*]$/.test(symbol)) return true;
  return cp === 0xFE0E || cp === 0xFE0F || cp === 0x20E3
    || (cp >= 0x1F1E6 && cp <= 0x1F1FF)
    || (cp >= 0x1F3FB && cp <= 0x1F3FF)
    || (cp >= 0xE0020 && cp <= 0xE007F);
}

function fromHex(hex, original) {
  const cp = Number.parseInt(hex, 16);
  return cp >= 0 && cp <= 0x10FFFF
    ? String.fromCodePoint(cp) : original;
}

function decode(text) {
  let result = text.replace(
    /\\u\{([0-9a-f]{1,6})\}|\\u([0-9a-f]{4})|\\U([0-9a-f]{8})/gi,
    (all, a, b, c) => fromHex(a || b || c, all)
  );
  result = result.replace(/&#(?:x([0-9a-f]+)|([0-9]+));/gi,
    (all, hex, decimal) => {
      const cp = Number.parseInt(hex || decimal, hex ? 16 : 10);
      return cp >= 0 && cp <= 0x10FFFF ? String.fromCodePoint(cp) : all;
    });
  result = result.replace(/\\([0-9a-f]{1,6})(?:\s)?/gi,
    (all, hex) => fromHex(hex, all));
  return result.replace(/(?:%[0-9a-f]{2})+/gi, all => {
    try { return decodeURIComponent(all); }
    catch { return all; }
  });
}

function firstViolation(text) {
  for (const symbol of text) {
    if (prohibited(symbol)) return symbol.codePointAt(0);
  }
  return null;
}

function safeLabel(text) {
  let result = '';
  for (const symbol of text) {
    result += prohibited(symbol)
      ? '[U+' + symbol.codePointAt(0).toString(16).toUpperCase() + ']'
      : symbol;
  }
  return result;
}

function walk(target, result) {
  const stat = fs.lstatSync(target);
  if (stat.isSymbolicLink()) return;
  if (stat.isDirectory()) {
    for (const entry of fs.readdirSync(target)) {
      if (!excluded.has(entry)) walk(path.join(target, entry), result);
    }
  } else if (stat.isFile()) {
    result.add(path.resolve(target));
  }
}

function collect() {
  const result = new Set();
  const explicit = process.argv.slice(2);
  if (explicit.length > 0) {
    for (const target of explicit) walk(path.resolve(target), result);
    return result;
  }
  let root;
  let listing;
  try {
    root = execFileSync('git', ['rev-parse', '--show-toplevel'],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    listing = execFileSync('git', ['-C', root, 'ls-files', '-co',
      '--exclude-standard', '-z'], { encoding: 'utf8' });
  } catch {
    walk(process.cwd(), result);
    return result;
  }
  for (const file of listing.split('\0')) {
    if (!file || file.split('/').some(part => excluded.has(part))) continue;
    const full = path.resolve(root, file);
    if (fs.existsSync(full) && fs.lstatSync(full).isFile()) result.add(full);
  }
  return result;
}

let failures = 0;
try {
  for (const file of collect()) {
    const label = path.relative(process.cwd(), file);
    let cp = firstViolation(label);
    const bytes = fs.readFileSync(file);
    if (cp === null && !binaryExtensions.has(path.extname(file).toLowerCase())
      && !bytes.includes(0)) {
      let view = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      for (let pass = 0; pass < 4 && cp === null; pass++) {
        cp = firstViolation(view);
        if (cp !== null) break;
        const next = decode(view);
        if (next === view) break;
        view = next;
      }
    }
    if (cp !== null) {
      failures++;
      process.stderr.write(safeLabel(label) + ': prohibited U+'
        + cp.toString(16).toUpperCase() + '\n');
    }
  }
  if (failures > 0) process.exitCode = 1;
  else process.stdout.write('No prohibited symbols found.\n');
} catch (error) {
  process.stderr.write('Scan failed: ' + safeLabel(String(error)) + '\n');
  process.exitCode = 2;
}
