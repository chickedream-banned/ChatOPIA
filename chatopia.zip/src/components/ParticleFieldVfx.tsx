import React, { useEffect, useRef } from 'react';

interface ParticleFieldVfxProps {
  scrollProgressRef: React.MutableRefObject<number>;
}

const LETTERS = ['C', 'H', 'A', 'T', 'O', 'P', 'I', 'A'] as const;
const AMBIENT_COUNT = 52;
const BURST_CAPACITY = 36;
const SPRITE_SIZE = 96;

class ChatopiaLetterVfxSystem {
  private readonly ctx: CanvasRenderingContext2D;
  private readonly events = new AbortController();
  private readonly observer: ResizeObserver;
  private disposed = false;
  private suspended = false;
  private raf: number | null = null;
  private lastTime: number | null = null;
  private width = 1;
  private height = 1;
  private dpr = 1;
  private pointerX = -1000;
  private pointerY = -1000;
  private lastScroll = 0;
  private scrollVelocity = 0;

  // Pre-rendered glowing glyph canvases for fast zero-allocation drawing
  private readonly whiteGlyphs: HTMLCanvasElement[] = [];
  private readonly goldGlyphs: HTMLCanvasElement[] = [];

  // Ambient floating letter state
  private readonly x = new Float32Array(AMBIENT_COUNT);
  private readonly y = new Float32Array(AMBIENT_COUNT);
  private readonly vx = new Float32Array(AMBIENT_COUNT);
  private readonly vy = new Float32Array(AMBIENT_COUNT);
  private readonly size = new Float32Array(AMBIENT_COUNT);
  private readonly alpha = new Float32Array(AMBIENT_COUNT);
  private readonly phase = new Float32Array(AMBIENT_COUNT);
  private readonly rot = new Float32Array(AMBIENT_COUNT);
  private readonly vrot = new Float32Array(AMBIENT_COUNT);
  private readonly depth = new Float32Array(AMBIENT_COUNT);
  private readonly letterIdx = new Uint8Array(AMBIENT_COUNT);
  private readonly isGold = new Uint8Array(AMBIENT_COUNT);

  // Click / interaction burst letter pool
  private readonly bx = new Float32Array(BURST_CAPACITY);
  private readonly by = new Float32Array(BURST_CAPACITY);
  private readonly bvx = new Float32Array(BURST_CAPACITY);
  private readonly bvy = new Float32Array(BURST_CAPACITY);
  private readonly blife = new Float32Array(BURST_CAPACITY);
  private readonly bmax = new Float32Array(BURST_CAPACITY);
  private readonly bsize = new Float32Array(BURST_CAPACITY);
  private readonly brot = new Float32Array(BURST_CAPACITY);
  private readonly bvrot = new Float32Array(BURST_CAPACITY);
  private readonly bletter = new Uint8Array(BURST_CAPACITY);
  private readonly bgold = new Uint8Array(BURST_CAPACITY);

  constructor(
    private readonly canvas: HTMLCanvasElement,
    private readonly scrollProgressRef: React.MutableRefObject<number>
  ) {
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) {
      throw new Error('Canvas 2D context unavailable');
    }
    this.ctx = ctx;
    this.observer = new ResizeObserver(this.resize);

    this.initGlyphCanvases();
    this.bakeGlyphs();

    // Re-bake once OldRobloxFont is guaranteed loaded
    if (typeof document !== 'undefined' && 'fonts' in document) {
      document.fonts
        .load("48px 'OldRobloxFont'")
        .then(() => {
          if (!this.disposed) this.bakeGlyphs();
        })
        .catch(() => {
          // Ignore font load promise rejection
        });
    }

    const sig = { signal: this.events.signal };
    window.addEventListener('resize', this.resize, sig);
    window.addEventListener('pointermove', this.onPointerMove, {
      ...sig,
      passive: true,
    });
    window.addEventListener('pointerdown', this.onPointerDown, {
      ...sig,
      passive: true,
    });
    window.addEventListener('pagehide', this.onPageHide, sig);
    window.addEventListener('pageshow', this.onPageShow, sig);
    document.addEventListener('visibilitychange', this.syncLoop, sig);

    this.resize();
    this.seedAmbient();
    this.syncLoop();
  }

  private initGlyphCanvases(): void {
    for (let i = 0; i < LETTERS.length; i++) {
      const wc = document.createElement('canvas');
      wc.width = SPRITE_SIZE;
      wc.height = SPRITE_SIZE;
      this.whiteGlyphs.push(wc);

      const gc = document.createElement('canvas');
      gc.width = SPRITE_SIZE;
      gc.height = SPRITE_SIZE;
      this.goldGlyphs.push(gc);
    }
  }

  private bakeGlyphs(): void {
    const half = SPRITE_SIZE / 2;
    for (let i = 0; i < LETTERS.length; i++) {
      const char = LETTERS[i]!;

      // 1. Silver-White Glowing Letter Sprite
      const wCanvas = this.whiteGlyphs[i]!;
      const wCtx = wCanvas.getContext('2d');
      if (wCtx) {
        wCtx.clearRect(0, 0, SPRITE_SIZE, SPRITE_SIZE);
        wCtx.font = "44px 'OldRobloxFont', sans-serif";
        wCtx.textAlign = 'center';
        wCtx.textBaseline = 'middle';

        // Soft wide outer bloom
        wCtx.save();
        wCtx.shadowColor = 'rgba(255, 255, 255, 0.92)';
        wCtx.shadowBlur = 18;
        wCtx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        wCtx.fillText(char, half, half);
        wCtx.restore();

        // Tight inner glow + crisp glyph core
        wCtx.save();
        wCtx.shadowColor = 'rgba(220, 235, 255, 0.95)';
        wCtx.shadowBlur = 8;
        wCtx.fillStyle = '#ffffff';
        wCtx.fillText(char, half, half);
        wCtx.restore();
      }

      // 2. Golden Glowing Letter Sprite
      const gCanvas = this.goldGlyphs[i]!;
      const gCtx = gCanvas.getContext('2d');
      if (gCtx) {
        gCtx.clearRect(0, 0, SPRITE_SIZE, SPRITE_SIZE);
        gCtx.font = "44px 'OldRobloxFont', sans-serif";
        gCtx.textAlign = 'center';
        gCtx.textBaseline = 'middle';

        // Wide golden bloom
        gCtx.save();
        gCtx.shadowColor = 'rgba(250, 204, 21, 0.95)';
        gCtx.shadowBlur = 20;
        gCtx.fillStyle = '#fde047';
        gCtx.fillText(char, half, half);
        gCtx.restore();

        // Crisp bright gold core
        gCtx.save();
        gCtx.shadowColor = 'rgba(254, 240, 138, 0.95)';
        gCtx.shadowBlur = 8;
        gCtx.fillStyle = '#fef08a';
        gCtx.fillText(char, half, half);
        gCtx.restore();
      }
    }
  }

  private seedAmbient(): void {
    const w = Math.max(320, this.width);
    const h = Math.max(320, this.height);
    for (let i = 0; i < AMBIENT_COUNT; i++) {
      this.x[i] = Math.random() * w;
      this.y[i] = Math.random() * h;
      const depth = 0.45 + Math.random() * 0.85; // parallax layer
      this.depth[i] = depth;
      this.vx[i] = (Math.random() - 0.5) * 16 * depth;
      this.vy[i] = (-12 - Math.random() * 22) * depth;
      this.size[i] = (28 + Math.random() * 30) * depth;
      this.alpha[i] = 0.22 + Math.random() * 0.48;
      this.phase[i] = Math.random() * Math.PI * 2;
      this.rot[i] = (Math.random() - 0.5) * 0.55;
      this.vrot[i] = (Math.random() - 0.5) * 0.45;
      this.letterIdx[i] = i % LETTERS.length;
      this.isGold[i] = i % 6 === 0 ? 1 : 0;
    }
  }

  private spawnBurst(x: number, y: number): void {
    // Spawn all 8 letters C-H-A-T-O-P-I-A in a glowing radial burst on click
    let spawned = 0;
    for (let i = 0; i < BURST_CAPACITY && spawned < LETTERS.length; i++) {
      if (this.blife[i]! > 0) continue;
      const angle =
        (Math.PI * 2 * spawned) / LETTERS.length + (Math.random() - 0.5) * 0.25;
      const speed = 65 + Math.random() * 115;
      this.bx[i] = x;
      this.by[i] = y;
      this.bvx[i] = Math.cos(angle) * speed;
      this.bvy[i] = Math.sin(angle) * speed - 35;
      this.bmax[i] = 0.75 + Math.random() * 0.35;
      this.blife[i] = this.bmax[i]!;
      this.bsize[i] = 34 + Math.random() * 18;
      this.brot[i] = (Math.random() - 0.5) * 0.4;
      this.bvrot[i] = (Math.random() - 0.5) * 2.2;
      this.bletter[i] = spawned % LETTERS.length;
      this.bgold[i] = spawned % 2 === 0 ? 1 : 0;
      spawned++;
    }
  }

  private onPointerMove = (e: PointerEvent): void => {
    this.pointerX = e.clientX;
    this.pointerY = e.clientY;
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (this.isPaused()) return;
    this.spawnBurst(e.clientX, e.clientY);
  };

  private onPageHide = (): void => {
    this.suspended = true;
    this.syncLoop();
  };

  private onPageShow = (): void => {
    this.suspended = false;
    this.syncLoop();
  };

  private isPaused(): boolean {
    return this.disposed || this.suspended || document.hidden;
  }

  private syncLoop = (): void => {
    if (this.isPaused()) {
      if (this.raf !== null) {
        cancelAnimationFrame(this.raf);
        this.raf = null;
      }
      this.lastTime = null;
    } else if (this.raf === null) {
      this.lastTime = null;
      this.raf = requestAnimationFrame(this.frame);
    }
  };

  private resize = (): void => {
    if (this.disposed) return;
    const w = Math.max(1, window.innerWidth);
    const h = Math.max(1, window.innerHeight);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.width = w;
    this.height = h;
    this.dpr = dpr;
    const targetW = Math.round(w * dpr);
    const targetH = Math.round(h * dpr);
    if (this.canvas.width !== targetW) this.canvas.width = targetW;
    if (this.canvas.height !== targetH) this.canvas.height = targetH;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  private frame = (now: number): void => {
    this.raf = null;
    if (this.isPaused()) return;

    const dt =
      this.lastTime === null
        ? 1 / 60
        : Math.max(0.001, Math.min((now - this.lastTime) / 1000, 0.06));
    this.lastTime = now;

    if (this.dpr !== Math.min(window.devicePixelRatio || 1, 2)) {
      this.resize();
    }

    this.update(dt);
    this.draw();

    this.raf = requestAnimationFrame(this.frame);
  };

  private update(dt: number): void {
    const currentScroll = this.scrollProgressRef.current;
    const scrollDelta = currentScroll - this.lastScroll;
    this.lastScroll = currentScroll;
    this.scrollVelocity =
      this.scrollVelocity * 0.88 + (scrollDelta / Math.max(dt, 0.008)) * 210;

    const w = this.width;
    const h = this.height;
    const px = this.pointerX;
    const py = this.pointerY;

    for (let i = 0; i < AMBIENT_COUNT; i++) {
      this.phase[i] = this.phase[i]! + dt * 1.9;
      this.rot[i] =
        Math.sin(this.phase[i]! * 0.65) * 0.28 + this.vrot[i]! * 0.15;

      const depth = this.depth[i]!;
      let x =
        this.x[i]! +
        this.vx[i]! * dt +
        Math.sin(this.phase[i]!) * 10 * depth * dt;
      let y =
        this.y[i]! + (this.vy[i]! - this.scrollVelocity * (0.45 * depth)) * dt;

      // Smooth cursor repulsion + glow interaction
      const dx = x - px;
      const dy = y - py;
      const distSq = dx * dx + dy * dy;
      if (distSq > 1 && distSq < 145 * 145) {
        const dist = Math.sqrt(distSq);
        const force = (1 - dist / 145) * 110 * dt;
        x += (dx / dist) * force;
        y += (dy / dist) * force;
      }

      if (x < -40) x = w + 40;
      else if (x > w + 40) x = -40;

      if (y < -45) {
        y = h + 40;
        x = Math.random() * w;
      } else if (y > h + 45) {
        y = -40;
        x = Math.random() * w;
      }

      this.x[i] = x;
      this.y[i] = y;
    }

    for (let i = 0; i < BURST_CAPACITY; i++) {
      const life = this.blife[i]!;
      if (life <= 0) continue;
      const next = life - dt;
      if (next <= 0) {
        this.blife[i] = 0;
        continue;
      }
      this.blife[i] = next;
      this.bvy[i] = this.bvy[i]! + 150 * dt;
      this.bx[i] = this.bx[i]! + this.bvx[i]! * dt;
      this.by[i] = this.by[i]! + this.bvy[i]! * dt;
      this.brot[i] = this.brot[i]! + this.bvrot[i]! * dt;
    }
  }

  private draw(): void {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    const px = this.pointerX;
    const py = this.pointerY;

    // 1. Draw ambient floating C, H, A, T, O, P, I, A glowing letters
    for (let i = 0; i < AMBIENT_COUNT; i++) {
      const x = this.x[i]!;
      const y = this.y[i]!;
      const s = this.size[i]!;
      const idx = this.letterIdx[i]!;

      // Boost glow alpha when near pointer
      const dx = x - px;
      const dy = y - py;
      const distSq = dx * dx + dy * dy;
      const nearBoost =
        distSq < 180 * 180 ? (1 - Math.sqrt(distSq) / 180) * 0.38 : 0;

      const pulse = 0.72 + 0.28 * Math.sin(this.phase[i]!);
      const alpha = Math.min(1, this.alpha[i]! * pulse + nearBoost);

      const sprite =
        this.isGold[i] === 1 || nearBoost > 0.18
          ? this.goldGlyphs[idx]
          : this.whiteGlyphs[idx];
      if (!sprite) continue;

      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(x, y);
      ctx.rotate(this.rot[i]!);
      ctx.drawImage(sprite, -s * 0.5, -s * 0.5, s, s);
      ctx.restore();
    }

    // 2. Draw click-burst C, H, A, T, O, P, I, A glowing letters
    for (let i = 0; i < BURST_CAPACITY; i++) {
      const life = this.blife[i]!;
      if (life <= 0) continue;
      const ratio = life / (this.bmax[i]! || 1);
      const s = this.bsize[i]! * (0.65 + 0.45 * Math.sin(ratio * Math.PI));
      const idx = this.bletter[i]!;
      const sprite =
        this.bgold[i] === 1 ? this.goldGlyphs[idx] : this.whiteGlyphs[idx];
      if (!sprite) continue;

      ctx.save();
      ctx.globalAlpha = Math.min(1, ratio * 1.15);
      ctx.translate(this.bx[i]!, this.by[i]!);
      ctx.rotate(this.brot[i]!);
      ctx.drawImage(sprite, -s * 0.5, -s * 0.5, s, s);
      ctx.restore();
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    if (this.raf !== null) {
      cancelAnimationFrame(this.raf);
      this.raf = null;
    }
    this.events.abort();
    this.observer.disconnect();
    for (let i = 0; i < this.whiteGlyphs.length; i++) {
      this.whiteGlyphs[i]!.width = 1;
      this.whiteGlyphs[i]!.height = 1;
      this.goldGlyphs[i]!.width = 1;
      this.goldGlyphs[i]!.height = 1;
    }
    this.canvas.width = 1;
    this.canvas.height = 1;
  }
}

export const ParticleFieldVfx: React.FC<ParticleFieldVfxProps> = ({
  scrollProgressRef,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    let system: ChatopiaLetterVfxSystem | null = null;
    try {
      system = new ChatopiaLetterVfxSystem(el, scrollProgressRef);
    } catch {
      return;
    }
    return () => {
      system?.dispose();
    };
  }, [scrollProgressRef]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none z-10 w-full h-full"
    />
  );
};
