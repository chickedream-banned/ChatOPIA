import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export interface CharacterViewport3DProps {
  scrollProgressRef: React.RefObject<number>;
}

const _box3 = new THREE.Box3();
const _center = new THREE.Vector3();
const _size = new THREE.Vector3();
const _dummyObj = new THREE.Object3D();

const isSoftwareGl = (() => {
  if (typeof document === 'undefined') return false;
  const gl = document.createElement('canvas').getContext('webgl2');
  if (!gl) return true;
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
  const gpu = String(gl.getParameter(param));
  gl.getExtension('WEBGL_lose_context')?.loseContext();
  return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
})();

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(128, 128, 16, 128, 128, 122);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.55)');
    grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.22)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

export function CharacterViewport3D({
  scrollProgressRef,
}: CharacterViewport3DProps) {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [contextLost, setContextLost] = useState<boolean>(false);

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    let disposed = false;
    let frameId = 0;
    const abortController = new AbortController();

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const scene = new THREE.Scene();

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);
    const camera = new THREE.PerspectiveCamera(34, width / height, 0.1, 60);
    camera.position.set(0, 1.95, 5.05);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      setContextLost(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    renderer.setSize(width, height, false);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const canvas = renderer.domElement;
    canvas.className =
      'w-full h-full block outline-none cursor-grab active:cursor-grabbing';
    canvas.tabIndex = 0;
    canvas.setAttribute('aria-label', 'ChatOPIA 3D Player');
    container.innerHTML = '';
    container.appendChild(canvas);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    pmremGenerator.dispose();

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x3f3f46, 1.25);
    hemiLight.position.set(0, 8, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 2.05);
    keyLight.position.set(3.4, 5.6, 4.4);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 16;
    const d = 2.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xe4e4e7, 0.9);
    fillLight.position.set(-3.8, 2.8, 2.4);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 1.15);
    rimLight.position.set(0.0, 4.0, -4.2);
    scene.add(rimLight);

    const stageRoot = new THREE.Group();
    scene.add(stageRoot);

    const disposableGeos: THREE.BufferGeometry[] = [];
    const disposableMats: THREE.Material[] = [];
    const disposableTexs: THREE.Texture[] = [];

    const shadowTex = createContactShadowTexture();
    disposableTexs.push(shadowTex);
    const shadowPlaneGeo = new THREE.PlaneGeometry(4.0, 4.0);
    disposableGeos.push(shadowPlaneGeo);
    const shadowPlaneMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.65,
    });
    disposableMats.push(shadowPlaneMat);
    const shadowPlane = new THREE.Mesh(shadowPlaneGeo, shadowPlaneMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.005;
    stageRoot.add(shadowPlane);

    const baseGeo = new THREE.CylinderGeometry(1.36, 1.48, 0.18, 48);
    disposableGeos.push(baseGeo);
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x5c5c5c,
      roughness: 0.55,
      metalness: 0.12,
    });
    disposableMats.push(baseMat);
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = 0.09;
    baseMesh.receiveShadow = !isSoftwareGl;
    baseMesh.castShadow = !isSoftwareGl;
    stageRoot.add(baseMesh);

    const studGeo = new THREE.BoxGeometry(0.22, 0.038, 0.22);
    disposableGeos.push(studGeo);
    const studMat = new THREE.MeshStandardMaterial({
      color: 0x707070,
      roughness: 0.5,
      metalness: 0.1,
    });
    disposableMats.push(studMat);

    const studCoords: Array<[number, number]> = [];
    for (let gx = -3; gx <= 3; gx++) {
      for (let gz = -3; gz <= 3; gz++) {
        const sx = gx * 0.32;
        const sz = gz * 0.32;
        if (sx * sx + sz * sz <= 1.15 * 1.15) {
          studCoords.push([sx, sz]);
        }
      }
    }

    const studsMesh = new THREE.InstancedMesh(
      studGeo,
      studMat,
      studCoords.length
    );
    studCoords.forEach(([sx, sz], i) => {
      _dummyObj.position.set(sx, 0.195, sz);
      _dummyObj.rotation.set(0, 0, 0);
      _dummyObj.scale.set(1, 1, 1);
      _dummyObj.updateMatrix();
      studsMesh.setMatrixAt(i, _dummyObj.matrix);
    });
    studsMesh.instanceMatrix.needsUpdate = true;
    studsMesh.computeBoundingSphere();
    studsMesh.receiveShadow = !isSoftwareGl;
    stageRoot.add(studsMesh);

    const controls = new OrbitControls(camera, canvas);
    controls.target.set(0, 1.36, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.enablePan = false;
    controls.enableZoom = false;
    controls.minPolarAngle = Math.PI * 0.26;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.update();

    let gltfRoot: THREE.Object3D | null = null;
    let mixer: THREE.AnimationMixer | null = null;
    let clips: THREE.AnimationClip[] = [];
    let currentClipIndex = 0;

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    const loader = new GLTFLoader();
    loader.load(
      '/ChatopianPREPRE.glb',
      (gltf) => {
        if (disposed) return;
        const model = gltf.scene;

        model.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            mesh.castShadow = !isSoftwareGl;
            mesh.receiveShadow = !isSoftwareGl;

            const mats = Array.isArray(mesh.material)
              ? mesh.material
              : [mesh.material];
            mats.forEach((m) => {
              if (
                m &&
                (m as THREE.MeshStandardMaterial).isMeshStandardMaterial
              ) {
                const std = m as THREE.MeshStandardMaterial;
                std.roughness = 0.56;
                std.metalness = 0.04;
                std.envMapIntensity = 0.45;
                if (std.map) {
                  std.map.colorSpace = THREE.SRGBColorSpace;
                  std.map.anisotropy = maxAnisotropy;
                  std.map.needsUpdate = true;
                }
                std.needsUpdate = true;
              }
            });
          }
        });

        _box3.setFromObject(model);
        _box3.getCenter(_center);
        _box3.getSize(_size);

        const maxDim = Math.max(_size.x, _size.y, _size.z, 0.001);
        const scaleFactor = 2.45 / maxDim;

        const wrapper = new THREE.Group();
        model.scale.setScalar(scaleFactor);

        _box3.setFromObject(model);
        _box3.getCenter(_center);
        model.position.x -= _center.x;
        model.position.z -= _center.z;
        model.position.y -= _box3.min.y;

        wrapper.position.set(0, 0.18, 0);
        wrapper.add(model);
        stageRoot.add(wrapper);
        gltfRoot = wrapper;

        if (gltf.animations && gltf.animations.length > 0) {
          clips = gltf.animations;
          mixer = new THREE.AnimationMixer(model);
          const walkIdx = clips.findIndex((c) => c.name === 'Player12');
          currentClipIndex = walkIdx >= 0 ? walkIdx : 0;
          const action = mixer.clipAction(clips[currentClipIndex]);
          action.play();
        }

        setIsLoaded(true);
      },
      undefined,
      () => {
        setIsLoaded(true);
      }
    );

    let downX = 0;
    let downY = 0;
    const onPointerDown = (e: PointerEvent) => {
      downX = e.clientX;
      downY = e.clientY;
    };
    const onPointerUp = (e: PointerEvent) => {
      const dist = Math.hypot(e.clientX - downX, e.clientY - downY);
      if (dist < 6 && mixer && clips.length > 1) {
        const prevAction = mixer.clipAction(clips[currentClipIndex]);
        const preferredNames = [
          'Player12',
          'PlayerJump',
          'Unied',
          'Animation',
        ];
        const currentName = clips[currentClipIndex]?.name || '';
        const nextPrefIdx =
          (preferredNames.indexOf(currentName) + 1) % preferredNames.length;
        const foundIdx = clips.findIndex(
          (c) => c.name === preferredNames[nextPrefIdx]
        );
        currentClipIndex =
          foundIdx >= 0 ? foundIdx : (currentClipIndex + 1) % clips.length;
        const nextAction = mixer.clipAction(clips[currentClipIndex]);
        nextAction.reset().play();
        prevAction.crossFadeTo(nextAction, 0.22, false);
      }
    };

    canvas.addEventListener('pointerdown', onPointerDown, {
      signal: abortController.signal,
    });
    canvas.addEventListener('pointerup', onPointerUp, {
      signal: abortController.signal,
    });

    const onContextLost = (e: Event) => {
      e.preventDefault();
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      setContextLost(true);
    };
    const onContextRestored = () => {
      setContextLost(false);
      clock.start();
      tick();
    };
    canvas.addEventListener('webglcontextlost', onContextLost, {
      signal: abortController.signal,
    });
    canvas.addEventListener('webglcontextrestored', onContextRestored, {
      signal: abortController.signal,
    });

    const resizeObserver = new ResizeObserver(() => {
      if (disposed) return;
      const w = Math.max(1, container.clientWidth);
      const h = Math.max(1, container.clientHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    });
    resizeObserver.observe(container);

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    const clock = new THREE.Clock();
    let smoothedYaw = -0.3;

    function tick() {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      if (controls.enableDamping) {
        controls.update();
      }

      if (mixer && !prefersReducedMotion) {
        mixer.update(dt);
      }

      const targetYaw =
        -0.3 +
        (scrollProgressRef.current || 0) * Math.PI * 1.45 +
        (prefersReducedMotion ? 0 : Math.sin(elapsed * 0.5) * 0.18);

      smoothedYaw = THREE.MathUtils.damp(smoothedYaw, targetYaw, 5, dt);
      stageRoot.rotation.y = smoothedYaw;

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      abortController.abort();
      resizeObserver.disconnect();
      controls.dispose();
      if (mixer) {
        mixer.stopAllAction();
      }
      if (gltfRoot) {
        gltfRoot.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            const mesh = obj as THREE.Mesh;
            mesh.geometry?.dispose();
            if (Array.isArray(mesh.material)) {
              mesh.material.forEach((m) => m.dispose());
            } else {
              mesh.material?.dispose();
            }
          }
        });
      }
      disposableGeos.forEach((g) => g.dispose());
      disposableMats.forEach((m) => m.dispose());
      disposableTexs.forEach((t) => t.dispose());
      envTarget.dispose();
      renderer.dispose();
    };
  }, [scrollProgressRef]);

  return (
    <div className="filter drop-shadow-[0_18px_28px_rgba(0,0,0,0.65)] w-full max-w-[440px] ml-auto">
      <div className="poly-avatar-box relative w-full h-[420px] sm:h-[470px] bg-gradient-to-b from-[#a8a8a8] via-[#7c7c7c] to-[#454545] overflow-hidden">
        <div ref={canvasMountRef} className="w-full h-full" />

        {!isLoaded && !contextLost && (
          <div className="absolute inset-0 z-20 flex items-center justify-center bg-[#686868]/80 pointer-events-none">
            <span className="font-chatopia text-xl tracking-wider">
              LOADING...
            </span>
          </div>
        )}

        {contextLost && (
          <div
            role="alert"
            className="absolute inset-0 z-20 flex items-center justify-center p-6 text-center bg-[#484848]"
          >
            <span className="font-chatopia text-lg">WEBGL PAUSED</span>
          </div>
        )}
      </div>
    </div>
  );
}
