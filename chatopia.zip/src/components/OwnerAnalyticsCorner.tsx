import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  auth,
  googleProvider,
  isAllowedOwner,
} from '../firebase';
import { TRANSLATIONS, type SiteLang } from '../i18n';
import {
  subscribeToOwnerAnalytics,
  type AnalyticsEventType,
  type AnalyticsSnapshotSummary,
} from '../utils/siteAnalytics';

interface OwnerAnalyticsCornerProps {
  lang: SiteLang;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

type DashboardTab = 'overview' | 'sessions' | 'events';

function formatDuration(sec: number): string {
  if (sec < 60) return `${sec}s`;
  const mins = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${mins}m ${String(rem).padStart(2, '0')}s`;
}

function formatClockTime(ms: number): string {
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(
    d.getMinutes()
  ).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
}

export function OwnerAnalyticsCorner({
  lang,
  isOpen,
  onOpenChange,
}: OwnerAnalyticsCornerProps) {
  const t = TRANSLATIONS[lang].analytics;
  const closeLabel = TRANSLATIONS[lang].close;

  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [stats, setStats] = useState<AnalyticsSnapshotSummary | null>(null);
  const [statsError, setStatsError] = useState<string | null>(null);

  const isOwner = isAllowedOwner(user);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (!nextUser) {
        setStats(null);
        setStatsError(null);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!authReady || !isOwner) {
      setStats(null);
      return;
    }

    setStatsError(null);
    const unsub = subscribeToOwnerAnalytics(
      (summary) => {
        setStats(summary);
        setStatsError(null);
      },
      (err) => {
        setStatsError(
          err instanceof Error ? err.message : 'Analytics sync error.'
        );
      }
    );

    return () => unsub();
  }, [authReady, isOwner]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onOpenChange(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onOpenChange]);

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    setSigningIn(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (!msg.includes('popup-closed-by-user')) {
        setAuthError(msg);
      }
    } finally {
      setSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setAuthError(null);
    try {
      await signOut(auth);
      setStats(null);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : String(err));
    }
  };

  const featureRows: Array<{ key: AnalyticsEventType; color: string }> = [
    { key: 'try_web', color: 'bg-yellow-300' },
    { key: 'discord_click', color: 'bg-indigo-300' },
    { key: 'telegram_click', color: 'bg-sky-300' },
    { key: 'itch_click', color: 'bg-rose-300' },
    { key: 'gamejolt_click', color: 'bg-lime-300' },
    { key: 'info_open', color: 'bg-amber-300' },
    { key: 'contact_open', color: 'bg-emerald-300' },
    { key: 'place_preview', color: 'bg-orange-300' },
    { key: 'lang_switch', color: 'bg-cyan-300' },
    { key: 'font_switch', color: 'bg-zinc-300' },
  ];

  const maxHourlyTotal = stats
    ? Math.max(
        1,
        ...stats.hourlyTimeline.map((b) => Math.max(b.visits, b.actions))
      )
    : 1;

  const maxFeatureCount = stats
    ? Math.max(1, ...featureRows.map((r) => stats.eventCounts[r.key] || 0))
    : 1;

  const nowMs = Date.now();

  return (
    <>
      {/* TOP-RIGHT FLOATING SIGNATURE CORNER WIDGET: Shown exclusively after verified owner login */}
      {isOwner && (
        <motion.aside
          initial={{ opacity: 0, x: 20, y: -12 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          transition={{ type: 'spring', stiffness: 190, damping: 22 }}
          aria-label={t.cornerOwnerAria}
          className="fixed top-2.5 right-2.5 sm:top-3.5 sm:right-3.5 z-50 filter drop-shadow-[0_10px_18px_rgba(0,0,0,0.82)]"
        >
          <button
            type="button"
            onClick={() => onOpenChange(true)}
            aria-label={t.cornerOwnerAria}
            className="poly-inner-brand p-[2px] cursor-pointer transition-transform hover:scale-105 active:scale-95 block bg-gradient-to-b from-[#fef08a] via-[#eab308] to-[#854d0e]"
          >
            <span className="poly-inner-brand vfx-shimmer px-2.5 sm:px-3.5 py-1.5 min-h-[38px] sm:min-h-[42px] flex items-center gap-2 bg-gradient-to-b from-[#54471c] via-[#382f14] to-[#211c0d]">
              {/* Status LED */}
              <span className="w-2.5 h-2.5 rounded-full shrink-0 bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse" />

              {/* Analytics Bars Icon */}
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="square"
                strokeLinejoin="miter"
                aria-hidden="true"
                className="w-4 h-4 sm:w-[18px] sm:h-[18px] shrink-0 text-yellow-300"
              >
                <rect x="3" y="12" width="4" height="8" />
                <rect x="10" y="7" width="4" height="13" />
                <rect x="17" y="4" width="4" height="16" />
              </svg>

              <span className="flex items-center gap-2 sm:gap-2.5">
                <span className="font-chatopia-gold text-xs sm:text-sm tracking-wider leading-none">
                  {t.cornerOnline}: {stats ? stats.onlineNow : '...'}
                </span>
                <span className="hidden md:inline font-chatopia text-xs tracking-wider leading-none opacity-90">
                  {t.cornerVisits}: {stats ? stats.totalVisits : '...'}
                </span>
              </span>
            </span>
          </button>
        </motion.aside>
      )}

      {/* ANALYTICS & ACTIVITY MODAL */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={t.dialogAria}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => onOpenChange(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/82 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.93, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.93, y: 20, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 230, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-5xl w-full filter drop-shadow-[0_24px_50px_rgba(0,0,0,0.95)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#e0e0e0] via-[#8c8c8c] to-[#3a3a3a]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-4 sm:p-6 space-y-4">
                  {/* Modal Header */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="poly-chamfer-sm p-[1.5px] bg-gradient-to-b from-yellow-200 to-amber-600 shrink-0">
                        <div className="poly-chamfer-sm w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-b from-[#4c4019] to-[#26200b] flex items-center justify-center">
                          <svg
                            width="20"
                            height="20"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2.2"
                            aria-hidden="true"
                            className="text-yellow-300"
                          >
                            <rect x="3" y="12" width="4" height="8" />
                            <rect x="10" y="7" width="4" height="13" />
                            <rect x="17" y="4" width="4" height="16" />
                          </svg>
                        </div>
                      </div>

                      <div className="min-w-0">
                        <h3 className="font-chatopia text-lg sm:text-2xl tracking-wider uppercase truncate leading-none">
                          {t.modalTitle}
                        </h3>
                        {isOwner && (
                          <p className="font-chatopia-gold text-xs sm:text-sm tracking-wider truncate mt-1">
                            {t.exclusiveBadge}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {user && (
                        <>
                          <button
                            type="button"
                            onClick={handleGoogleSignIn}
                            disabled={signingIn}
                            className="poly-inner-brand px-3 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer active:scale-95"
                          >
                            <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                              {t.switchAccount}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={handleSignOut}
                            className="poly-inner-brand px-3 py-1.5 bg-gradient-to-b from-[#7a7a7a] to-[#424242] hover:from-[#929292] hover:to-[#545454] cursor-pointer active:scale-95"
                          >
                            <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                              {t.signOut}
                            </span>
                          </button>
                        </>
                      )}
                      <button
                        type="button"
                        onClick={() => onOpenChange(false)}
                        className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                          {closeLabel}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Modal Body */}
                  <div className="poly-window-shell p-[2px] bg-[#101010]">
                    <div className="poly-window-shell chatopia-scrollbox max-h-[68vh] overflow-y-auto bg-gradient-to-b from-[#262626] via-[#1c1c1c] to-[#121212] p-4 sm:p-6">
                      {!user ? (
                        /* NOT SIGNED IN: OWNER GOOGLE AUTH GATE */
                        <div className="max-w-lg mx-auto py-4 space-y-5 text-center">
                          <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#fde047] via-[#787878] to-[#464646]">
                            <div className="poly-chamfer-md bg-[#262626] p-5 space-y-3">
                              <h4 className="font-chatopia-gold text-xl sm:text-2xl tracking-wider uppercase">
                                {t.signedOutTitle}
                              </h4>
                              <p className="font-chatopia text-sm sm:text-base leading-relaxed opacity-90">
                                {t.signedOutDesc}
                              </p>
                            </div>
                          </div>

                          {authError && (
                            <p
                              role="alert"
                              className="font-chatopia text-xs sm:text-sm text-red-300"
                            >
                              {t.authErrorPrefix} {authError}
                            </p>
                          )}

                          <button
                            type="button"
                            onClick={handleGoogleSignIn}
                            disabled={signingIn}
                            className="poly-inner-brand p-[2.5px] bg-gradient-to-b from-[#fef08a] via-[#eab308] to-[#854d0e] cursor-pointer transition-transform hover:scale-105 active:scale-95 disabled:opacity-60 mx-auto inline-flex"
                          >
                            <span className="poly-inner-brand vfx-shimmer px-7 py-3 bg-gradient-to-b from-[#5c4f1d] via-[#403613] to-[#26200b] flex items-center gap-3">
                              <span className="w-2.5 h-2.5 rounded-full bg-yellow-300 shadow-[0_0_8px_#fde047]" />
                              <span className="font-chatopia-gold text-base sm:text-lg tracking-wider uppercase">
                                {signingIn ? t.signingIn : t.signInGoogle}
                              </span>
                            </span>
                          </button>
                        </div>
                      ) : !isOwner ? (
                        /* SIGNED IN WITH NON-OWNER EMAIL */
                        <div className="max-w-lg mx-auto py-4 space-y-4 text-center">
                          <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#f87171] via-[#7f1d1d] to-[#450a0a]">
                            <div className="poly-chamfer-md bg-[#2b1314] p-5 space-y-3">
                              <h4 className="font-chatopia text-xl sm:text-2xl tracking-wider uppercase text-red-200">
                                {t.deniedTitle}
                              </h4>
                              <p className="font-chatopia text-sm sm:text-base leading-relaxed text-red-100/90">
                                {t.deniedDesc}
                              </p>
                            </div>
                          </div>

                          <div className="flex flex-wrap justify-center gap-3">
                            <button
                              type="button"
                              onClick={handleGoogleSignIn}
                              disabled={signingIn}
                              className="poly-inner-brand px-5 py-2.5 bg-gradient-to-b from-[#a8a8a8] to-[#585858] hover:from-[#bcbcbc] hover:to-[#6a6a6a] cursor-pointer"
                            >
                              <span className="font-chatopia text-sm tracking-wider uppercase">
                                {t.switchAccount}
                              </span>
                            </button>
                            <button
                              type="button"
                              onClick={handleSignOut}
                              className="poly-inner-brand px-5 py-2.5 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer"
                            >
                              <span className="font-chatopia text-sm tracking-wider uppercase">
                                {t.signOut}
                              </span>
                            </button>
                          </div>
                        </div>
                      ) : statsError ? (
                        <div className="poly-chamfer-md p-[2px] bg-red-400/70">
                          <div className="poly-chamfer-md bg-[#2c1415] p-4 text-center font-chatopia text-sm text-red-200">
                            {statsError}
                          </div>
                        </div>
                      ) : !stats ? (
                        <div className="py-12 text-center font-chatopia-gold text-lg tracking-wider uppercase">
                          {t.loadingStats}
                        </div>
                      ) : (
                        /* OWNER FULL ANALYTICS DASHBOARD */
                        <div className="space-y-5">
                          {/* Navigation Tabs */}
                          <div className="flex flex-wrap items-center gap-2">
                            {(
                              [
                                { id: 'overview', label: t.tabOverview },
                                {
                                  id: 'sessions',
                                  label: `${t.tabSessions} (${stats.recentSessions.length})`,
                                },
                                {
                                  id: 'events',
                                  label: `${t.tabEvents} (${stats.recentEvents.length})`,
                                },
                              ] as const
                            ).map((tab) => (
                              <button
                                key={tab.id}
                                type="button"
                                onClick={() => setActiveTab(tab.id)}
                                className={`poly-chamfer-sm p-[1.5px] cursor-pointer transition-transform active:scale-95 ${
                                  activeTab === tab.id
                                    ? 'bg-gradient-to-b from-yellow-200 to-amber-600'
                                    : 'bg-gradient-to-b from-[#9c9c9c] to-[#4a4a4a]'
                                }`}
                              >
                                <span
                                  className={`poly-chamfer-sm block px-4 py-1.5 font-chatopia text-xs sm:text-sm tracking-wider uppercase ${
                                    activeTab === tab.id
                                      ? 'bg-[#423815] text-yellow-200'
                                      : 'bg-[#323232] hover:bg-[#3f3f3f] text-white'
                                  }`}
                                >
                                  {tab.label}
                                </span>
                              </button>
                            ))}
                          </div>

                          {activeTab === 'overview' && (
                            <div className="space-y-5">
                              {/* 6 KPI Metric Cards */}
                              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                                {/* 1. Online Now */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-emerald-300 via-emerald-700 to-[#2f4f42]">
                                  <div className="poly-chamfer-md h-full bg-[#122920] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider text-emerald-200/85 block">
                                      {t.kpiOnlineNow}
                                    </span>
                                    <div className="flex items-center gap-2">
                                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse shrink-0" />
                                      <span className="font-chatopia text-2xl sm:text-3xl text-emerald-200 leading-none">
                                        {stats.onlineNow}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* 2. Total Visits */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-yellow-300 via-[#887021] to-[#4a3e16]">
                                  <div className="poly-chamfer-md h-full bg-[#2f2812] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider text-yellow-100/80 block">
                                      {t.kpiVisits}
                                    </span>
                                    <div className="flex items-baseline justify-between gap-2">
                                      <span className="font-chatopia-gold text-2xl sm:text-3xl leading-none">
                                        {stats.totalVisits}
                                      </span>
                                      <span className="font-chatopia text-xs text-yellow-200/85">
                                        {t.todayLabel}: {stats.todayVisits}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* 3. Unique Visitors */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-sky-300 via-[#2a5c75] to-[#1b3847]">
                                  <div className="poly-chamfer-md h-full bg-[#132631] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider text-sky-100/80 block">
                                      {t.kpiUnique}
                                    </span>
                                    <div className="flex items-baseline justify-between gap-2">
                                      <span className="font-chatopia text-2xl sm:text-3xl text-sky-200 leading-none">
                                        {stats.uniqueVisitors}
                                      </span>
                                      <span className="font-chatopia text-xs text-sky-200/85">
                                        {t.todayLabel}: {stats.todayUniqueVisitors}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* 4. Avg Session Duration */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#d4d4d4] via-[#6e6e6e] to-[#424242]">
                                  <div className="poly-chamfer-md h-full bg-[#242424] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider opacity-80 block">
                                      {t.kpiAvgDuration}
                                    </span>
                                    <div className="flex items-baseline justify-between gap-2">
                                      <span className="font-chatopia text-2xl sm:text-3xl leading-none">
                                        {formatDuration(stats.avgDurationSec)}
                                      </span>
                                      <span className="font-chatopia text-xs opacity-75">
                                        {t.maxLabel}:{' '}
                                        {formatDuration(stats.maxDurationSec)}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                {/* 5. Engagement Rate */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-orange-300 via-[#884c1b] to-[#4d2b11]">
                                  <div className="poly-chamfer-md h-full bg-[#2b1a0f] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider text-orange-100/80 block">
                                      {t.kpiEngagement}
                                    </span>
                                    <span className="font-chatopia text-2xl sm:text-3xl text-orange-200 leading-none block">
                                      {stats.engagementRatePct}%
                                    </span>
                                  </div>
                                </div>

                                {/* 6. Total Actions */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-amber-300 via-[#7c5c19] to-[#4a3711]">
                                  <div className="poly-chamfer-md h-full bg-[#2a210f] p-3.5 space-y-1">
                                    <span className="font-chatopia text-xs uppercase tracking-wider text-amber-100/80 block">
                                      {t.kpiActions}
                                    </span>
                                    <span className="font-chatopia text-2xl sm:text-3xl text-amber-200 leading-none block">
                                      {stats.totalActions}
                                    </span>
                                  </div>
                                </div>
                              </div>

                              {/* 24H Activity Timeline */}
                              <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#7a7a7a] to-[#3a3a3a]">
                                <div className="poly-chamfer-md bg-[#1a1a1a] p-4 space-y-3">
                                  <div className="flex flex-wrap items-center justify-between gap-2">
                                    <h4 className="font-chatopia text-sm sm:text-base tracking-wider uppercase">
                                      {t.hourlyHeading}
                                    </h4>
                                    <div className="flex items-center gap-4 text-xs font-chatopia">
                                      <span className="flex items-center gap-1.5 text-yellow-300">
                                        <span className="w-2.5 h-2.5 bg-yellow-300 inline-block" />
                                        {t.hourlyVisitsLegend}
                                      </span>
                                      <span className="flex items-center gap-1.5 text-sky-300">
                                        <span className="w-2.5 h-2.5 bg-sky-300 inline-block" />
                                        {t.hourlyActionsLegend}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-12 gap-1.5 sm:gap-2 items-end h-28 pt-2">
                                    {stats.hourlyTimeline.map((bucket) => {
                                      const visitPct = Math.round(
                                        (bucket.visits / maxHourlyTotal) * 100
                                      );
                                      const actionPct = Math.round(
                                        (bucket.actions / maxHourlyTotal) * 100
                                      );
                                      return (
                                        <div
                                          key={bucket.hourLabel}
                                          title={`${bucket.hourLabel} | ${t.hourlyVisitsLegend}: ${bucket.visits}, ${t.hourlyActionsLegend}: ${bucket.actions}`}
                                          className="flex flex-col items-center justify-end h-full gap-1"
                                        >
                                          <div className="w-full flex items-end justify-center gap-0.5 flex-1">
                                            <div
                                              style={{
                                                height: `${Math.max(bucket.visits > 0 ? 10 : 3, visitPct)}%`,
                                              }}
                                              className="w-1/2 bg-gradient-to-t from-amber-500 to-yellow-300 transition-all"
                                            />
                                            <div
                                              style={{
                                                height: `${Math.max(bucket.actions > 0 ? 10 : 3, actionPct)}%`,
                                              }}
                                              className="w-1/2 bg-gradient-to-t from-sky-600 to-sky-300 transition-all"
                                            />
                                          </div>
                                          <span className="font-chatopia text-[9px] sm:text-[10px] opacity-70">
                                            {bucket.hourLabel.slice(0, 2)}
                                          </span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              </div>

                              {/* Clicks & Audience Split Grid */}
                              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                {/* CTAs & Interaction Breakdown */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#7a7a7a] to-[#3a3a3a]">
                                  <div className="poly-chamfer-md h-full bg-[#1c1c1c] p-4 space-y-3">
                                    <h4 className="font-chatopia text-sm sm:text-base tracking-wider uppercase">
                                      {t.ctaHeading}
                                    </h4>
                                    <div className="space-y-2">
                                      {featureRows.map((row) => {
                                        const count =
                                          stats.eventCounts[row.key] || 0;
                                        const pct = Math.round(
                                          (count / maxFeatureCount) * 100
                                        );
                                        return (
                                          <div
                                            key={row.key}
                                            className="space-y-1"
                                          >
                                            <div className="flex items-center justify-between text-xs sm:text-sm font-chatopia">
                                              <span className="opacity-90">
                                                {t.eventLabels[row.key]}
                                              </span>
                                              <span className="text-yellow-200">
                                                {count}
                                              </span>
                                            </div>
                                            <div className="w-full h-2 bg-[#2d2d2d] overflow-hidden">
                                              <div
                                                style={{
                                                  width: `${count > 0 ? Math.max(4, pct) : 0}%`,
                                                }}
                                                className={`h-full ${row.color} transition-all`}
                                              />
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </div>
                                </div>

                                {/* Audience, Devices, Sources, Places */}
                                <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#7a7a7a] to-[#3a3a3a]">
                                  <div className="poly-chamfer-md h-full bg-[#1c1c1c] p-4 space-y-4">
                                    <h4 className="font-chatopia text-sm sm:text-base tracking-wider uppercase">
                                      {t.audienceHeading}
                                    </h4>

                                    {/* Language & Font & Device Chips */}
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                                      <div className="poly-chamfer-sm p-[1.5px] bg-[#555555]">
                                        <div className="poly-chamfer-sm bg-[#242424] p-2.5 space-y-1">
                                          <span className="font-chatopia text-[11px] uppercase opacity-75 block">
                                            {t.languagesLabel}
                                          </span>
                                          <p className="font-chatopia text-xs sm:text-sm">
                                            EN: {stats.langCounts.en}
                                          </p>
                                          <p className="font-chatopia text-xs sm:text-sm">
                                            RU: {stats.langCounts.ru}
                                          </p>
                                        </div>
                                      </div>

                                      <div className="poly-chamfer-sm p-[1.5px] bg-[#555555]">
                                        <div className="poly-chamfer-sm bg-[#242424] p-2.5 space-y-1">
                                          <span className="font-chatopia text-[11px] uppercase opacity-75 block">
                                            {t.fontsLabel}
                                          </span>
                                          <p className="font-chatopia text-xs sm:text-sm">
                                            OldRbx: {stats.fontCounts.oldroblox}
                                          </p>
                                          <p className="font-chatopia text-xs sm:text-sm">
                                            Boblox: {stats.fontCounts.boblox}
                                          </p>
                                        </div>
                                      </div>

                                      <div className="poly-chamfer-sm p-[1.5px] bg-[#555555]">
                                        <div className="poly-chamfer-sm bg-[#242424] p-2.5 space-y-1">
                                          <span className="font-chatopia text-[11px] uppercase opacity-75 block">
                                            {t.devicesLabel}
                                          </span>
                                          <p className="font-chatopia text-xs">
                                            PC: {stats.deviceCounts.desktop}
                                          </p>
                                          <p className="font-chatopia text-xs">
                                            Mob: {stats.deviceCounts.mobile} / Tab:{' '}
                                            {stats.deviceCounts.tablet}
                                          </p>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Places Breakdown */}
                                    <div className="space-y-1.5">
                                      <span className="font-chatopia text-xs uppercase opacity-75 block">
                                        {t.placesHeading}
                                      </span>
                                      <div className="flex flex-wrap gap-2">
                                        <span className="poly-chamfer-sm p-[1px] bg-[#666666]">
                                          <span className="poly-chamfer-sm block px-2.5 py-1 bg-[#262626] font-chatopia text-xs">
                                            Chatting Zone:{' '}
                                            {stats.placeCounts['chatting-zone'] || 0}
                                          </span>
                                        </span>
                                        <span className="poly-chamfer-sm p-[1px] bg-[#666666]">
                                          <span className="poly-chamfer-sm block px-2.5 py-1 bg-[#262626] font-chatopia text-xs">
                                            SFOTH: {stats.placeCounts['sfoth'] || 0}
                                          </span>
                                        </span>
                                      </div>
                                    </div>

                                    {/* Referrers & Viewports */}
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                      <div className="space-y-1.5">
                                        <span className="font-chatopia text-xs uppercase opacity-75 block">
                                          {t.referrersLabel}
                                        </span>
                                        {stats.topReferrers.length === 0 ? (
                                          <p className="font-chatopia text-xs opacity-60">
                                            {t.noDataYet}
                                          </p>
                                        ) : (
                                          <div className="space-y-1">
                                            {stats.topReferrers.map((r) => (
                                              <div
                                                key={r.name}
                                                className="flex items-center justify-between font-chatopia text-xs bg-[#262626] px-2.5 py-1"
                                              >
                                                <span className="truncate pr-2">
                                                  {r.name}
                                                </span>
                                                <span className="text-yellow-200 shrink-0">
                                                  {r.count}
                                                </span>
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>

                                      <div className="space-y-1.5">
                                        <span className="font-chatopia text-xs uppercase opacity-75 block">
                                          {t.viewportsLabel}
                                        </span>
                                        {stats.topViewports.length === 0 ? (
                                          <p className="font-chatopia text-xs opacity-60">
                                            {t.noDataYet}
                                          </p>
                                        ) : (
                                          <div className="space-y-1">
                                            {stats.topViewports.map((v) => (
                                              <div
                                                key={v.name}
                                                className="flex items-center justify-between font-chatopia text-xs bg-[#262626] px-2.5 py-1"
                                              >
                                                <span>{v.name}</span>
                                                <span className="text-sky-200 shrink-0">
                                                  {v.count}
                                                </span>
                                              </div>
                                            ))}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}

                          {activeTab === 'sessions' && (
                            <div className="space-y-2.5">
                              {stats.recentSessions.length === 0 ? (
                                <p className="font-chatopia text-sm text-center py-6 opacity-75">
                                  {t.noDataYet}
                                </p>
                              ) : (
                                stats.recentSessions.map((sess) => {
                                  const isLive =
                                    nowMs - sess.lastSeenAtMs <= 120000;
                                  return (
                                    <div
                                      key={sess.sessionId}
                                      className={`poly-chamfer-sm p-[1.5px] ${
                                        isLive
                                          ? 'bg-gradient-to-r from-emerald-300 via-emerald-700 to-[#3a3a3a]'
                                          : 'bg-[#505050]'
                                      }`}
                                    >
                                      <div className="poly-chamfer-sm bg-[#202020] px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs font-chatopia">
                                        <div className="flex items-center gap-2">
                                          <span
                                            className={`w-2 h-2 rounded-full shrink-0 ${
                                              isLive
                                                ? 'bg-emerald-400 animate-pulse'
                                                : 'bg-zinc-500'
                                            }`}
                                          />
                                          <span
                                            className={
                                              isLive
                                                ? 'text-emerald-300'
                                                : 'opacity-70'
                                            }
                                          >
                                            {isLive ? t.liveTag : t.recentTag}
                                          </span>
                                          <span className="opacity-85">
                                            {sess.deviceType.toUpperCase()} ({sess.viewport})
                                          </span>
                                          <span className="text-yellow-200">
                                            [{sess.lang.toUpperCase()} /{' '}
                                            {sess.fontMode}]
                                          </span>
                                        </div>

                                        <div className="flex flex-wrap items-center gap-3 opacity-85">
                                          <span>
                                            {t.durationLabel}:{' '}
                                            {formatDuration(sess.durationSec)}
                                          </span>
                                          <span>
                                            {t.actionsLabel}: {sess.actionsCount}
                                          </span>
                                          <span>
                                            {t.sourceLabel}: {sess.referrerHost}
                                          </span>
                                          <span>
                                            {t.lastSeenLabel}:{' '}
                                            {formatClockTime(sess.lastSeenAtMs)}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })
                              )}
                            </div>
                          )}

                          {activeTab === 'events' && (
                            <div className="space-y-2">
                              {stats.recentEvents.length === 0 ? (
                                <p className="font-chatopia text-sm text-center py-6 opacity-75">
                                  {t.noDataYet}
                                </p>
                              ) : (
                                stats.recentEvents.map((ev) => (
                                  <div
                                    key={ev.id}
                                    className="poly-chamfer-sm p-[1.5px] bg-[#4c4c4c]"
                                  >
                                    <div className="poly-chamfer-sm bg-[#202020] px-3.5 py-2 flex flex-wrap items-center justify-between gap-2 text-xs font-chatopia">
                                      <div className="flex items-center gap-2 min-w-0">
                                        <span className="text-yellow-200">
                                          {t.eventLabels[ev.eventType]}
                                        </span>
                                        {ev.target && (
                                          <span className="text-sky-200 truncate">
                                            [{ev.target}]
                                          </span>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-3 opacity-80 shrink-0">
                                        <span>{ev.deviceType.toUpperCase()}</span>
                                        <span>{ev.lang.toUpperCase()}</span>
                                        <span>
                                          {formatClockTime(ev.createdAtMs)}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
