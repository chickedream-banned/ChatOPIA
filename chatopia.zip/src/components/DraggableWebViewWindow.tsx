import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';

interface DraggableWebViewWindowProps {
  isOpen: boolean;
  isMinimized: boolean;
  onMinimizeChange: (minimized: boolean) => void;
  onClose: () => void;
  url?: string;
}

interface WindowBounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface SavedSyncAccount {
  id: string;
  username: string;
  savedAt: number;
}

const BOUNDS_STORAGE_KEY = 'chatopia_webview_bounds_v1';
const ACCOUNTS_STORAGE_KEY = 'chatopia_synced_accounts_v1';
const KEEP_SESSION_STORAGE_KEY = 'chatopia_webview_keep_session_v1';

function getViewportSize(): { vw: number; vh: number } {
  if (typeof window === 'undefined') return { vw: 1200, vh: 800 };
  const vv = window.visualViewport;
  return {
    vw: Math.round(vv?.width ?? window.innerWidth),
    vh: Math.round(vv?.height ?? window.innerHeight),
  };
}

function clampPosition(
  x: number,
  y: number,
  width: number,
  height: number
): { x: number; y: number } {
  const { vw, vh } = getViewportSize();
  const minVisibleX = Math.min(120, Math.round(width * 0.45));
  const minX = -(width - minVisibleX);
  const maxX = vw - minVisibleX;
  const minY = 4;
  const maxY = Math.max(minY, vh - Math.min(64, Math.round(height * 0.25)));

  return {
    x: Math.round(Math.max(minX, Math.min(x, maxX))),
    y: Math.round(Math.max(minY, Math.min(y, maxY))),
  };
}

function computeInitialBounds(): WindowBounds {
  const { vw, vh } = getViewportSize();
  const isCompact = vw < 640;
  const defaultW = isCompact
    ? Math.min(Math.max(280, Math.round(vw * 0.92)), vw - 16)
    : Math.min(Math.max(360, vw - 32), 960);
  const defaultH = isCompact
    ? Math.min(Math.max(300, Math.round(vh * 0.68)), vh - 32)
    : Math.min(Math.max(380, vh - 80), 650);

  try {
    const raw = localStorage.getItem(BOUNDS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<WindowBounds>;
      if (
        typeof parsed.x === 'number' &&
        typeof parsed.y === 'number' &&
        typeof parsed.width === 'number' &&
        typeof parsed.height === 'number'
      ) {
        const width = Math.max(260, Math.min(parsed.width, vw - 16));
        const height = Math.max(240, Math.min(parsed.height, vh - 24));
        const pos = clampPosition(parsed.x, parsed.y, width, height);
        return { x: pos.x, y: pos.y, width, height };
      }
    }
  } catch {
    // Ignore storage read errors
  }

  return {
    x: Math.max(8, Math.round((vw - defaultW) / 2)),
    y: Math.max(12, Math.round((vh - defaultH) / 2)),
    width: defaultW,
    height: defaultH,
  };
}

function loadSavedAccounts(): SavedSyncAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is SavedSyncAccount =>
        Boolean(item) &&
        typeof item.id === 'string' &&
        typeof item.username === 'string' &&
        typeof item.savedAt === 'number'
    );
  } catch {
    return [];
  }
}

function loadKeepSession(): boolean {
  try {
    return localStorage.getItem(KEEP_SESSION_STORAGE_KEY) === 'true';
  } catch {
    return false;
  }
}

export const DraggableWebViewWindow: React.FC<DraggableWebViewWindowProps> = ({
  isOpen,
  isMinimized,
  onMinimizeChange,
  onClose,
  url = 'https://chatopia-game.pages.dev',
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [hasActivated, setHasActivated] = useState(isOpen);

  // Sync & Account Persistence State
  const [showSyncDrawer, setShowSyncDrawer] = useState(false);
  const [savedAccounts, setSavedAccounts] =
    useState<SavedSyncAccount[]>(loadSavedAccounts);
  const [accountInput, setAccountInput] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [keepSessionOnClose, setKeepSessionOnClose] =
    useState<boolean>(loadKeepSession);
  const [storagePersisted, setStoragePersisted] = useState<boolean | null>(
    null
  );

  const [bounds, setBounds] = useState<WindowBounds>(computeInitialBounds);
  const liveBoundsRef = useRef<WindowBounds>(bounds);
  const windowRef = useRef<HTMLDivElement | null>(null);

  const dragStateRef = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  }>({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    originX: 0,
    originY: 0,
  });

  const resizeStateRef = useRef<{
    active: boolean;
    pointerId: number | null;
    startX: number;
    startY: number;
    originW: number;
    originH: number;
  }>({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    originW: 0,
    originH: 0,
  });

  useEffect(() => {
    if (isOpen) {
      setHasActivated(true);
    }
  }, [isOpen]);

  // Ask browser for persistent storage when the web window is opened
  useEffect(() => {
    if (!isOpen) return;
    if (typeof navigator !== 'undefined' && navigator.storage?.persist) {
      navigator.storage
        .persisted()
        .then((already) => {
          if (already) {
            setStoragePersisted(true);
            return;
          }
          return navigator.storage.persist().then((granted) => {
            setStoragePersisted(granted);
          });
        })
        .catch(() => {
          setStoragePersisted(null);
        });
    }
  }, [isOpen]);

  useEffect(() => {
    liveBoundsRef.current = bounds;
    try {
      localStorage.setItem(BOUNDS_STORAGE_KEY, JSON.stringify(bounds));
    } catch {
      // Ignore storage write errors
    }
  }, [bounds]);

  useEffect(() => {
    try {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(savedAccounts));
    } catch {
      // Ignore storage write errors
    }
  }, [savedAccounts]);

  useEffect(() => {
    try {
      localStorage.setItem(
        KEEP_SESSION_STORAGE_KEY,
        keepSessionOnClose ? 'true' : 'false'
      );
    } catch {
      // Ignore storage write errors
    }
  }, [keepSessionOnClose]);

  // Keep window within viewport on device orientation change or resize
  useEffect(() => {
    const handleViewportResize = () => {
      const { vw, vh } = getViewportSize();
      setBounds((prev) => {
        const nextW = Math.max(260, Math.min(prev.width, vw - 16));
        const nextH = Math.max(240, Math.min(prev.height, vh - 24));
        const pos = clampPosition(prev.x, prev.y, nextW, nextH);
        const next = { x: pos.x, y: pos.y, width: nextW, height: nextH };
        liveBoundsRef.current = next;
        return next;
      });
    };

    window.addEventListener('resize', handleViewportResize);
    window.visualViewport?.addEventListener('resize', handleViewportResize);
    return () => {
      window.removeEventListener('resize', handleViewportResize);
      window.visualViewport?.removeEventListener('resize', handleViewportResize);
    };
  }, []);

  // Escape key exits fullscreen
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, isFullscreen]);

  const interactionAbortRef = useRef<AbortController | null>(null);

  const finishInteraction = useCallback(() => {
    interactionAbortRef.current?.abort();
    interactionAbortRef.current = null;
    if (dragStateRef.current.active) {
      dragStateRef.current.active = false;
      dragStateRef.current.pointerId = null;
      setBounds({ ...liveBoundsRef.current });
      setIsDragging(false);
    }
    if (resizeStateRef.current.active) {
      resizeStateRef.current.active = false;
      resizeStateRef.current.pointerId = null;
      setBounds({ ...liveBoundsRef.current });
      setIsResizing(false);
    }
  }, []);

  useEffect(() => {
    return () => {
      interactionAbortRef.current?.abort();
      interactionAbortRef.current = null;
    };
  }, []);

  const attachGlobalPointerListeners = useCallback(() => {
    interactionAbortRef.current?.abort();
    const controller = new AbortController();
    interactionAbortRef.current = controller;
    const { signal } = controller;

    const onPointerMove = (e: PointerEvent) => {
      const drag = dragStateRef.current;
      if (
        drag.active &&
        (drag.pointerId === null || drag.pointerId === e.pointerId)
      ) {
        e.preventDefault();
        const dx = e.clientX - drag.startX;
        const dy = e.clientY - drag.startY;
        const cur = liveBoundsRef.current;
        const pos = clampPosition(
          drag.originX + dx,
          drag.originY + dy,
          cur.width,
          cur.height
        );
        const next = { ...cur, x: pos.x, y: pos.y };
        liveBoundsRef.current = next;
        if (windowRef.current) {
          windowRef.current.style.left = `${pos.x}px`;
          windowRef.current.style.top = `${pos.y}px`;
        }
        return;
      }

      const resize = resizeStateRef.current;
      if (
        resize.active &&
        (resize.pointerId === null || resize.pointerId === e.pointerId)
      ) {
        e.preventDefault();
        const dx = e.clientX - resize.startX;
        const dy = e.clientY - resize.startY;
        const { vw, vh } = getViewportSize();
        const cur = liveBoundsRef.current;
        const maxW = Math.max(260, vw - Math.max(8, cur.x) - 8);
        const maxH = Math.max(240, vh - Math.max(8, cur.y) - 8);
        const nextW = Math.round(
          Math.max(260, Math.min(resize.originW + dx, maxW))
        );
        const nextH = Math.round(
          Math.max(240, Math.min(resize.originH + dy, maxH))
        );
        const next = { ...cur, width: nextW, height: nextH };
        liveBoundsRef.current = next;
        if (windowRef.current) {
          windowRef.current.style.width = `${nextW}px`;
          windowRef.current.style.height = `${nextH}px`;
        }
      }
    };

    const onPointerUpOrCancel = (e: PointerEvent) => {
      const drag = dragStateRef.current;
      const resize = resizeStateRef.current;
      if (
        (drag.active &&
          (drag.pointerId === null || drag.pointerId === e.pointerId)) ||
        (resize.active &&
          (resize.pointerId === null || resize.pointerId === e.pointerId))
      ) {
        finishInteraction();
      }
    };

    window.addEventListener('pointermove', onPointerMove, {
      passive: false,
      signal,
    });
    window.addEventListener('pointerup', onPointerUpOrCancel, { signal });
    window.addEventListener('pointercancel', onPointerUpOrCancel, { signal });
    window.addEventListener('blur', finishInteraction, { signal });
  }, [finishInteraction]);

  const startDrag = (e: React.PointerEvent<HTMLElement>) => {
    if (isFullscreen || isMinimized || !isOpen) return;
    if (
      (e.target as HTMLElement).closest(
        'button, a, iframe, input, label, [data-no-drag="true"]'
      )
    ) {
      return;
    }
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore capture errors on browsers/WebViews that restrict capture on touch
    }

    const cur = liveBoundsRef.current;
    dragStateRef.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: cur.x,
      originY: cur.y,
    };
    attachGlobalPointerListeners();
    setIsDragging(true);
  };

  const startResize = (e: React.PointerEvent<HTMLElement>) => {
    if (isFullscreen || isMinimized || !isOpen) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    e.preventDefault();
    e.stopPropagation();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore capture errors on browsers/WebViews that restrict capture on touch
    }

    const cur = liveBoundsRef.current;
    resizeStateRef.current = {
      active: true,
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originW: cur.width,
      originH: cur.height,
    };
    attachGlobalPointerListeners();
    setIsResizing(true);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = accountInput.trim();
    if (!cleaned) return;

    setSavedAccounts((prev) => {
      const existing = prev.find(
        (acc) => acc.username.toLowerCase() === cleaned.toLowerCase()
      );
      if (existing) {
        return [
          { ...existing, username: cleaned, savedAt: Date.now() },
          ...prev.filter((acc) => acc.id !== existing.id),
        ];
      }
      return [
        {
          id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          username: cleaned,
          savedAt: Date.now(),
        },
        ...prev,
      ].slice(0, 12);
    });
    setAccountInput('');
  };

  const handleCopyAccount = (acc: SavedSyncAccount) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(acc.username).catch(() => {});
    }
    setCopiedId(acc.id);
    window.setTimeout(() => {
      setCopiedId((prev) => (prev === acc.id ? null : prev));
    }, 1600);
  };

  const handleRemoveAccount = (id: string) => {
    setSavedAccounts((prev) => prev.filter((acc) => acc.id !== id));
  };

  const handleCloseWindow = () => {
    setIsFullscreen(false);
    if (!keepSessionOnClose) {
      setHasActivated(false);
    }
    onClose();
  };

  const shouldStayMounted = isOpen || (keepSessionOnClose && hasActivated);
  if (!shouldStayMounted) return null;

  const isHiddenMode = !isOpen || isMinimized;

  const windowStyle: React.CSSProperties = isFullscreen
    ? {
        top: 8,
        left: 8,
        right: 8,
        bottom: 8,
        width: 'calc(100vw - 16px)',
        height: 'calc(100vh - 16px)',
      }
    : {
        top: bounds.y,
        left: bounds.x,
        width: bounds.width,
        height: bounds.height,
      };

  return (
    <>
      {/* Transparent shield during drag/resize so iframe never steals mouse or touch events */}
      {(isDragging || isResizing) && (
        <div
          aria-hidden="true"
          className="fixed inset-0 z-[55] touch-none select-none"
          style={{ cursor: isResizing ? 'nwse-resize' : 'grabbing' }}
        />
      )}

      {/* Minimized Floating Dock Bar */}
      <AnimatePresence>
        {isOpen && isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 280, damping: 24 }}
            className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] max-w-[calc(100vw-24px)]"
          >
            <div className="poly-top-bar p-[2.5px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#424242]">
              <div className="poly-top-bar bg-gradient-to-b from-[#969696] via-[#767676] to-[#525252] px-4 sm:px-7 py-2.5 flex items-center gap-3 sm:gap-6">
                <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_10px_#fde047] animate-pulse shrink-0" />
                <span className="font-chatopia text-sm sm:text-xl tracking-wider whitespace-nowrap">
                  CHATOPIA WEB
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onMinimizeChange(false)}
                    aria-label="Развернуть окно"
                    className="poly-inner-brand px-3.5 sm:px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5e5e5e] hover:from-[#bcbcbc] hover:to-[#707070] cursor-pointer transition-transform active:scale-95"
                  >
                    <span className="font-chatopia text-xs sm:text-base tracking-wider">
                      RESTORE
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCloseWindow}
                    aria-label="Закрыть окно"
                    className="poly-inner-brand px-3 sm:px-3.5 py-1.5 bg-gradient-to-b from-[#8c4646] to-[#522222] hover:from-[#a85454] hover:to-[#692b2b] cursor-pointer transition-transform active:scale-95"
                  >
                    <span className="font-chatopia text-xs sm:text-base tracking-wider">
                      X
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Draggable Window (kept mounted when minimized or when keepSessionOnClose is enabled) */}
      <motion.div
        ref={windowRef}
        role="dialog"
        aria-modal="false"
        aria-hidden={isHiddenMode}
        aria-label="Chatopia Web Client"
        initial={{ opacity: 0, scale: 0.9, y: 24 }}
        animate={
          isHiddenMode
            ? {
                opacity: 0,
                scale: 0.65,
                y: 160,
                pointerEvents: 'none' as const,
              }
            : {
                opacity: 1,
                scale: 1,
                y: 0,
                pointerEvents: 'auto' as const,
              }
        }
        transition={{ type: 'spring', stiffness: 260, damping: 25 }}
        style={windowStyle}
        className={`fixed z-50 flex flex-col select-none filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.9)] ${
          isDragging ? 'cursor-grabbing' : ''
        }`}
      >
        {/* Outer Chamfered Bevel Rim (draggable on touch & desktop) */}
        <div
          onPointerDown={startDrag}
          className={`poly-window-shell touch-none w-full h-full p-[3px] bg-gradient-to-b from-[#d4d4d4] via-[#8a8a8a] to-[#3a3a3a] flex flex-col ${
            isFullscreen ? 'cursor-default' : 'cursor-grab active:cursor-grabbing'
          }`}
        >
          <div className="poly-window-shell w-full h-full bg-gradient-to-b from-[#888888] via-[#666666] to-[#3c3c3c] flex flex-col overflow-hidden p-2 sm:p-3 gap-2">
            {/* DRAGGABLE TITLE BAR */}
            <div
              onDoubleClick={() => setIsFullscreen((prev) => !prev)}
              className={`poly-top-bar touch-none bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#626262] px-2.5 sm:px-5 py-2 sm:py-2.5 flex items-center justify-between gap-2 sm:gap-3 shrink-0 ${
                isFullscreen ? 'cursor-default' : 'cursor-grab active:cursor-grabbing'
              }`}
            >
              {/* Left Title Badge */}
              <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className="poly-inner-brand bg-gradient-to-b from-[#9c9c9c] via-[#7c7c7c] to-[#585858] px-3 sm:px-5 py-1 sm:py-1.5 flex items-center gap-2 shadow-md">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_8px_#fde047] shrink-0" />
                  <span className="font-chatopia text-xs sm:text-xl tracking-wider truncate">
                    CHATOPIA WEB
                  </span>
                </div>
                <span className="hidden md:inline-block font-chatopia text-xs sm:text-sm tracking-wider opacity-85 truncate">
                  {url.replace(/^https?:\/\//, '')}
                </span>
              </div>

              {/* Right Controls: Sync, Reload, Open, Minimize, Fullscreen, Close */}
              <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                {/* Account Sync & Persistence Drawer Button */}
                <button
                  type="button"
                  onClick={() => setShowSyncDrawer((prev) => !prev)}
                  title="Account Sync & Session Persistence"
                  aria-label="Синхронизация аккаунтов"
                  aria-expanded={showSyncDrawer}
                  className={`h-8 sm:h-9 px-2.5 sm:px-3 rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer shadow active:scale-95 ${
                    showSyncDrawer
                      ? 'bg-gradient-to-b from-[#695a22] to-[#3f3512] border-yellow-300/80'
                      : 'bg-gradient-to-b from-[#969696] to-[#5a5a5a] border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e]'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      storagePersisted !== false
                        ? 'bg-emerald-400 shadow-[0_0_6px_#34d399]'
                        : 'bg-yellow-300'
                    }`}
                  />
                  <span className="font-chatopia text-[11px] sm:text-sm tracking-wider leading-none">
                    SYNC
                  </span>
                </button>

                {/* Reload Iframe Button */}
                <button
                  type="button"
                  onClick={() => {
                    setIsLoading(true);
                    setIframeKey((k) => k + 1);
                  }}
                  title="Reload Web View"
                  aria-label="Перезагрузить веб-клиент"
                  className="w-8 h-8 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M21 12a9 9 0 1 1-2.64-6.36" />
                    <polyline points="21 3 21 9 15 9" />
                  </svg>
                </button>

                {/* Open in New Tab helper */}
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="Open in browser tab"
                  aria-label="Открыть в новой вкладке"
                  className="w-8 h-8 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                    <polyline points="15 3 21 3 21 9" />
                    <line x1="10" y1="14" x2="21" y2="3" />
                  </svg>
                </a>

                {/* Minimize Button */}
                <button
                  type="button"
                  onClick={() => onMinimizeChange(true)}
                  title="Minimize"
                  aria-label="Свернуть окно"
                  className="w-8 h-8 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    aria-hidden="true"
                  >
                    <line x1="5" y1="18" x2="19" y2="18" />
                  </svg>
                </button>

                {/* Fullscreen Toggle Button */}
                <button
                  type="button"
                  onClick={() => setIsFullscreen((prev) => !prev)}
                  title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
                  aria-label={
                    isFullscreen ? 'Выйти из полного экрана' : 'На весь экран'
                  }
                  className="w-8 h-8 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  {isFullscreen ? (
                    <svg
                      width="15"
                      height="15"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polyline points="4 14 10 14 10 20" />
                      <polyline points="20 10 14 10 14 4" />
                      <line x1="14" y1="10" x2="21" y2="3" />
                      <line x1="3" y1="21" x2="10" y2="14" />
                    </svg>
                  ) : (
                    <svg
                      width="15"
                      height="15"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <rect x="4" y="4" width="16" height="16" rx="2" />
                    </svg>
                  )}
                </button>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={handleCloseWindow}
                  title="Close"
                  aria-label="Закрыть окно"
                  className="w-8 h-8 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#a64b4b] to-[#632424] border border-white/40 hover:from-[#c45a5a] hover:to-[#7a2c2c] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    aria-hidden="true"
                  >
                    <line x1="6" y1="6" x2="18" y2="18" />
                    <line x1="18" y1="6" x2="6" y2="18" />
                  </svg>
                </button>
              </div>
            </div>

            {/* COLLAPSIBLE ACCOUNT SYNC & SESSION PERSISTENCE BAR */}
            <AnimatePresence>
              {showSyncDrawer && (
                <motion.div
                  data-no-drag="true"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.18 }}
                  className="overflow-hidden shrink-0"
                >
                  <div className="rounded-xl bg-gradient-to-b from-[#4c4c4c] to-[#2e2e2e] border border-white/25 p-3 space-y-2.5 cursor-default">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                          ACCOUNT SYNC & STORAGE ACCESS ENABLED
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <label className="flex items-center gap-1.5 cursor-pointer bg-black/35 px-2.5 py-1 rounded-lg border border-white/20">
                          <input
                            type="checkbox"
                            checked={keepSessionOnClose}
                            onChange={(e) =>
                              setKeepSessionOnClose(e.target.checked)
                            }
                            className="accent-yellow-400 w-3.5 h-3.5 cursor-pointer"
                          />
                          <span className="font-chatopia text-[11px] sm:text-xs tracking-wider uppercase">
                            KEEP SESSION ON CLOSE
                          </span>
                        </label>

                        <a
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="poly-inner-brand px-3 py-1 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868]"
                        >
                          <span className="font-chatopia text-[11px] sm:text-xs tracking-wider uppercase">
                            DIRECT TAB SYNC
                          </span>
                        </a>
                      </div>
                    </div>

                    {/* Save synced username bookmarks locally for fast account switching */}
                    <form
                      onSubmit={handleSaveAccount}
                      className="flex flex-wrap sm:flex-nowrap items-center gap-2"
                    >
                      <input
                        type="text"
                        value={accountInput}
                        onChange={(e) => setAccountInput(e.target.value)}
                        placeholder="Save synced username (e.g. Chickedream)"
                        aria-label="Сохранить никнейм синхронизированного аккаунта"
                        className="flex-1 min-w-[160px] bg-black/45 border border-white/25 rounded-lg px-3 py-1.5 text-xs sm:text-sm text-white placeholder:text-white/45 outline-none focus:border-yellow-300 font-sans select-text"
                      />
                      <button
                        type="submit"
                        className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#585858] hover:from-[#bcbcbc] hover:to-[#6a6a6a] cursor-pointer shrink-0"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                          SAVE ACCOUNT
                        </span>
                      </button>
                    </form>

                    {savedAccounts.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        {savedAccounts.map((acc) => (
                          <div
                            key={acc.id}
                            className="flex items-center gap-1 bg-black/45 border border-white/20 rounded-lg pl-2.5 pr-1 py-1"
                          >
                            <button
                              type="button"
                              onClick={() => handleCopyAccount(acc)}
                              title="Copy username to paste in login"
                              className="font-chatopia text-xs sm:text-sm tracking-wider hover:text-yellow-300 cursor-pointer"
                            >
                              {copiedId === acc.id
                                ? 'COPIED!'
                                : acc.username}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveAccount(acc.id)}
                              aria-label={`Удалить ${acc.username}`}
                              className="w-5 h-5 rounded flex items-center justify-center text-white/65 hover:text-red-300 hover:bg-white/10 cursor-pointer text-xs font-sans"
                            >
                              x
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* WEB VIEW BODY */}
            <div
              data-no-drag="true"
              className="relative flex-1 w-full rounded-xl overflow-hidden border-2 border-[#222222] bg-[#141414] shadow-inner cursor-default"
            >
              {isLoading && (
                <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-gradient-to-b from-[#5c5c5c] to-[#262626] gap-3 pointer-events-none">
                  <div className="w-10 h-10 rounded-lg border-2 border-white/80 border-t-transparent animate-spin" />
                  <span className="font-chatopia text-base sm:text-2xl tracking-wider text-center px-4">
                    LOADING CHATOPIA WEB...
                  </span>
                </div>
              )}

              <iframe
                key={iframeKey}
                src={url}
                title="Chatopia Web Revival"
                onLoad={() => setIsLoading(false)}
                referrerPolicy="strict-origin-when-cross-origin"
                allow="fullscreen; gamepad; autoplay; clipboard-read; clipboard-write; storage-access; identity-credentials-get"
                className={`w-full h-full border-0 bg-[#121212] ${
                  isDragging || isResizing ? 'pointer-events-none' : ''
                }`}
              />
            </div>

            {/* BOTTOM STATUS / RESIZE BAR */}
            <div className="touch-none flex items-center justify-between px-2 pt-0.5 text-xs opacity-85 shrink-0">
              <span className="font-chatopia tracking-wider text-[11px] sm:text-sm truncate pr-2">
                DRAG FRAME TO MOVE // SYNC SAVES ACCOUNTS &amp; SESSION
              </span>

              {!isFullscreen && (
                <div
                  data-no-drag="true"
                  onPointerDown={startResize}
                  title="Drag to resize window"
                  aria-label="Изменить размер окна"
                  className="touch-none w-9 h-9 -my-2 -mr-1 flex items-center justify-end cursor-nwse-resize p-1.5 shrink-0"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 16 16"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.2"
                    aria-hidden="true"
                  >
                    <line x1="14" y1="5" x2="5" y2="14" />
                    <line x1="14" y1="10" x2="10" y2="14" />
                  </svg>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
};
