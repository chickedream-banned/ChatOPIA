import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';

interface DraggableWebViewWindowProps {
  isOpen: boolean;
  isMinimized: boolean;
  onMinimizeChange: (minimized: boolean) => void;
  onClose: () => void;
  url?: string;
}

export const DraggableWebViewWindow: React.FC<DraggableWebViewWindowProps> = ({
  isOpen,
  isMinimized,
  onMinimizeChange,
  onClose,
  url = 'https://chatopiarbxrevival.netlify.app',
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const [bounds, setBounds] = useState(() => {
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1200;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
    const w = Math.min(Math.max(340, vw - 28), 960);
    const h = Math.min(Math.max(420, vh - 80), 650);
    return {
      x: Math.max(12, Math.round((vw - w) / 2)),
      y: Math.max(24, Math.round((vh - h) / 2)),
      width: w,
      height: h,
    };
  });

  const dragStateRef = useRef<{
    pointerId: number | null;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  }>({
    pointerId: null,
    startX: 0,
    startY: 0,
    originX: 0,
    originY: 0,
  });

  const resizeStateRef = useRef<{
    pointerId: number | null;
    startX: number;
    startY: number;
    originW: number;
    originH: number;
  }>({
    pointerId: null,
    startX: 0,
    startY: 0,
    originW: 0,
    originH: 0,
  });

  // Keep window within viewport on resize
  useEffect(() => {
    const handleViewportResize = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      setBounds((prev) => {
        const w = Math.min(prev.width, vw - 16);
        const h = Math.min(prev.height, vh - 24);
        const x = Math.max(8, Math.min(prev.x, vw - w - 8));
        const y = Math.max(8, Math.min(prev.y, vh - 64));
        return { x, y, width: Math.max(320, w), height: Math.max(300, h) };
      });
    };
    window.addEventListener('resize', handleViewportResize);
    return () => window.removeEventListener('resize', handleViewportResize);
  }, []);

  // Escape key exits fullscreen
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, isFullscreen]);

  const handleHeaderPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isFullscreen || isMinimized) return;
    if ((e.target as HTMLElement).closest('button, a')) return;
    if (!e.isPrimary || e.button !== 0) return;

    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStateRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originX: bounds.x,
      originY: bounds.y,
    };
    setIsDragging(true);
  };

  const handleHeaderPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStateRef.current.pointerId !== e.pointerId) return;
    const dx = e.clientX - dragStateRef.current.startX;
    const dy = e.clientY - dragStateRef.current.startY;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    setBounds((prev) => {
      const nextX = Math.max(
        8,
        Math.min(dragStateRef.current.originX + dx, vw - prev.width - 8)
      );
      const nextY = Math.max(
        8,
        Math.min(dragStateRef.current.originY + dy, vh - 64)
      );
      return { ...prev, x: nextX, y: nextY };
    });
  };

  const handleHeaderPointerEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (dragStateRef.current.pointerId !== e.pointerId) return;
    dragStateRef.current.pointerId = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setIsDragging(false);
  };

  const handleResizePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isFullscreen || isMinimized) return;
    if (!e.isPrimary || e.button !== 0) return;

    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    resizeStateRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      originW: bounds.width,
      originH: bounds.height,
    };
    setIsResizing(true);
  };

  const handleResizePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (resizeStateRef.current.pointerId !== e.pointerId) return;
    const dx = e.clientX - resizeStateRef.current.startX;
    const dy = e.clientY - resizeStateRef.current.startY;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    setBounds((prev) => {
      const nextW = Math.max(
        340,
        Math.min(resizeStateRef.current.originW + dx, vw - prev.x - 8)
      );
      const nextH = Math.max(
        300,
        Math.min(resizeStateRef.current.originH + dy, vh - prev.y - 8)
      );
      return { ...prev, width: nextW, height: nextH };
    });
  };

  const handleResizePointerEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    if (resizeStateRef.current.pointerId !== e.pointerId) return;
    resizeStateRef.current.pointerId = null;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setIsResizing(false);
  };

  if (!isOpen) return null;

  const windowStyle: React.CSSProperties = isFullscreen
    ? {
        top: 10,
        left: 10,
        right: 10,
        bottom: 10,
        width: 'calc(100vw - 20px)',
        height: 'calc(100vh - 20px)',
      }
    : {
        top: bounds.y,
        left: bounds.x,
        width: bounds.width,
        height: bounds.height,
      };

  return (
    <>
      {/* Minimized Floating Dock Bar */}
      <AnimatePresence>
        {isMinimized && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 280, damping: 24 }}
            className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)]"
          >
            <div className="poly-top-bar p-[2.5px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#424242]">
              <div className="poly-top-bar bg-gradient-to-b from-[#969696] via-[#767676] to-[#525252] px-5 sm:px-7 py-2.5 flex items-center gap-4 sm:gap-6">
                <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_10px_#fde047] animate-pulse shrink-0" />
                <span className="font-chatopia text-base sm:text-xl tracking-wider whitespace-nowrap">
                  CHATOPIA WEB
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onMinimizeChange(false)}
                    aria-label="Развернуть окно"
                    className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5e5e5e] hover:from-[#bcbcbc] hover:to-[#707070] cursor-pointer transition-transform active:scale-95"
                  >
                    <span className="font-chatopia text-sm sm:text-base tracking-wider">
                      RESTORE
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    aria-label="Закрыть окно"
                    className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#8c4646] to-[#522222] hover:from-[#a85454] hover:to-[#692b2b] cursor-pointer transition-transform active:scale-95"
                  >
                    <span className="font-chatopia text-sm sm:text-base tracking-wider">
                      X
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Draggable Window (kept mounted when minimized so iframe state is preserved) */}
      <motion.div
        role="dialog"
        aria-modal="false"
        aria-label="Chatopia Web Client"
        initial={{ opacity: 0, scale: 0.9, y: 24 }}
        animate={
          isMinimized
            ? {
                opacity: 0,
                scale: 0.65,
                y: 160,
                pointerEvents: 'none' as const,
              }
            : {
                opacity: 1,
                scale: 1,
                y: 0,
                pointerEvents: 'auto' as const,
              }
        }
        transition={{ type: 'spring', stiffness: 260, damping: 25 }}
        style={windowStyle}
        className={`fixed z-50 flex flex-col select-none filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.9)] ${
          isDragging ? 'cursor-grabbing' : ''
        }`}
      >
        {/* Outer Chamfered Bevel Rim */}
        <div className="poly-window-shell w-full h-full p-[3px] bg-gradient-to-b from-[#d4d4d4] via-[#8a8a8a] to-[#3a3a3a] flex flex-col">
          <div className="poly-window-shell w-full h-full bg-gradient-to-b from-[#888888] via-[#666666] to-[#3c3c3c] flex flex-col overflow-hidden p-2 sm:p-3 gap-2">
            {/* DRAGGABLE TITLE BAR */}
            <div
              onPointerDown={handleHeaderPointerDown}
              onPointerMove={handleHeaderPointerMove}
              onPointerUp={handleHeaderPointerEnd}
              onPointerCancel={handleHeaderPointerEnd}
              onLostPointerCapture={handleHeaderPointerEnd}
              onDoubleClick={() => setIsFullscreen((prev) => !prev)}
              className={`poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#626262] px-3 sm:px-5 py-2 sm:py-2.5 flex items-center justify-between gap-3 shrink-0 ${
                isFullscreen ? 'cursor-default' : 'cursor-grab active:cursor-grabbing'
              }`}
            >
              {/* Left Title Badge */}
              <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                <div className="poly-inner-brand bg-gradient-to-b from-[#9c9c9c] via-[#7c7c7c] to-[#585858] px-3.5 sm:px-5 py-1 sm:py-1.5 flex items-center gap-2 shadow-md">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_8px_#fde047] shrink-0" />
                  <span className="font-chatopia text-sm sm:text-xl tracking-wider truncate">
                    CHATOPIA WEB
                  </span>
                </div>
                <span className="hidden md:inline-block font-chatopia text-xs sm:text-sm tracking-wider opacity-85 truncate">
                  chatopiarbxrevival.netlify.app
                </span>
              </div>

              {/* Right Controls: Reload, Minimize, Fullscreen, Close */}
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
                {/* Reload Iframe Button */}
                <button
                  type="button"
                  onClick={() => {
                    setIsLoading(true);
                    setIframeKey((k) => k + 1);
                  }}
                  title="Reload Web View"
                  aria-label="Перезагрузить веб-клиент"
                  className="w-9 h-9 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M21 12a9 9 0 1 1-2.64-6.36" />
                    <polyline points="21 3 21 9 15 9" />
                  </svg>
                </button>

                {/* Open in New Tab helper */}
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="Open in browser tab"
                  aria-label="Открыть в новой вкладке"
                  className="w-9 h-9 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                    <polyline points="15 3 21 3 21 9" />
                    <line x1="10" y1="14" x2="21" y2="3" />
                  </svg>
                </a>

                {/* Minimize Button */}
                <button
                  type="button"
                  onClick={() => onMinimizeChange(true)}
                  title="Minimize"
                  aria-label="Свернуть окно"
                  className="w-9 h-9 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    aria-hidden="true"
                  >
                    <line x1="5" y1="18" x2="19" y2="18" />
                  </svg>
                </button>

                {/* Fullscreen Toggle Button */}
                <button
                  type="button"
                  onClick={() => setIsFullscreen((prev) => !prev)}
                  title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
                  aria-label={
                    isFullscreen ? 'Выйти из полного экрана' : 'На весь экран'
                  }
                  className="w-9 h-9 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#969696] to-[#5a5a5a] border border-white/35 hover:from-[#b0b0b0] hover:to-[#6e6e6e] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  {isFullscreen ? (
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <polyline points="4 14 10 14 10 20" />
                      <polyline points="20 10 14 10 14 4" />
                      <line x1="14" y1="10" x2="21" y2="3" />
                      <line x1="3" y1="21" x2="10" y2="14" />
                    </svg>
                  ) : (
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <rect x="4" y="4" width="16" height="16" rx="2" />
                    </svg>
                  )}
                </button>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => {
                    setIsFullscreen(false);
                    onClose();
                  }}
                  title="Close"
                  aria-label="Закрыть окно"
                  className="w-9 h-9 sm:w-10 sm:h-9 rounded-lg bg-gradient-to-b from-[#a64b4b] to-[#632424] border border-white/40 hover:from-[#c45a5a] hover:to-[#7a2c2c] active:scale-95 transition-all flex items-center justify-center cursor-pointer shadow"
                >
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    aria-hidden="true"
                  >
                    <line x1="6" y1="6" x2="18" y2="18" />
                    <line x1="18" y1="6" x2="6" y2="18" />
                  </svg>
                </button>
              </div>
            </div>

            {/* WEB VIEW BODY */}
            <div className="relative flex-1 w-full rounded-xl overflow-hidden border-2 border-[#222222] bg-[#141414] shadow-inner">
              {isLoading && (
                <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-gradient-to-b from-[#5c5c5c] to-[#262626] gap-3 pointer-events-none">
                  <div className="w-10 h-10 rounded-lg border-2 border-white/80 border-t-transparent animate-spin" />
                  <span className="font-chatopia text-lg sm:text-2xl tracking-wider">
                    LOADING CHATOPIA WEB...
                  </span>
                </div>
              )}

              <iframe
                key={iframeKey}
                src={url}
                title="Chatopia Web Revival"
                onLoad={() => setIsLoading(false)}
                allow="fullscreen; gamepad; autoplay; clipboard-read; clipboard-write"
                className={`w-full h-full border-0 bg-[#121212] ${
                  isDragging || isResizing ? 'pointer-events-none' : ''
                }`}
              />
            </div>

            {/* BOTTOM STATUS / RESIZE BAR */}
            <div className="flex items-center justify-between px-2 pt-0.5 text-xs opacity-80 shrink-0">
              <span className="font-chatopia tracking-wider text-xs sm:text-sm">
                DRAG TOP BAR TO MOVE // DOUBLE-CLICK TOP BAR FOR FULLSCREEN
              </span>

              {!isFullscreen && (
                <div
                  onPointerDown={handleResizePointerDown}
                  onPointerMove={handleResizePointerMove}
                  onPointerUp={handleResizePointerEnd}
                  onPointerCancel={handleResizePointerEnd}
                  onLostPointerCapture={handleResizePointerEnd}
                  title="Drag to resize window"
                  className="w-6 h-6 flex items-end justify-end cursor-nwse-resize p-0.5"
                >
                  <svg
                    width="14"
                    height="14"
                    viewBox="0 0 16 16"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    aria-hidden="true"
                  >
                    <line x1="14" y1="6" x2="6" y2="14" />
                    <line x1="14" y1="11" x2="11" y2="14" />
                  </svg>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
};
