export type SiteLang = 'en' | 'ru';
export type FontMode = 'oldroblox' | 'boblox';

export interface SiteTranslations {
  pageTitle: string;
  brandTitle: string;
  brandSubtitle: string;
  navAria: string;
  navMain: string;
  navCredits: string;
  heroTitle: string;
  heroDesc: string;
  platformsLabel: string;
  platforms: readonly [string, string, string];
  tryWeb: string;
  telegramAria: string;
  telegramTitle: string;
  discordAria: string;
  discordTitle: string;
  creditsHeading: string;
  founderRole: string;
  builderRole: string;
  contactBtn: string;
  openContactAria: string;
  downloadHeading: string;
  itchHeader: string;
  itchOpen: string;
  itchTitle: string;
  gameJoltHeader: string;
  gameJoltOpen: string;
  gameJoltTitle: string;
  placeTag: string;
  placeAuthor: string;
  openPlaceAriaPrefix: string;
  places: {
    chattingZone: string;
    sfoth: string;
  };
  close: string;
  contactTitle: string;
  contactDialogAria: string;
  tiktokLabel: string;
  copyBtn: string;
  copyOneBtn: string;
  copyTwoBtn: string;
  copyEmailBtn: string;
  copiedBtn: string;
  telegramLabel: string;
  youtubeLabel: string;
  emailLabel: string;
  robloxLabel: string;
  countryLabel: string;
  countryValue: string;
  footerCopyright: string;
  footerTrademarks: string;
  viewportLoading: string;
  viewportPaused: string;
  viewportAria: string;
  langControlsAria: string;
  englishBtnAria: string;
  russianBtnAria: string;
  fontToggleAria: string;
  fontToggleTitleOld: string;
  fontToggleTitleBoblox: string;
  webView: {
    windowAria: string;
    title: string;
    restore: string;
    restoreAria: string;
    closeAria: string;
    syncBtn: string;
    syncAria: string;
    syncTitle: string;
    reloadAria: string;
    reloadTitle: string;
    openTabAria: string;
    openTabTitle: string;
    minimizeAria: string;
    minimizeTitle: string;
    fullscreenAria: string;
    exitFullscreenAria: string;
    fullscreenTitle: string;
    exitFullscreenTitle: string;
    syncStatusEnabled: string;
    keepSession: string;
    directTabSync: string;
    accountPlaceholder: string;
    accountInputAria: string;
    saveAccount: string;
    copyUsernameTitle: string;
    copied: string;
    removePrefix: string;
    loading: string;
    iframeTitle: string;
    footerHint: string;
    resizeAria: string;
    resizeTitle: string;
  };
  infoCredits: {
    btnLabel: string;
    btnAria: string;
    modalTitle: string;
    dialogAria: string;
    introPrefix: string;
    introTeam: string;
    plannedText: string;
    plannedYear: string;
    releasedText: string;
    releasedYear: string;
    devsLabel: string;
    devOne: string;
    devTwo: string;
    engineLabel: string;
    engineValue: string;
    androidNotePrefix: string;
    androidNoteHighlight: string;
    platformsPrefix: string;
    platformsList: readonly [string, string, string, string];
    platformsAnd: string;
    platformsFakeWarning: string;
    copyright: string;
    tipLabel: string;
    tipPrefix: string;
    tipHighlight: string;
    tipSuffix: string;
    feedbackPrefix: string;
    feedbackEmail: string;
    copycatText: string;
    copycatHighlight: string;
    unpackText: string;
  };
}

export const TRANSLATIONS: Record<SiteLang, SiteTranslations> = {
  en: {
    pageTitle: 'CHATOPIA / Roblox Revival',
    brandTitle: 'CHATOPIA /',
    brandSubtitle: 'ROBLOX REVIVAL',
    navAria: 'Main navigation',
    navMain: 'MAIN',
    navCredits: 'CREDITS',
    heroTitle: 'FEEL THE NOSTALGIA.',
    heroDesc:
      'The best roblox revival on NewCatroid And Web (prolly). Play with friends, siblings, anywhere.',
    platformsLabel: 'Available Platforms:',
    platforms: ['Android', 'Web', 'J2ME'],
    tryWeb: 'TRY WEB',
    telegramAria: 'Open Chatopia Telegram Channel',
    telegramTitle: 'Telegram: @awesome_chatopians',
    discordAria: 'Open Chatopia Discord Server',
    discordTitle: 'Discord: discord.gg/yxdCVChqy',
    creditsHeading: 'CREDITS',
    founderRole: 'FOUNDER / LEAD DEVELOPER',
    builderRole: 'DEVELOPER / PLACE BUILDER',
    contactBtn: 'CONTACT',
    openContactAria: 'Open Chickedream Contact Menu',
    downloadHeading: 'DOWNLOAD CHATOPIA',
    itchHeader: 'ITCH.IO // ANDROID & CLIENT',
    itchOpen: 'OPEN ITCH.IO',
    itchTitle: 'ChatOpia — Android Roblox Revival by Chickedream on Itch.io',
    gameJoltHeader: 'GAME JOLT // OFFICIAL PACKAGE',
    gameJoltOpen: 'OPEN GAME JOLT',
    gameJoltTitle: 'ChatOpia Game Jolt Package',
    placeTag: 'PLACE',
    placeAuthor: 'BY THEMAINCHATTER',
    openPlaceAriaPrefix: 'Open',
    places: {
      chattingZone: 'THE CHATTING ZONE',
      sfoth: 'SFOTH',
    },
    close: 'CLOSE',
    contactTitle: 'CONTACT // CHICKEDREAM',
    contactDialogAria: 'Contact Chickedream',
    tiktokLabel: 'TIKTOK (2 ACCOUNTS)',
    copyBtn: 'COPY',
    copyOneBtn: 'COPY #1',
    copyTwoBtn: 'COPY #2',
    copyEmailBtn: 'COPY EMAIL',
    copiedBtn: 'COPIED',
    telegramLabel: 'TELEGRAM',
    youtubeLabel: 'YOUTUBE',
    emailLabel: 'EMAIL',
    robloxLabel: 'ROBLOX',
    countryLabel: 'COUNTRY',
    countryValue: 'UKRAINE',
    footerCopyright: '2025\u20132026 ChatOPIA Revivals LLC. All rights reserved.',
    footerTrademarks:
      'All third-party trademarks, logos, and brand names are the property of their respective owners.',
    viewportLoading: 'LOADING...',
    viewportPaused: 'WEBGL PAUSED',
    viewportAria: 'ChatOPIA 3D Player',
    langControlsAria: 'Language and font switcher',
    englishBtnAria: 'Switch site language to English',
    russianBtnAria: 'Switch site language to Russian',
    fontToggleAria: 'Toggle BobloxClassicCyrillic font',
    fontToggleTitleOld: 'Switch everywhere to BobloxClassicCyrillic font',
    fontToggleTitleBoblox: 'Switch back to OldRobloxFontCyrillic font',
    webView: {
      windowAria: 'Chatopia Web Client',
      title: 'CHATOPIA WEB',
      restore: 'RESTORE',
      restoreAria: 'Restore window',
      closeAria: 'Close window',
      syncBtn: 'SYNC',
      syncAria: 'Account sync',
      syncTitle: 'Account Sync & Session Persistence',
      reloadAria: 'Reload web client',
      reloadTitle: 'Reload Web View',
      openTabAria: 'Open in new tab',
      openTabTitle: 'Open in browser tab',
      minimizeAria: 'Minimize window',
      minimizeTitle: 'Minimize',
      fullscreenAria: 'Fullscreen',
      exitFullscreenAria: 'Exit fullscreen',
      fullscreenTitle: 'Fullscreen',
      exitFullscreenTitle: 'Exit Fullscreen',
      syncStatusEnabled: 'ACCOUNT SYNC & STORAGE ACCESS ENABLED',
      keepSession: 'KEEP SESSION ON CLOSE',
      directTabSync: 'DIRECT TAB SYNC',
      accountPlaceholder: 'Save synced username (e.g. Chickedream)',
      accountInputAria: 'Save synced account username',
      saveAccount: 'SAVE ACCOUNT',
      copyUsernameTitle: 'Copy username to paste in login',
      copied: 'COPIED!',
      removePrefix: 'Remove',
      loading: 'LOADING CHATOPIA WEB...',
      iframeTitle: 'Chatopia Web Revival',
      footerHint: 'DRAG FRAME TO MOVE // SYNC SAVES ACCOUNTS & SESSION',
      resizeAria: 'Resize window',
      resizeTitle: 'Drag to resize window',
    },
    infoCredits: {
      btnLabel: "InfoN'Credits",
      btnAria: "Open InfoN'Credits modal",
      modalTitle: "InfoN'Credits",
      dialogAria: "InfoN'Credits",
      introPrefix: 'ChatOPIA is a Roblox Revival, that was originally made by',
      introTeam: 'FemDream Team',
      plannedText: 'ChatOPIA first was planned at',
      plannedYear: '2025',
      releasedText: 'ChatOpia first was publicly released at',
      releasedYear: '2026',
      devsLabel: "Official Dev's:",
      devOne: 'Chickedream',
      devTwo: 'TheMainChatter',
      engineLabel: 'Main Game Engine:',
      engineValue: 'NewCatroid By Danveyd',
      androidNotePrefix: 'The game are developed using an',
      androidNoteHighlight: 'Android-based development environment.',
      platformsPrefix: 'ChatOPIA is officially only on those 4 platforms:',
      platformsList: ['Gamejolt', 'itch', 'our telegramm channel', 'chatopia.fun'],
      platformsAnd: ', and',
      platformsFakeWarning:
        "Don't download ChatOPIA from any other source \u2014 it's fake.",
      copyright: '2026 FemDream Team. All Rights Reserved.',
      tipLabel: 'Tip:',
      tipPrefix: "We don't collect",
      tipHighlight: 'ANY data',
      tipSuffix: 'from users to sell it to any other companies or services',
      feedbackPrefix: 'To send a feedback, or contact us \u2014 please, send a mail to',
      feedbackEmail: 'chickedream@gmail.com',
      copycatText:
        'We have right to request deleting the copy of our game without any credit to us.',
      copycatHighlight: '',
      unpackText:
        "Unpacking the project \u2014 is not allowed, you will be banned in the game and ChatOPIA's socials, or else talk with us.",
    },
  },
  ru: {
    pageTitle: 'ЧАТОПИЯ / Ревайвл Роблокса',
    brandTitle: 'ЧАТОПИЯ /',
    brandSubtitle: 'РЕВАЙВЛ РОБЛОКСА',
    navAria: 'Основная навигация',
    navMain: 'ГЛАВНАЯ',
    navCredits: 'РАЗРАБЫ',
    heroTitle: 'ЛОВИ ОЛДСКУЛ И НОСТАЛЬГИЮ.',
    heroDesc:
      'Топовый ревайвл роблокса на NewCatroid и в вебе - походу. Залетай с кентами и братанами, откуда угодно.',
    platformsLabel: 'ГДЕ ЗАПУСТИТЬ:',
    platforms: ['Android', 'Веб', 'J2ME'],
    tryWeb: 'ИГРАТЬ В ВЕБЕ',
    telegramAria: 'Открыть Телеграм-канал Чатопии',
    telegramTitle: 'Телега: @awesome_chatopians',
    discordAria: 'Залететь на Дискорд-сервер Чатопии',
    discordTitle: 'Дискорд: discord.gg/yxdCVChqy',
    creditsHeading: 'Разрабы:',
    founderRole: 'БАТЯ ПРОЕКТА / ОСНОВНОЙ КОДЕР',
    builderRole: 'КОДЕР / БИЛДЕР ПЛЕЙСОВ',
    contactBtn: 'СВЯЗЬ',
    openContactAria: 'Открыть контакты Chickedream',
    downloadHeading: 'СКАЧАТЬ ЧАТОПИЮ',
    itchHeader: 'ITCH.IO // АНДРОИД И КЛИЕНТ',
    itchOpen: 'НА ITCH.IO',
    itchTitle: 'ChatOpia — мобильный ревайвл роблокса от Chickedream на Itch.io',
    gameJoltHeader: 'GAME JOLT // ОФИЦИАЛЬНЫЙ БИЛД',
    gameJoltOpen: 'НА GAME JOLT',
    gameJoltTitle: 'Билд ChatOpia на Game Jolt',
    placeTag: 'ПЛЕЙС',
    placeAuthor: 'ОТ THEMAINCHATTER',
    openPlaceAriaPrefix: 'Открыть плейс',
    places: {
      chattingZone: 'Чаттинг зон',
      sfoth: 'SFOTH',
    },
    close: 'ЗАКРЫТЬ',
    contactTitle: 'КОНТАКТЫ // CHICKEDREAM',
    contactDialogAria: 'Контакты Chickedream',
    tiktokLabel: 'ТИКТОК - 2 АККА',
    copyBtn: 'КОПИРНУТЬ',
    copyOneBtn: 'КОПИЯ #1',
    copyTwoBtn: 'КОПИЯ #2',
    copyEmailBtn: 'КОПИЯ ПОЧТЫ',
    copiedBtn: 'В БУФЕРЕ!',
    telegramLabel: 'ТЕЛЕГРАМ',
    youtubeLabel: 'ЮТУБ',
    emailLabel: 'ПОЧТА',
    robloxLabel: 'РОБЛОКС',
    countryLabel: 'СТРАНА',
    countryValue: 'УКРАИНА',
    footerCopyright: '2025\u20132026 ChatOPIA Revivals LLC. Все права защищены.',
    footerTrademarks:
      'Все сторонние товарные знаки, логотипы и названия брендов принадлежат их законным владельцам.',
    viewportLoading: 'ГРУЗИМ СЦЕНУ...',
    viewportPaused: 'WEBGL НА ПАУЗЕ',
    viewportAria: '3D-модель игрока Чатопии',
    langControlsAria: 'Переключатель языка и шрифта',
    englishBtnAria: 'Переключить сайт на английский',
    russianBtnAria: 'Переключить сайт на русский со сленгом',
    fontToggleAria: 'Переключить шрифт на BobloxClassicCyrillic и обратно',
    fontToggleTitleOld: 'Врубить везде шрифт BobloxClassicCyrillic',
    fontToggleTitleBoblox: 'Вернуть шрифт OldRobloxFontCyrillic',
    webView: {
      windowAria: 'Веб-клиент Чатопии',
      title: 'ЧАТОПИЯ ВЕБ',
      restore: 'ВЕРНУТЬ',
      restoreAria: 'Развернуть окно',
      closeAria: 'Закрыть окно',
      syncBtn: 'СИНХРА',
      syncAria: 'Синхронизация аккаунтов',
      syncTitle: 'Синхронизация акков и сохранение сессии',
      reloadAria: 'Перезагрузить веб-клиент',
      reloadTitle: 'Обновить веб-клиент',
      openTabAria: 'Открыть в новой вкладке',
      openTabTitle: 'Открыть в отдельной вкладке браузера',
      minimizeAria: 'Свернуть окно',
      minimizeTitle: 'Свернуть',
      fullscreenAria: 'На весь экран',
      exitFullscreenAria: 'Выйти из полного экрана',
      fullscreenTitle: 'На весь экран',
      exitFullscreenTitle: 'Свернуть из фуллскрина',
      syncStatusEnabled: 'СИНХРА АККОВ И ПАМЯТЬ ВКЛЮЧЕНЫ',
      keepSession: 'ДЕРЖАТЬ СЕССИЮ ПОСЛЕ ЗАКРЫТИЯ',
      directTabSync: 'ПРЯМАЯ ВКЛАДКА',
      accountPlaceholder: 'Запомнить ник, напр. Chickedream',
      accountInputAria: 'Сохранить никнейм синхронизированного аккаунта',
      saveAccount: 'СОХРАНИТЬ АКК',
      copyUsernameTitle: 'Скопировать ник для быстрого входа',
      copied: 'В БУФЕРЕ!',
      removePrefix: 'Удалить',
      loading: 'ЗАГРУЖАЕМ ЧАТОПИЮ ВЕБ...',
      iframeTitle: 'Веб-клиент Chatopia Revival',
      footerHint: 'ТАЩИ ЗА РАМКУ // СИНХРА ДЕРЖИТ АККИ И СЕССИЮ',
      resizeAria: 'Изменить размер окна',
      resizeTitle: 'Тяни за угол, чтобы менять размер',
    },
    infoCredits: {
      btnLabel: 'Инфа и Кредиты',
      btnAria: 'Открыть окно Инфа и Кредиты',
      modalTitle: 'Инфа и Кредиты',
      dialogAria: 'Инфа и Кредиты',
      introPrefix: 'Чатопия это Роблокс Ревайвл, который был оригинально сделан командой',
      introTeam: 'FemDream',
      plannedText: 'Чатопия планировалась еще в',
      plannedYear: '2025 году',
      releasedText: 'А впервые вышла публично Чатопия в',
      releasedYear: '2026',
      devsLabel: 'Официальные разрабы:',
      devOne: 'Chickedream',
      devTwo: 'TheMainChatter',
      engineLabel: 'Основной игровой движок:',
      engineValue: 'NewCatroid By Danveyd, Веб, J2ME',
      androidNotePrefix: 'Игра разработана на',
      androidNoteHighlight: 'движке под Андроиды.',
      platformsPrefix: 'Чатопия официально есть только на этих платформах:',
      platformsList: ['Gamejolt', 'itch', 'наш Телеграм канал', 'chatopia.fun'],
      platformsAnd: ', и',
      platformsFakeWarning:
        'Не скачивайте Чатопию из любого другого автора или источника \u2014 вероятно это фейк.',
      copyright: '2026 FemDream Team. Все права защищены.',
      tipLabel: 'Приметка:',
      tipPrefix: 'Мы не крадем и не продаем',
      tipHighlight: 'ваши данные',
      tipSuffix: 'другим компаниям или третьим лицам',
      feedbackPrefix: 'Оставить отзыв, или связатся с нами \u2014 отправьте имейл на',
      feedbackEmail: 'chickedream@gmail.com',
      copycatText:
        'Мы имеем правило попросить удалить копирку нашей игры без упоминания создателей',
      copycatHighlight: '(В ПЛАНЕ УКРАДЕННЫХ АССЕТОВ)',
      unpackText:
        'Распакование проекта \u2014 не разрешено, вы будете забанены в нашей игре, и в наших социальных сетях. Либо проведем разговор.',
    },
  },
};
