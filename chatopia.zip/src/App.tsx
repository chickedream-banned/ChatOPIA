import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AnimatePresence,
  motion,
  useScroll,
  useSpring,
  useTransform,
} from 'motion/react';
import { CharacterViewport3D } from './components/CharacterViewport3D';
import { DraggableWebViewWindow } from './components/DraggableWebViewWindow';
import { ParticleFieldVfx } from './components/ParticleFieldVfx';
import { TRANSLATIONS, type FontMode, type SiteLang } from './i18n';
import { SoundEffectsController } from './utils/soundEffects';

interface GameScreenItem {
  id: string;
  title: string;
  author: string;
  imageUrl: string;
}

const LANG_STORAGE_KEY = 'chatopia_lang_v1';
const FONT_STORAGE_KEY = 'chatopia_font_v1';

export default function App() {
  const scrollProgressRef = useRef<number>(0);
  const { scrollYProgress } = useScroll();
  const smoothScroll = useSpring(scrollYProgress, {
    stiffness: 85,
    damping: 24,
    restDelta: 0.001,
  });

  // Parallax & Scroll-linked VFX transforms
  const leftColumnY = useTransform(smoothScroll, [0, 0.4], [0, -28]);
  const rightAvatarY = useTransform(smoothScroll, [0, 0.4], [0, -14]);
  const ambientGlowY = useTransform(smoothScroll, [0, 1], ['0%', '35%']);
  const creditsScale = useTransform(smoothScroll, [0.12, 0.42], [0.95, 1]);

  const [lang, setLang] = useState<SiteLang>(() => {
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY);
      return saved === 'ru' ? 'ru' : 'en';
    } catch {
      return 'en';
    }
  });

  const [fontMode, setFontMode] = useState<FontMode>(() => {
    try {
      const saved = localStorage.getItem(FONT_STORAGE_KEY);
      return saved === 'boblox' ? 'boblox' : 'oldroblox';
    } catch {
      return 'oldroblox';
    }
  });

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    document.documentElement.dataset.font = fontMode;
    try {
      localStorage.setItem(FONT_STORAGE_KEY, fontMode);
    } catch {
      // Ignore storage write errors
    }
  }, [fontMode]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.title = t.pageTitle;
    try {
      localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      // Ignore storage write errors
    }
  }, [lang, t.pageTitle]);

  const featuredScreens: GameScreenItem[] = useMemo(
    () => [
      {
        id: 'chatting-zone',
        title: t.places.chattingZone,
        author: t.placeAuthor,
        imageUrl: '/Screenshot_20261108_010904.png',
      },
      {
        id: 'sfoth',
        title: t.places.sfoth,
        author: t.placeAuthor,
        imageUrl: '/Screenshot_20261108_010922.png',
      },
    ],
    [t.placeAuthor, t.places.chattingZone, t.places.sfoth]
  );

  useEffect(() => {
    const unsubscribe = smoothScroll.on('change', (val) => {
      scrollProgressRef.current = val;
    });
    return () => unsubscribe();
  }, [smoothScroll]);

  useEffect(() => {
    const sfx = new SoundEffectsController();
    return () => sfx.dispose();
  }, []);

  const [previewScreenId, setPreviewScreenId] = useState<string | null>(null);
  const previewScreen = useMemo(
    () =>
      previewScreenId
        ? featuredScreens.find((item) => item.id === previewScreenId) ?? null
        : null,
    [featuredScreens, previewScreenId]
  );
  const [isWebViewOpen, setIsWebViewOpen] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem('chatopia_webview_session_v1');
      if (!raw) return false;
      const parsed = JSON.parse(raw) as { open?: boolean };
      return parsed.open === true;
    } catch {
      return false;
    }
  });
  const [isWebViewMinimized, setIsWebViewMinimized] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem('chatopia_webview_session_v1');
      if (!raw) return false;
      const parsed = JSON.parse(raw) as { minimized?: boolean };
      return parsed.minimized === true;
    } catch {
      return false;
    }
  });
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);

  useEffect(() => {
    if (!isInfoOpen && !isContactOpen && !previewScreenId) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsInfoOpen(false);
        setIsContactOpen(false);
        setPreviewScreenId(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isInfoOpen, isContactOpen, previewScreenId]);

  useEffect(() => {
    try {
      localStorage.setItem(
        'chatopia_webview_session_v1',
        JSON.stringify({ open: isWebViewOpen, minimized: isWebViewMinimized })
      );
    } catch {
      // Ignore storage write errors
    }
  }, [isWebViewOpen, isWebViewMinimized]);

  const handleCopyText = (text: string, label: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setCopiedLabel(label);
    window.setTimeout(() => {
      setCopiedLabel((prev) => (prev === label ? null : prev));
    }, 1800);
  };

  const handleOpenWebView = () => {
    setIsWebViewOpen(true);
    setIsWebViewMinimized(false);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-[#747474] via-[#262626] via-45% to-[#030303] text-white flex flex-col overflow-x-hidden">
      {/* Top Scroll Progress Laser Line */}
      <motion.div
        style={{ scaleX: smoothScroll }}
        className="fixed top-0 left-0 right-0 h-1 origin-left z-40 bg-gradient-to-r from-[#d4d4d4] via-[#ffffff] to-[#fde047] shadow-[0_0_14px_rgba(255,255,255,0.85)]"
      />

      {/* TOP-LEFT FLOATING SIGNATURE FRAME: English-Lang.png | Russian-Lang.png | С (Font Toggle) */}
      <motion.aside
        initial={{ opacity: 0, x: -20, y: -12 }}
        animate={{ opacity: 1, x: 0, y: 0 }}
        transition={{ type: 'spring', stiffness: 190, damping: 22 }}
        aria-label={t.langControlsAria}
        className="fixed top-2.5 left-2.5 sm:top-3.5 sm:left-3.5 z-50 filter drop-shadow-[0_10px_18px_rgba(0,0,0,0.82)]"
      >
        <div className="poly-inner-brand p-[2px] bg-gradient-to-b from-[#dcdcdc] via-[#8c8c8c] to-[#3c3c3c]">
          <div className="poly-inner-brand bg-gradient-to-b from-[#969696] via-[#767676] to-[#505050] px-2.5 sm:px-3 py-1.5 flex items-center gap-1.5 sm:gap-2">
            {/* English Language Icon Button */}
            <button
              type="button"
              onClick={() => setLang('en')}
              aria-label={t.englishBtnAria}
              aria-pressed={lang === 'en'}
              title="English"
              className={`poly-chamfer-sm min-h-[34px] p-[1.5px] transition-all cursor-pointer active:scale-95 flex items-center justify-center ${
                lang === 'en'
                  ? 'bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-600 shadow-[0_0_10px_rgba(253,224,71,0.45)]'
                  : 'bg-white/20 opacity-80 hover:opacity-100 hover:bg-white/40'
              }`}
            >
              <span
                className={`poly-chamfer-sm px-1.5 py-0.5 flex items-center justify-center ${
                  lang === 'en'
                    ? 'bg-[#36321f]'
                    : 'bg-[#5a5a5a] hover:bg-[#4c4c4c]'
                }`}
              >
                <img
                  src="/English-Lang.png"
                  alt="English"
                  draggable={false}
                  className="h-6 sm:h-7 w-auto object-contain select-none"
                />
              </span>
            </button>

            {/* Russian Language Icon Button (right of English) */}
            <button
              type="button"
              onClick={() => setLang('ru')}
              aria-label={t.russianBtnAria}
              aria-pressed={lang === 'ru'}
              title="Русский"
              className={`poly-chamfer-sm min-h-[34px] p-[1.5px] transition-all cursor-pointer active:scale-95 flex items-center justify-center ${
                lang === 'ru'
                  ? 'bg-gradient-to-b from-yellow-200 via-yellow-400 to-amber-600 shadow-[0_0_10px_rgba(253,224,71,0.45)]'
                  : 'bg-white/20 opacity-80 hover:opacity-100 hover:bg-white/40'
              }`}
            >
              <span
                className={`poly-chamfer-sm px-1.5 py-0.5 flex items-center justify-center ${
                  lang === 'ru'
                    ? 'bg-[#36321f]'
                    : 'bg-[#5a5a5a] hover:bg-[#4c4c4c]'
                }`}
              >
                <img
                  src="/Russian-Lang.png"
                  alt="Русский"
                  draggable={false}
                  className="h-6 sm:h-7 w-auto object-contain select-none"
                />
              </span>
            </button>

            {/* Font Toggle Button "С" (right of Russian, toggles BobloxClassicCyrillic <-> OldRobloxFontCyrillic) */}
            <button
              type="button"
              onClick={() =>
                setFontMode((prev) =>
                  prev === 'oldroblox' ? 'boblox' : 'oldroblox'
                )
              }
              aria-label={t.fontToggleAria}
              aria-pressed={fontMode === 'boblox'}
              title={
                fontMode === 'boblox'
                  ? t.fontToggleTitleBoblox
                  : t.fontToggleTitleOld
              }
              className={`poly-square-btn min-w-[36px] min-h-[34px] sm:min-w-[40px] sm:min-h-[36px] p-[2px] cursor-pointer transition-transform hover:scale-105 active:scale-95 flex items-center justify-center ${
                fontMode === 'boblox'
                  ? 'bg-gradient-to-b from-[#fef08a] via-[#eab308] to-[#854d0e]'
                  : 'bg-gradient-to-b from-[#e4e4e4] via-[#9c9c9c] to-[#464646]'
              }`}
            >
              <div
                className={`poly-square-btn w-full h-full px-2 py-0.5 flex items-center justify-center ${
                  fontMode === 'boblox'
                    ? 'bg-gradient-to-b from-[#695a22] via-[#4a3f17] to-[#2e260c]'
                    : 'bg-gradient-to-b from-[#a2a2a2] via-[#7c7c7c] to-[#525252]'
                }`}
              >
                <span
                  className={`${
                    fontMode === 'boblox'
                      ? 'font-chatopia-gold'
                      : 'font-chatopia'
                  } text-lg sm:text-xl leading-none select-none`}
                >
                  С
                </span>
              </div>
            </button>
          </div>
        </div>
      </motion.aside>

      {/* Ambient Floating Volumetric Glow Orbs */}
      <motion.div
        aria-hidden="true"
        style={{ y: ambientGlowY }}
        className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      >
        <div className="absolute -top-28 left-1/4 w-[28rem] h-[28rem] rounded-full bg-white/[0.07] blur-[110px]" />
        <div className="absolute top-[38%] right-[10%] w-[24rem] h-[24rem] rounded-full bg-[#d4d4d4]/[0.06] blur-[120px]" />
        <div className="absolute top-[55%] left-1/2 -translate-x-1/2 w-[30rem] h-[18rem] rounded-full bg-yellow-400/[0.06] blur-[130px]" />
      </motion.div>

      {/* Interactive Retro Particle & Stud VFX Canvas */}
      <ParticleFieldVfx
        scrollProgressRef={scrollProgressRef}
        fontMode={fontMode}
        lang={lang}
      />

      {/* TOP BAR: Exact Chamfered Polygon Bar from Reference Drawing */}
      <motion.header
        initial={{ opacity: 0, y: -36, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{
          type: 'spring',
          stiffness: 170,
          damping: 22,
          delay: 0.05,
        }}
        className="relative w-full max-w-[74rem] mx-auto pt-16 sm:pt-16 2xl:pt-7 px-3 sm:px-6 z-30"
      >
        <div className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.72)]">
          <div className="poly-top-bar bg-gradient-to-b from-[#989898] via-[#848484] to-[#6e6e6e] px-4 sm:px-8 py-3.5 sm:py-4 flex flex-wrap items-center justify-between gap-4 sm:gap-6">
            {/* Inner Inset Brand Plate: Expanded slightly + InfoN'Credits button slightly raised on the right */}
            <div className="filter drop-shadow-[0_6px_8px_rgba(0,0,0,0.55)] max-w-full">
              <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#a0a0a0] via-[#828282] to-[#626262] px-7 sm:px-11 py-3 sm:py-4 flex flex-wrap items-start gap-3 sm:gap-5">
                <motion.a
                  href="#main"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="block pt-0.5"
                >
                  <div className="flex flex-wrap items-baseline gap-2 sm:gap-3">
                    <span className="font-chatopia text-2xl sm:text-4xl md:text-[2.65rem] leading-none tracking-wider whitespace-nowrap">
                      {t.brandTitle}
                    </span>
                    <span className="font-chatopia text-base sm:text-2xl md:text-[1.65rem] leading-none tracking-wider whitespace-nowrap">
                      {t.brandSubtitle}
                    </span>
                  </div>
                </motion.a>

                {/* InfoN'Credits button right of brand text, slightly higher */}
                <motion.button
                  type="button"
                  onClick={() => setIsInfoOpen(true)}
                  aria-label={t.infoCredits.btnAria}
                  whileHover={{ scale: 1.06, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="poly-inner-brand self-start -mt-1 sm:-mt-1.5 p-[2px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#464646] cursor-pointer shadow-md shrink-0 group"
                >
                  <div className="poly-inner-brand bg-gradient-to-b from-[#9c9c9c] via-[#7c7c7c] to-[#565656] group-hover:from-[#b4b4b4] group-hover:to-[#666666] px-2.5 sm:px-3.5 py-1 flex items-center gap-1.5 transition-colors">
                    <img
                      src="/image.png"
                      alt=""
                      aria-hidden="true"
                      draggable={false}
                      className="w-4 h-4 sm:w-5 sm:h-5 object-contain shrink-0 select-none"
                    />
                    <span className="font-chatopia text-[11px] sm:text-sm tracking-wider leading-none whitespace-nowrap">
                      {t.infoCredits.btnLabel}
                    </span>
                  </div>
                </motion.button>
              </div>
            </div>

            {/* Right Navigation Links: "MAIN" & "CREDITS" */}
            <nav
              aria-label={t.navAria}
              className="flex items-center gap-6 sm:gap-10 pr-3 sm:pr-8 ml-auto"
            >
              <motion.a
                href="#main"
                whileHover={{ scale: 1.08, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="font-chatopia text-2xl sm:text-4xl leading-none tracking-wider whitespace-nowrap shrink-0"
              >
                {t.navMain}
              </motion.a>
              <motion.a
                href="#credits"
                whileHover={{ scale: 1.08, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="font-chatopia text-2xl sm:text-4xl leading-none tracking-wider whitespace-nowrap shrink-0"
              >
                {t.navCredits}
              </motion.a>
            </nav>
          </div>
        </div>
      </motion.header>

      {/* MAIN CONTENT */}
      <main className="relative z-20 flex-1 w-full max-w-6xl mx-auto px-4 sm:px-8 pb-32 space-y-28 sm:space-y-36">
        {/* 1. HERO SECTION: Left "FEEL THE NOSTALGIA" + Description Box + "TRY WEB" Button | Right Chamfered 3D Player Window */}
        <section id="main" className="pt-8 sm:pt-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-start">
            {/* Left Side Stack */}
            <motion.div
              style={{ y: leftColumnY }}
              className="lg:col-span-7 pt-2 sm:pt-4 space-y-6 sm:space-y-7"
            >
              {/* 1A. "FEEL THE NOSTALGIA" Chamfered Banner */}
              <motion.div
                initial={{ opacity: 0, x: -48, rotate: -1.5 }}
                animate={{ opacity: 1, x: 0, rotate: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.14,
                }}
                whileHover={{ scale: 1.015 }}
                className="filter drop-shadow-[0_14px_20px_rgba(0,0,0,0.78)]"
              >
                <div className="poly-nostalgia-banner p-[2.5px] bg-gradient-to-b from-[#c8c8c8] via-[#888888] to-[#444444]">
                  <div className="poly-nostalgia-banner vfx-shimmer bg-gradient-to-b from-[#969696] via-[#787878] to-[#585858] px-6 sm:px-10 py-6 sm:py-8">
                    <h1 className="font-chatopia text-2xl sm:text-4xl md:text-[2.65rem] leading-none tracking-wider uppercase text-center sm:text-left">
                      {t.heroTitle}
                    </h1>
                  </div>
                </div>
              </motion.div>

              {/* 1B. Window Below "FEEL THE NOSTALGIA" with requested description text */}
              <motion.div
                initial={{ opacity: 0, x: -38, y: 18 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 21,
                  delay: 0.26,
                }}
                className="filter drop-shadow-[0_14px_22px_rgba(0,0,0,0.8)] max-w-xl"
              >
                <div className="poly-desc-box p-[2.5px] bg-gradient-to-b from-[#bcbcbc] via-[#7c7c7c] to-[#3d3d3d]">
                  <div className="poly-desc-box bg-gradient-to-b from-[#828282] via-[#666666] to-[#484848] px-6 sm:px-9 py-6 sm:py-7">
                    <p className="font-chatopia text-lg sm:text-2xl md:text-[1.6rem] leading-relaxed tracking-wide text-center sm:text-left">
                      {t.heroDesc}
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* 1B-2. "Available Platforms: Android, Web, J2ME" Plate Below Description */}
              <motion.div
                initial={{ opacity: 0, x: -32, y: 16 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 155,
                  damping: 20,
                  delay: 0.32,
                }}
                className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.78)] max-w-xl"
              >
                <div className="poly-section-plate p-[2px] bg-gradient-to-b from-[#c4c4c4] via-[#808080] to-[#3f3f3f]">
                  <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#8c8c8c] via-[#6e6e6e] to-[#4e4e4e] px-5 sm:px-8 py-4 sm:py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
                    <span className="font-chatopia text-base sm:text-xl tracking-wider uppercase text-center sm:text-left shrink-0">
                      {t.platformsLabel}
                    </span>

                    <div className="flex flex-wrap items-center justify-center sm:justify-end gap-2 sm:gap-2.5">
                      {t.platforms.map((platform) => (
                        <div
                          key={platform}
                          className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] via-[#848484] to-[#585858] shadow-md"
                        >
                          <span className="font-chatopia text-sm sm:text-lg tracking-wider leading-none">
                            {platform}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* 1C. "TRY WEB" Button + 1:1 Telegram Button Below the Description Window */}
              <motion.div
                initial={{ opacity: 0, y: 24, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{
                  type: 'spring',
                  stiffness: 170,
                  damping: 19,
                  delay: 0.38,
                }}
                className="pt-1 flex flex-wrap items-stretch justify-center sm:justify-start gap-4"
              >
                <div className="filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] flex">
                  <motion.button
                    type="button"
                    onClick={handleOpenWebView}
                    whileHover={{ scale: 1.05, y: -3 }}
                    whileTap={{ scale: 0.96 }}
                    className="poly-inner-brand p-[3px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#4a4a4a] cursor-pointer group flex"
                  >
                    <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#a6a6a6] via-[#828282] to-[#565656] group-hover:from-[#b8b8b8] group-hover:via-[#909090] group-hover:to-[#646464] px-8 sm:px-11 py-4 sm:py-5 flex items-center gap-4 transition-colors">
                      <span className="w-3 h-3 rounded-full bg-[#fde047] shadow-[0_0_12px_#fde047] animate-pulse shrink-0" />
                      <span className="font-chatopia text-xl sm:text-3xl tracking-wider leading-none uppercase">
                        {t.tryWeb}
                      </span>
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                        className="transition-transform duration-200 group-hover:translate-x-1"
                      >
                        <line x1="5" y1="12" x2="19" y2="12" />
                        <polyline points="12 5 19 12 12 19" />
                      </svg>
                    </div>
                  </motion.button>
                </div>

                {/* 1:1 Square Telegram Button right next to TRY WEB */}
                <div className="filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] flex">
                  <motion.a
                    href="https://t.me/awesome_chatopians"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t.telegramAria}
                    title={t.telegramTitle}
                    whileHover={{ scale: 1.07, y: -3, rotate: 2 }}
                    whileTap={{ scale: 0.95 }}
                    className="poly-square-btn aspect-square h-[58px] sm:h-[76px] p-[3px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#4a4a4a] cursor-pointer group flex"
                  >
                    <div className="poly-square-btn vfx-shimmer w-full h-full bg-gradient-to-b from-[#a6a6a6] via-[#828282] to-[#565656] group-hover:from-[#b8b8b8] group-hover:via-[#909090] group-hover:to-[#646464] flex items-center justify-center transition-colors">
                      <svg
                        width="32"
                        height="32"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        aria-hidden="true"
                        className="w-7 h-7 sm:w-9 sm:h-9 text-white filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-transform duration-200 group-hover:scale-110 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                      >
                        <path d="M21.94 2.66a1.5 1.5 0 0 0-1.62-.24L2.43 9.77a1.42 1.42 0 0 0 .08 2.67l4.56 1.55 1.76 5.42a1.32 1.32 0 0 0 2.24.48l2.58-2.64 4.78 3.52a1.48 1.48 0 0 0 2.33-.92l2.68-15.65a1.5 1.5 0 0 0-.5-1.54ZM9.45 14.8l-.98 3.32-1.18-3.64 9.9-6.64-7.74 6.96Z" />
                      </svg>
                    </div>
                  </motion.a>
                </div>

                {/* 1:1 Square Discord Button right next to Telegram */}
                <div className="filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] flex">
                  <motion.a
                    href="https://discord.gg/yxdCVChqy"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={t.discordAria}
                    title={t.discordTitle}
                    whileHover={{ scale: 1.07, y: -3, rotate: -2 }}
                    whileTap={{ scale: 0.95 }}
                    className="poly-square-btn aspect-square h-[58px] sm:h-[76px] p-[3px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#4a4a4a] cursor-pointer group flex"
                  >
                    <div className="poly-square-btn vfx-shimmer w-full h-full bg-gradient-to-b from-[#a6a6a6] via-[#828282] to-[#565656] group-hover:from-[#b8b8b8] group-hover:via-[#909090] group-hover:to-[#646464] flex items-center justify-center transition-colors">
                      <svg
                        width="32"
                        height="32"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        aria-hidden="true"
                        className="w-7 h-7 sm:w-9 sm:h-9 text-white filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-transform duration-200 group-hover:scale-110"
                      >
                        <path d="M20.32 4.37a19.8 19.8 0 0 0-4.93-1.51.07.07 0 0 0-.08.04c-.21.38-.45.87-.62 1.25a18.27 18.27 0 0 0-5.49 0c-.17-.39-.42-.87-.63-1.25a.08.08 0 0 0-.08-.04A19.74 19.74 0 0 0 3.56 4.37a.07.07 0 0 0-.03.03C.4 9.05-.46 13.59-.04 18.06a.08.08 0 0 0 .03.06 19.9 19.9 0 0 0 5.99 3.03.08.08 0 0 0 .08-.03c.46-.63.87-1.3 1.23-2a.08.08 0 0 0-.04-.11 13.1 13.1 0 0 1-1.87-.89.08.08 0 0 1-.01-.12c.13-.09.25-.19.37-.29a.08.08 0 0 1 .08-.01c3.93 1.79 8.18 1.79 12.06 0a.08.08 0 0 1 .08.01c.12.1.24.2.37.29a.08.08 0 0 1-.01.12c-.6.35-1.22.65-1.87.89a.08.08 0 0 0-.04.11c.36.7.77 1.37 1.23 2a.08.08 0 0 0 .08.03 19.83 19.83 0 0 0 6-3.03.08.08 0 0 0 .03-.06c.5-5.18-.84-9.68-3.55-13.66a.06.06 0 0 0-.03-.03ZM8.02 15.33c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.96 2.42-2.16 2.42Zm7.97 0c-1.18 0-2.16-1.08-2.16-2.42 0-1.33.96-2.42 2.16-2.42 1.21 0 2.18 1.1 2.16 2.42 0 1.34-.95 2.42-2.16 2.42Z" />
                      </svg>
                    </div>
                  </motion.a>
                </div>
              </motion.div>
            </motion.div>

            {/* Right Side: Chamfered 3D Player Window */}
            <motion.div
              style={{ y: rightAvatarY }}
              initial={{ opacity: 0, x: 48, scale: 0.94 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{
                type: 'spring',
                stiffness: 140,
                damping: 20,
                delay: 0.2,
              }}
              className="lg:col-span-5"
            >
              <CharacterViewport3D
                scrollProgressRef={scrollProgressRef}
                loadingLabel={t.viewportLoading}
                pausedLabel={t.viewportPaused}
                ariaLabel={t.viewportAria}
              />
            </motion.div>
          </div>
        </section>

        {/* 2. MIDDLE SECTION: CREDITS / DEVELOPERS (TheMainChatter above glowing gold + Chickedream below) */}
        <motion.section
          id="credits"
          style={{ scale: creditsScale }}
          className="max-w-3xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.4 }}
            transition={{ type: 'spring', stiffness: 160, damping: 20 }}
            className="flex justify-center mb-10"
          >
            <div className="filter drop-shadow-[0_10px_14px_rgba(0,0,0,0.7)]">
              <div className="poly-inner-brand p-[2px] bg-gradient-to-b from-[#b8b8b8] to-[#4a4a4a]">
                <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#8e8e8e] to-[#5c5c5c] px-10 py-3">
                  <h2 className="font-chatopia text-2xl sm:text-4xl tracking-wider uppercase">
                    {t.creditsHeading}
                  </h2>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-7">
            {/* 1st (Higher & Glowing Gold): TheMainChatter with root avatar on left */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ type: 'spring', stiffness: 150, damping: 20 }}
              whileHover={{ scale: 1.02, y: -3 }}
              className="vfx-gold-aura"
            >
              <div className="poly-section-plate p-[2.5px] bg-gradient-to-r from-[#fef08a] via-[#eab308] to-[#fef08a]">
                <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#54471c] via-[#382f14] to-[#211c0d] px-6 sm:px-9 py-5 sm:py-6 flex flex-col sm:flex-row items-center gap-6">
                  <div className="poly-chamfer-md p-[2.5px] bg-gradient-to-b from-[#fef08a] via-[#eab308] to-[#854d0e] shadow-[0_0_20px_rgba(250,204,21,0.65)] shrink-0">
                    <div className="poly-chamfer-md w-20 h-20 sm:w-24 sm:h-24 overflow-hidden bg-black">
                      <img
                        src="/IMG_20261108_012259_125.jpg"
                        alt="TheMainChatter"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  <div className="text-center sm:text-left">
                    <h3 className="font-chatopia-gold text-3xl sm:text-5xl tracking-wider leading-none mb-2">
                      THEMAINCHATTER
                    </h3>
                    <p className="font-chatopia text-sm sm:text-lg tracking-wider opacity-90">
                      {t.founderRole}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* 2nd (Below TheMainChatter): Chickedream (Clickable -> Opens Contact Menu) */}
            <motion.div
              role="button"
              tabIndex={0}
              aria-label={t.openContactAria}
              onClick={() => setIsContactOpen(true)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setIsContactOpen(true);
                }
              }}
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{
                type: 'spring',
                stiffness: 150,
                damping: 20,
                delay: 0.08,
              }}
              whileHover={{ scale: 1.025, y: -4 }}
              whileTap={{ scale: 0.98 }}
              className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.75)] cursor-pointer group"
            >
              <div className="poly-section-plate p-[2px] bg-gradient-to-b from-[#c8c8c8] to-[#484848] group-hover:from-[#ffffff] group-hover:to-[#666666] transition-colors">
                <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#848484] via-[#686868] to-[#4c4c4c] group-hover:from-[#949494] group-hover:via-[#747474] group-hover:to-[#565656] px-6 sm:px-9 py-5 flex flex-col sm:flex-row items-center justify-between gap-6 transition-colors">
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#d8d8d8] to-[#5a5a5a] shrink-0 shadow-md">
                      <div className="poly-chamfer-md w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-b from-[#9a9a9a] to-[#525252] flex items-center justify-center">
                        <span className="font-chatopia text-3xl sm:text-4xl">
                          C
                        </span>
                      </div>
                    </div>

                    <div className="text-center sm:text-left">
                      <h3 className="font-chatopia text-2xl sm:text-4xl tracking-wider leading-none mb-2">
                        CHICKEDREAM
                      </h3>
                      <p className="font-chatopia text-sm sm:text-lg tracking-wider opacity-90">
                        {t.builderRole}
                      </p>
                    </div>
                  </div>

                  <div className="poly-inner-brand px-5 py-2 bg-gradient-to-b from-[#a6a6a6] to-[#585858] group-hover:from-[#bcbcbc] group-hover:to-[#6a6a6a] shrink-0 shadow">
                    <span className="font-chatopia text-sm sm:text-lg tracking-wider uppercase">
                      {t.contactBtn}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.section>

        {/* 2.5. DOWNLOAD WIDGETS: ITCH.IO & GAME JOLT FRAMES */}
        <section id="downloads" className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.35 }}
            transition={{ type: 'spring', stiffness: 160, damping: 20 }}
            className="flex justify-center mb-10"
          >
            <div className="filter drop-shadow-[0_10px_14px_rgba(0,0,0,0.7)]">
              <div className="poly-inner-brand p-[2px] bg-gradient-to-b from-[#b8b8b8] to-[#4a4a4a]">
                <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#8e8e8e] to-[#5c5c5c] px-8 sm:px-10 py-3">
                  <h2 className="font-chatopia text-2xl sm:text-4xl tracking-wider uppercase text-center">
                    {t.downloadHeading}
                  </h2>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-8">
            {/* Itch.io Decorated Frame */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.25 }}
              transition={{ type: 'spring', stiffness: 150, damping: 20 }}
              whileHover={{ y: -4, scale: 1.01 }}
              className="filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.82)]"
            >
              <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#848484] to-[#3f3f3f]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8a8a8a] via-[#686868] to-[#464646] p-4 sm:p-6 space-y-4">
                  {/* Frame Header Bar */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#9c9c9c] via-[#7e7e7e] to-[#5c5c5c] px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#fa5c5c] shadow-[0_0_10px_#fa5c5c] shrink-0" />
                      <span className="font-chatopia text-lg sm:text-2xl tracking-wider uppercase">
                        {t.itchHeader}
                      </span>
                    </div>
                    <a
                      href="https://chickedream.itch.io/chatopia"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="poly-inner-brand vfx-shimmer px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5a5a5a] hover:from-[#bcbcbc] hover:to-[#6e6e6e] transition-transform active:scale-95"
                    >
                      <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                        {t.itchOpen}
                      </span>
                    </a>
                  </div>

                  {/* Centered Embed Container */}
                  <div className="poly-window-shell p-[2px] bg-[#141414]">
                    <div className="poly-window-shell bg-gradient-to-b from-[#2b2b2b] to-[#171717] p-3 sm:p-5 flex justify-center items-center overflow-x-auto shadow-inner">
                      <iframe
                        frameBorder={0}
                        src="https://itch.io/embed/4650524"
                        width="552"
                        height="167"
                        title={t.itchTitle}
                        className="poly-chamfer-sm max-w-full shadow-lg shrink-0"
                      >
                        <a href="https://chickedream.itch.io/chatopia">
                          {t.itchTitle}
                        </a>
                      </iframe>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Game Jolt Decorated Frame */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.25 }}
              transition={{
                type: 'spring',
                stiffness: 150,
                damping: 20,
                delay: 0.08,
              }}
              whileHover={{ y: -4, scale: 1.01 }}
              className="filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.82)]"
            >
              <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#848484] to-[#3f3f3f]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8a8a8a] via-[#686868] to-[#464646] p-4 sm:p-6 space-y-4">
                  {/* Frame Header Bar */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#9c9c9c] via-[#7e7e7e] to-[#5c5c5c] px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#ccff00] shadow-[0_0_10px_#ccff00] shrink-0" />
                      <span className="font-chatopia text-lg sm:text-2xl tracking-wider uppercase">
                        {t.gameJoltHeader}
                      </span>
                    </div>
                    <a
                      href="https://gamejolt.com/games/Chatopiarevival/1075649"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="poly-inner-brand vfx-shimmer px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5a5a5a] hover:from-[#bcbcbc] hover:to-[#6e6e6e] transition-transform active:scale-95"
                    >
                      <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                        {t.gameJoltOpen}
                      </span>
                    </a>
                  </div>

                  {/* Centered Embed Container */}
                  <div className="poly-window-shell p-[2px] bg-[#141414]">
                    <div className="poly-window-shell bg-gradient-to-b from-[#2b2b2b] to-[#171717] p-3 sm:p-5 flex justify-center items-center overflow-x-auto shadow-inner">
                      <iframe
                        src="https://widgets.gamejolt.com/package/v1?key=QD9DCGpX"
                        frameBorder={0}
                        width="500"
                        height="245"
                        title={t.gameJoltTitle}
                        className="poly-chamfer-sm max-w-full shadow-lg shrink-0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 3. IN-GAME SCREENSHOTS IN SIGNATURE CHATOPIA FRAMES (The Chatting Zone & SFOTH) */}
        <section id="places" className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10">
            {featuredScreens.map((item, idx) => (
              <motion.article
                key={item.id}
                role="button"
                tabIndex={0}
                aria-label={`${t.openPlaceAriaPrefix} ${item.title}`}
                onClick={() => setPreviewScreenId(item.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setPreviewScreenId(item.id);
                  }
                }}
                initial={{ opacity: 0, y: 44, scale: 0.94 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: false, amount: 0.25 }}
                transition={{
                  type: 'spring',
                  stiffness: 145,
                  damping: 20,
                  delay: idx * 0.12,
                }}
                whileHover={{ y: -6, scale: 1.015 }}
                whileTap={{ scale: 0.985 }}
                className="group filter drop-shadow-[0_18px_32px_rgba(0,0,0,0.85)] cursor-pointer"
              >
                <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#d0d0d0] via-[#848484] to-[#3c3c3c] group-hover:from-[#ffffff] group-hover:via-[#9a9a9a] group-hover:to-[#4f4f4f] transition-colors">
                  <div className="poly-window-shell vfx-shimmer bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#444444] p-4 sm:p-5 space-y-4">
                    {/* Top Signature Place Header */}
                    <div className="poly-top-bar bg-gradient-to-b from-[#9e9e9e] via-[#808080] to-[#5e5e5e] px-4 sm:px-5 py-2 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_8px_#fde047] shrink-0" />
                        <span className="font-chatopia text-base sm:text-xl tracking-wider uppercase truncate">
                          {item.title}
                        </span>
                      </div>
                      <span className="font-chatopia text-xs tracking-wider opacity-80 uppercase shrink-0">
                        {t.placeTag}
                      </span>
                    </div>

                    {/* Signature Chamfered Inner Screenshot Frame */}
                    <div className="poly-window-shell p-[2px] bg-black/90">
                      <div className="poly-window-shell aspect-[16/10] w-full overflow-hidden bg-black shadow-inner">
                        <img
                          src={item.imageUrl}
                          alt={item.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      </div>
                    </div>

                    {/* Bottom Author Plate */}
                    <div className="flex justify-center pt-0.5">
                      <div className="poly-inner-brand px-6 py-2 bg-gradient-to-b from-[#989898] via-[#767676] to-[#525252] shadow-md">
                        <p className="font-chatopia text-sm sm:text-lg tracking-wider uppercase">
                          {item.author}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </section>
      </main>

      {/* BOTTOM LEGAL FOOTER: Signature Chamfered Frame, White Text on Black */}
      <footer className="relative z-20 w-full px-4 sm:px-8 pb-10 sm:pb-14">
        <motion.div
          initial={{ opacity: 0, y: 28, scale: 0.96 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ type: 'spring', stiffness: 150, damping: 22 }}
          className="max-w-4xl mx-auto filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.9)]"
        >
          <div className="poly-section-plate p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#808080] to-[#3b3b3b]">
            <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#141414] via-[#080808] to-[#000000] px-6 sm:px-12 py-7 sm:py-9 text-center space-y-3">
              <p className="font-chatopia text-sm sm:text-lg md:text-xl tracking-wider leading-relaxed">
                &copy; {t.footerCopyright}
              </p>
              <p className="font-chatopia text-xs sm:text-base tracking-wider leading-relaxed opacity-90">
                {t.footerTrademarks}
              </p>
            </div>
          </div>
        </motion.div>
      </footer>

      {/* DRAGGABLE WEB VIEW WINDOW (chatopia-game.pages.dev) */}
      <DraggableWebViewWindow
        isOpen={isWebViewOpen}
        isMinimized={isWebViewMinimized}
        onMinimizeChange={setIsWebViewMinimized}
        onClose={() => {
          setIsWebViewOpen(false);
          setIsWebViewMinimized(false);
        }}
        url="https://chatopia-game.pages.dev"
        lang={lang}
      />

      {/* CHICKEDREAM CONTACT MENU MODAL */}
      <AnimatePresence>
        {isContactOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={t.contactDialogAria}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setIsContactOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.92, y: 24, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 24, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 240, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-2xl w-full filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.92)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#3d3d3d]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-5 sm:p-7 space-y-5 max-h-[88vh] overflow-y-auto">
                  {/* Modal Header */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="poly-chamfer-sm p-[1.5px] bg-gradient-to-b from-[#e0e0e0] to-[#686868] shrink-0">
                        <div className="poly-chamfer-sm w-10 h-10 bg-gradient-to-b from-[#9c9c9c] to-[#525252] flex items-center justify-center">
                          <span className="font-chatopia text-2xl leading-none">
                            C
                          </span>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-chatopia text-xl sm:text-3xl tracking-wider uppercase leading-none">
                          {t.contactTitle}
                        </h3>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsContactOpen(false)}
                      className="poly-inner-brand px-4 sm:px-5 py-2 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <span className="font-chatopia text-sm sm:text-base tracking-wider">
                        {t.close}
                      </span>
                    </button>
                  </div>

                  {/* Contact Items Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
                    {/* TikTok (2 accounts) */}
                    <div className="sm:col-span-2 poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.tiktokLabel}
                          </span>
                          <div className="flex flex-wrap items-center gap-3 mt-1">
                            <a
                              href="https://www.tiktok.com/@chickedream"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline"
                            >
                              @chickedream
                            </a>
                            <span className="font-chatopia text-lg opacity-60">
                              /
                            </span>
                            <a
                              href="https://www.tiktok.com/@chickedream_fdt"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline"
                            >
                              @chickedream_fdt
                            </a>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              handleCopyText('@chickedream', 'tiktok1')
                            }
                            className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer"
                          >
                            <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                              {copiedLabel === 'tiktok1'
                                ? t.copiedBtn
                                : t.copyOneBtn}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              handleCopyText('@chickedream_fdt', 'tiktok2')
                            }
                            className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer"
                          >
                            <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                              {copiedLabel === 'tiktok2'
                                ? t.copiedBtn
                                : t.copyTwoBtn}
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Telegram */}
                    <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md h-full bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.telegramLabel}
                          </span>
                          <a
                            href="https://t.me/chickedream"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                          >
                            @chickedream
                          </a>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText('@chickedream', 'tg')}
                          className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'tg' ? t.copiedBtn : t.copyBtn}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* YouTube */}
                    <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md h-full bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.youtubeLabel}
                          </span>
                          <a
                            href="https://www.youtube.com/@chickedream"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                          >
                            @chickedream
                          </a>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyText('@chickedream', 'yt')}
                          className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'yt' ? t.copiedBtn : t.copyBtn}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Email */}
                    <div className="sm:col-span-2 poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="min-w-0">
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.emailLabel}
                          </span>
                          <a
                            href="mailto:chickedream@gmail.com"
                            className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                          >
                            chickedream@gmail.com
                          </a>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyText('chickedream@gmail.com', 'email')
                          }
                          className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0 self-start sm:self-center"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'email'
                              ? t.copiedBtn
                              : t.copyEmailBtn}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Roblox */}
                    <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md h-full bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.robloxLabel}
                          </span>
                          <span className="font-chatopia text-lg sm:text-2xl tracking-wider block truncate mt-0.5">
                            @4effrey_d4hm9r
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyText('4effrey_d4hm9r', 'roblox')
                          }
                          className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'roblox' ? t.copiedBtn : t.copyBtn}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Country */}
                    <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#a8a8a8] to-[#505050]">
                      <div className="poly-chamfer-md h-full bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                            {t.countryLabel}
                          </span>
                          <span className="font-chatopia text-lg sm:text-2xl tracking-wider block truncate mt-0.5">
                            {t.countryValue}
                          </span>
                        </div>
                        <div className="poly-chamfer-sm p-[1.5px] bg-[#b0b0b0] shrink-0 shadow">
                          <svg
                            width="28"
                            height="20"
                            viewBox="0 0 28 20"
                            aria-hidden="true"
                            className="poly-chamfer-sm block"
                          >
                            <rect width="28" height="10" y="0" fill="#0057B7" />
                            <rect width="28" height="10" y="10" fill="#FFD700" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FULLSCREEN SCREENSHOT MODAL */}
      <AnimatePresence>
        {previewScreen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={previewScreen.title}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setPreviewScreenId(null)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/85"
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-4xl w-full filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.92)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#3d3d3d]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-4 sm:p-6 space-y-4">
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <h3 className="font-chatopia text-xl sm:text-3xl uppercase truncate">
                        {previewScreen.title}
                      </h3>
                      <p className="font-chatopia text-xs sm:text-sm tracking-wider opacity-85">
                        {previewScreen.author}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setPreviewScreenId(null)}
                      className="poly-inner-brand px-4 sm:px-5 py-2 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <span className="font-chatopia text-sm sm:text-base">
                        {t.close}
                      </span>
                    </button>
                  </div>

                  <div className="poly-window-shell p-[2px] bg-black">
                    <div className="poly-window-shell overflow-hidden bg-black">
                      <img
                        src={previewScreen.imageUrl}
                        alt={previewScreen.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-auto max-h-[74vh] object-contain mx-auto"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* INFON'CREDITS MODAL (Scrollbox + Highlights, English & Russian) */}
      <AnimatePresence>
        {isInfoOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={t.infoCredits.dialogAria}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setIsInfoOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.92, y: 24, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 24, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 240, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-3xl w-full filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.92)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#3d3d3d]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-4 sm:p-6 space-y-4">
                  {/* Modal Header */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="poly-chamfer-sm p-[1.5px] bg-gradient-to-b from-[#e0e0e0] to-[#686868] shrink-0 shadow">
                        <div className="poly-chamfer-sm w-10 h-10 bg-gradient-to-b from-[#a4a4a4] to-[#565656] flex items-center justify-center p-1">
                          <img
                            src="/image.png"
                            alt=""
                            aria-hidden="true"
                            draggable={false}
                            className="w-full h-full object-contain select-none"
                          />
                        </div>
                      </div>
                      <h3 className="font-chatopia text-xl sm:text-3xl tracking-wider truncate">
                        {t.infoCredits.modalTitle}
                      </h3>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsInfoOpen(false)}
                      className="poly-inner-brand px-4 sm:px-5 py-2 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <span className="font-chatopia text-sm sm:text-base tracking-wider">
                        {t.close}
                      </span>
                    </button>
                  </div>

                  {/* Styled Scrollbox with Highlights */}
                  <div className="poly-window-shell p-[2px] bg-[#101010] shadow-inner">
                    <div className="poly-window-shell chatopia-scrollbox max-h-[58vh] overflow-y-auto bg-gradient-to-b from-[#2b2b2b] via-[#1e1e1e] to-[#121212] p-4 sm:p-6 space-y-4">
                      {/* 1. History & Origin Card */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#fde047] via-[#5a5a5a] to-[#424242]">
                        <div className="poly-chamfer-md bg-[#2a2a2a] p-3.5 sm:p-4 space-y-2">
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.introPrefix}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#eab308]/80 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#3c3416] text-yellow-200">
                                {t.infoCredits.introTeam}
                              </span>
                            </span>
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.plannedText}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#38bdf8]/75 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#172d3b] text-sky-200">
                                {t.infoCredits.plannedYear}
                              </span>
                            </span>
                            .
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.releasedText}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#34d399]/75 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#153127] text-emerald-200">
                                {t.infoCredits.releasedYear}
                              </span>
                            </span>
                            .
                          </p>
                        </div>
                      </div>

                      {/* 2. Official Devs & Engine Card */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#fcd34d] via-[#927722] to-[#5e4d18]">
                        <div className="poly-chamfer-md bg-gradient-to-b from-[#3b3216] to-[#211b0c] p-3.5 sm:p-4 space-y-2.5">
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.devsLabel}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#fde047]/70 align-baseline">
                              <span className="poly-chamfer-sm font-chatopia-gold inline-block px-2 py-0.5 bg-[#463a15]">
                                {t.infoCredits.devOne}
                              </span>
                            </span>
                            ;{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#fde047]/70 align-baseline">
                              <span className="poly-chamfer-sm font-chatopia-gold inline-block px-2 py-0.5 bg-[#463a15]">
                                {t.infoCredits.devTwo}
                              </span>
                            </span>
                            .
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.engineLabel}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#a3a3a3]/65 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#443e29] text-white">
                                {t.infoCredits.engineValue}
                              </span>
                            </span>
                            .
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide opacity-95">
                            {t.infoCredits.androidNotePrefix}{' '}
                            <span className="text-emerald-300">
                              {t.infoCredits.androidNoteHighlight}
                            </span>
                          </p>
                        </div>
                      </div>

                      {/* 3. Official Platforms & Fake Source Warning */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#fb923c] via-[#9a4a16] to-[#633010]">
                        <div className="poly-chamfer-md bg-[#341c0d] p-3.5 sm:p-4 space-y-2.5">
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.platformsPrefix}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#a3a3a3]/60 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#4c3425] text-yellow-200">
                                {t.infoCredits.platformsList[0]}
                              </span>
                            </span>
                            ,{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#a3a3a3]/60 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#4c3425] text-yellow-200">
                                {t.infoCredits.platformsList[1]}
                              </span>
                            </span>
                            ,{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#a3a3a3]/60 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#4c3425] text-sky-200">
                                {t.infoCredits.platformsList[2]}
                              </span>
                            </span>
                            {t.infoCredits.platformsAnd}{' '}
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#a3a3a3]/60 align-baseline">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#4c3425] text-emerald-200">
                                {t.infoCredits.platformsList[3]}
                              </span>
                            </span>
                            .
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide text-orange-200">
                            {t.infoCredits.platformsFakeWarning}
                          </p>
                        </div>
                      </div>

                      {/* 4. Copyright Strip */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-b from-[#7a7a7a] to-[#3a3a3a]">
                        <div className="poly-chamfer-md bg-[#0e0e0e] px-4 py-3 text-center">
                          <p className="font-chatopia text-sm sm:text-lg tracking-wider text-white">
                            &copy; {t.infoCredits.copyright}
                          </p>
                        </div>
                      </div>

                      {/* 5. Privacy Tip & Feedback Email */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#34d399] via-[#1b7a58] to-[#114a35]">
                        <div className="poly-chamfer-md bg-[#0f2b20] p-3.5 sm:p-4 space-y-2.5">
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#6ee7b7]/75 align-baseline mr-1.5">
                              <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#154231] text-emerald-200">
                                {t.infoCredits.tipLabel}
                              </span>
                            </span>
                            {t.infoCredits.tipPrefix}{' '}
                            <span className="text-emerald-300 underline decoration-emerald-400/60 underline-offset-4">
                              {t.infoCredits.tipHighlight}
                            </span>{' '}
                            {t.infoCredits.tipSuffix}
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.feedbackPrefix}{' '}
                            <a
                              href={`mailto:${t.infoCredits.feedbackEmail}`}
                              className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#7dd3fc]/75 align-baseline group"
                            >
                              <span className="poly-chamfer-sm inline-block px-2.5 py-0.5 bg-[#163448] group-hover:bg-[#1e4a66] text-sky-200 transition-colors underline">
                                {t.infoCredits.feedbackEmail}
                              </span>
                            </a>
                          </p>
                        </div>
                      </div>

                      {/* 6. Rights & Anti-Unpack Rules */}
                      <div className="poly-chamfer-md p-[2px] bg-gradient-to-r from-[#f87171] via-[#8f2424] to-[#571616]">
                        <div className="poly-chamfer-md bg-[#321214] p-3.5 sm:p-4 space-y-2.5">
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide">
                            {t.infoCredits.copycatText}
                            {t.infoCredits.copycatHighlight ? (
                              <>
                                {' '}
                                <span className="poly-chamfer-sm inline-flex p-[1.5px] bg-[#fca5a5]/75 align-baseline">
                                  <span className="poly-chamfer-sm inline-block px-2 py-0.5 bg-[#4a1c1f] text-red-200">
                                    {t.infoCredits.copycatHighlight}
                                  </span>
                                </span>
                              </>
                            ) : null}
                          </p>
                          <p className="font-chatopia text-sm sm:text-lg leading-relaxed tracking-wide text-red-200">
                            {t.infoCredits.unpackText}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
