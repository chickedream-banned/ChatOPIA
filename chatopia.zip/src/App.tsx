import React, { useEffect, useRef, useState } from 'react';
import {
  AnimatePresence,
  motion,
  useScroll,
  useSpring,
  useTransform,
} from 'motion/react';
import { CharacterViewport3D } from './components/CharacterViewport3D';
import { DraggableWebViewWindow } from './components/DraggableWebViewWindow';
import { ParticleFieldVfx } from './components/ParticleFieldVfx';
import { SoundEffectsController } from './utils/soundEffects';

interface GameScreenItem {
  id: string;
  title: string;
  author: string;
  imageUrl: string;
}

const FEATURED_SCREENS: GameScreenItem[] = [
  {
    id: 'chatting-zone',
    title: 'THE CHATTING ZONE',
    author: 'BY THEMAINCHATTER',
    imageUrl: '/Screenshot_20261108_010904.png',
  },
  {
    id: 'sfoth',
    title: 'SFOTH',
    author: 'BY THEMAINCHATTER',
    imageUrl: '/Screenshot_20261108_010922.png',
  },
];

export default function App() {
  const scrollProgressRef = useRef<number>(0);
  const { scrollYProgress } = useScroll();
  const smoothScroll = useSpring(scrollYProgress, {
    stiffness: 85,
    damping: 24,
    restDelta: 0.001,
  });

  // Parallax & Scroll-linked VFX transforms
  const leftColumnY = useTransform(smoothScroll, [0, 0.4], [0, -28]);
  const rightAvatarY = useTransform(smoothScroll, [0, 0.4], [0, -14]);
  const ambientGlowY = useTransform(smoothScroll, [0, 1], ['0%', '35%']);
  const creditsScale = useTransform(smoothScroll, [0.12, 0.42], [0.95, 1]);

  useEffect(() => {
    const unsubscribe = smoothScroll.on('change', (val) => {
      scrollProgressRef.current = val;
    });
    return () => unsubscribe();
  }, [smoothScroll]);

  useEffect(() => {
    const sfx = new SoundEffectsController();
    return () => sfx.dispose();
  }, []);

  const [previewScreen, setPreviewScreen] = useState<GameScreenItem | null>(
    null
  );
  const [isWebViewOpen, setIsWebViewOpen] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem('chatopia_webview_session_v1');
      if (!raw) return false;
      const parsed = JSON.parse(raw) as { open?: boolean };
      return parsed.open === true;
    } catch {
      return false;
    }
  });
  const [isWebViewMinimized, setIsWebViewMinimized] = useState<boolean>(() => {
    try {
      const raw = localStorage.getItem('chatopia_webview_session_v1');
      if (!raw) return false;
      const parsed = JSON.parse(raw) as { minimized?: boolean };
      return parsed.minimized === true;
    } catch {
      return false;
    }
  });
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [copiedLabel, setCopiedLabel] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(
        'chatopia_webview_session_v1',
        JSON.stringify({ open: isWebViewOpen, minimized: isWebViewMinimized })
      );
    } catch {
      // Ignore storage write errors
    }
  }, [isWebViewOpen, isWebViewMinimized]);

  const handleCopyText = (text: string, label: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
    setCopiedLabel(label);
    window.setTimeout(() => {
      setCopiedLabel((prev) => (prev === label ? null : prev));
    }, 1800);
  };

  const handleOpenWebView = () => {
    setIsWebViewOpen(true);
    setIsWebViewMinimized(false);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-[#747474] via-[#262626] via-45% to-[#030303] text-white flex flex-col overflow-x-hidden">
      {/* Top Scroll Progress Laser Line */}
      <motion.div
        style={{ scaleX: smoothScroll }}
        className="fixed top-0 left-0 right-0 h-1 origin-left z-40 bg-gradient-to-r from-[#d4d4d4] via-[#ffffff] to-[#fde047] shadow-[0_0_14px_rgba(255,255,255,0.85)]"
      />

      {/* Ambient Floating Volumetric Glow Orbs */}
      <motion.div
        aria-hidden="true"
        style={{ y: ambientGlowY }}
        className="fixed inset-0 pointer-events-none z-0 overflow-hidden"
      >
        <div className="absolute -top-28 left-1/4 w-[28rem] h-[28rem] rounded-full bg-white/[0.07] blur-[110px]" />
        <div className="absolute top-[38%] right-[10%] w-[24rem] h-[24rem] rounded-full bg-[#d4d4d4]/[0.06] blur-[120px]" />
        <div className="absolute top-[55%] left-1/2 -translate-x-1/2 w-[30rem] h-[18rem] rounded-full bg-yellow-400/[0.06] blur-[130px]" />
      </motion.div>

      {/* Interactive Retro Particle & Stud VFX Canvas */}
      <ParticleFieldVfx scrollProgressRef={scrollProgressRef} />

      {/* TOP BAR: Exact Chamfered Polygon Bar from Reference Drawing */}
      <motion.header
        initial={{ opacity: 0, y: -36, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{
          type: 'spring',
          stiffness: 170,
          damping: 22,
          delay: 0.05,
        }}
        className="relative w-full max-w-6xl mx-auto pt-5 sm:pt-7 px-3 sm:px-6 z-30"
      >
        <div className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.72)]">
          <div className="poly-top-bar bg-gradient-to-b from-[#989898] via-[#848484] to-[#6e6e6e] px-4 sm:px-8 py-3.5 sm:py-4 flex flex-wrap items-center justify-between gap-4 sm:gap-8">
            {/* Inner Inset Brand Plate: "CHATOPIA / ROBLOX REVIVAL" */}
            <div className="filter drop-shadow-[0_6px_8px_rgba(0,0,0,0.55)] max-w-full">
              <motion.a
                href="#main"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="poly-inner-brand vfx-shimmer block bg-gradient-to-b from-[#a0a0a0] via-[#828282] to-[#626262] px-5 sm:px-9 py-2.5 sm:py-3.5"
              >
                <div className="flex flex-wrap items-baseline gap-2 sm:gap-3">
                  <span className="font-chatopia text-2xl sm:text-4xl md:text-[2.65rem] leading-none tracking-wider whitespace-nowrap">
                    CHATOPIA /
                  </span>
                  <span className="font-chatopia text-base sm:text-2xl md:text-[1.65rem] leading-none tracking-wider whitespace-nowrap">
                    ROBLOX REVIVAL
                  </span>
                </div>
              </motion.a>
            </div>

            {/* Right Navigation Links: "MAIN" & "CREDITS" */}
            <nav
              aria-label="Main navigation"
              className="flex items-center gap-6 sm:gap-12 pr-3 sm:pr-8 ml-auto"
            >
              <motion.a
                href="#main"
                whileHover={{ scale: 1.08, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="font-chatopia text-2xl sm:text-4xl leading-none tracking-wider whitespace-nowrap shrink-0"
              >
                MAIN
              </motion.a>
              <motion.a
                href="#credits"
                whileHover={{ scale: 1.08, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="font-chatopia text-2xl sm:text-4xl leading-none tracking-wider whitespace-nowrap shrink-0"
              >
                CREDITS
              </motion.a>
            </nav>
          </div>
        </div>
      </motion.header>

      {/* MAIN CONTENT */}
      <main className="relative z-20 flex-1 w-full max-w-6xl mx-auto px-4 sm:px-8 pb-32 space-y-28 sm:space-y-36">
        {/* 1. HERO SECTION: Left "FEEL THE NOSTALGIA" + Description Box + "TRY WEB" Button | Right Chamfered 3D Player Window */}
        <section id="main" className="pt-8 sm:pt-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-start">
            {/* Left Side Stack */}
            <motion.div
              style={{ y: leftColumnY }}
              className="lg:col-span-7 pt-2 sm:pt-4 space-y-6 sm:space-y-7"
            >
              {/* 1A. "FEEL THE NOSTALGIA" Chamfered Banner */}
              <motion.div
                initial={{ opacity: 0, x: -48, rotate: -1.5 }}
                animate={{ opacity: 1, x: 0, rotate: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 20,
                  delay: 0.14,
                }}
                whileHover={{ scale: 1.015 }}
                className="filter drop-shadow-[0_14px_20px_rgba(0,0,0,0.78)]"
              >
                <div className="poly-nostalgia-banner p-[2.5px] bg-gradient-to-b from-[#c8c8c8] via-[#888888] to-[#444444]">
                  <div className="poly-nostalgia-banner vfx-shimmer bg-gradient-to-b from-[#969696] via-[#787878] to-[#585858] px-6 sm:px-10 py-6 sm:py-8">
                    <h1 className="font-chatopia text-2xl sm:text-4xl md:text-[2.65rem] leading-none tracking-wider uppercase text-center sm:text-left">
                      FEEL THE NOSTALGIA.
                    </h1>
                  </div>
                </div>
              </motion.div>

              {/* 1B. Window Below "FEEL THE NOSTALGIA" with requested description text */}
              <motion.div
                initial={{ opacity: 0, x: -38, y: 18 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 150,
                  damping: 21,
                  delay: 0.26,
                }}
                className="filter drop-shadow-[0_14px_22px_rgba(0,0,0,0.8)] max-w-xl"
              >
                <div className="poly-desc-box p-[2.5px] bg-gradient-to-b from-[#bcbcbc] via-[#7c7c7c] to-[#3d3d3d]">
                  <div className="poly-desc-box bg-gradient-to-b from-[#828282] via-[#666666] to-[#484848] px-6 sm:px-9 py-6 sm:py-7">
                    <p className="font-chatopia text-lg sm:text-2xl md:text-[1.6rem] leading-relaxed tracking-wide text-center sm:text-left">
                      The best roblox revival on NewCatroid And Web (prolly).
                      Play with friends, siblings, anywhere.
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* 1B-2. "Available Platforms: Android, Web, J2ME" Plate Below Description */}
              <motion.div
                initial={{ opacity: 0, x: -32, y: 16 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 155,
                  damping: 20,
                  delay: 0.32,
                }}
                className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.78)] max-w-xl"
              >
                <div className="poly-section-plate p-[2px] bg-gradient-to-b from-[#c4c4c4] via-[#808080] to-[#3f3f3f]">
                  <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#8c8c8c] via-[#6e6e6e] to-[#4e4e4e] px-5 sm:px-8 py-4 sm:py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
                    <span className="font-chatopia text-base sm:text-xl tracking-wider uppercase text-center sm:text-left shrink-0">
                      Available Platforms:
                    </span>

                    <div className="flex flex-wrap items-center justify-center sm:justify-end gap-2 sm:gap-2.5">
                      {(['Android', 'Web', 'J2ME'] as const).map((platform) => (
                        <div
                          key={platform}
                          className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] via-[#848484] to-[#585858] shadow-md"
                        >
                          <span className="font-chatopia text-sm sm:text-lg tracking-wider leading-none">
                            {platform}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* 1C. "TRY WEB" Button + 1:1 Telegram Button Below the Description Window */}
              <motion.div
                initial={{ opacity: 0, y: 24, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{
                  type: 'spring',
                  stiffness: 170,
                  damping: 19,
                  delay: 0.38,
                }}
                className="pt-1 flex flex-wrap items-stretch justify-center sm:justify-start gap-4"
              >
                <div className="filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] flex">
                  <motion.button
                    type="button"
                    onClick={handleOpenWebView}
                    whileHover={{ scale: 1.05, y: -3 }}
                    whileTap={{ scale: 0.96 }}
                    className="poly-inner-brand p-[3px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#4a4a4a] cursor-pointer group flex"
                  >
                    <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#a6a6a6] via-[#828282] to-[#565656] group-hover:from-[#b8b8b8] group-hover:via-[#909090] group-hover:to-[#646464] px-9 sm:px-12 py-4 sm:py-5 flex items-center gap-4 transition-colors">
                      <span className="w-3 h-3 rounded-full bg-[#fde047] shadow-[0_0_12px_#fde047] animate-pulse shrink-0" />
                      <span className="font-chatopia text-2xl sm:text-4xl tracking-wider leading-none uppercase">
                        TRY WEB
                      </span>
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden="true"
                        className="transition-transform duration-200 group-hover:translate-x-1"
                      >
                        <line x1="5" y1="12" x2="19" y2="12" />
                        <polyline points="12 5 19 12 12 19" />
                      </svg>
                    </div>
                  </motion.button>
                </div>

                {/* 1:1 Square Telegram Button right next to TRY WEB */}
                <div className="filter drop-shadow-[0_14px_24px_rgba(0,0,0,0.85)] flex">
                  <motion.a
                    href="https://t.me/awesome_chatopians"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Open Chatopia Telegram Channel"
                    title="Telegram: @awesome_chatopians"
                    whileHover={{ scale: 1.07, y: -3, rotate: 2 }}
                    whileTap={{ scale: 0.95 }}
                    className="poly-square-btn aspect-square h-[58px] sm:h-[76px] p-[3px] bg-gradient-to-b from-[#e4e4e4] via-[#9e9e9e] to-[#4a4a4a] cursor-pointer group flex"
                  >
                    <div className="poly-square-btn vfx-shimmer w-full h-full bg-gradient-to-b from-[#a6a6a6] via-[#828282] to-[#565656] group-hover:from-[#b8b8b8] group-hover:via-[#909090] group-hover:to-[#646464] flex items-center justify-center transition-colors">
                      <svg
                        width="32"
                        height="32"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        aria-hidden="true"
                        className="w-7 h-7 sm:w-9 sm:h-9 text-white filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-transform duration-200 group-hover:scale-110 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                      >
                        <path d="M21.94 2.66a1.5 1.5 0 0 0-1.62-.24L2.43 9.77a1.42 1.42 0 0 0 .08 2.67l4.56 1.55 1.76 5.42a1.32 1.32 0 0 0 2.24.48l2.58-2.64 4.78 3.52a1.48 1.48 0 0 0 2.33-.92l2.68-15.65a1.5 1.5 0 0 0-.5-1.54ZM9.45 14.8l-.98 3.32-1.18-3.64 9.9-6.64-7.74 6.96Z" />
                      </svg>
                    </div>
                  </motion.a>
                </div>
              </motion.div>
            </motion.div>

            {/* Right Side: Chamfered 3D Player Window */}
            <motion.div
              style={{ y: rightAvatarY }}
              initial={{ opacity: 0, x: 48, scale: 0.94 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              transition={{
                type: 'spring',
                stiffness: 140,
                damping: 20,
                delay: 0.2,
              }}
              className="lg:col-span-5"
            >
              <CharacterViewport3D scrollProgressRef={scrollProgressRef} />
            </motion.div>
          </div>
        </section>

        {/* 2. MIDDLE SECTION: CREDITS / DEVELOPERS (TheMainChatter above glowing gold + Chickedream below) */}
        <motion.section
          id="credits"
          style={{ scale: creditsScale }}
          className="max-w-3xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.4 }}
            transition={{ type: 'spring', stiffness: 160, damping: 20 }}
            className="flex justify-center mb-10"
          >
            <div className="filter drop-shadow-[0_10px_14px_rgba(0,0,0,0.7)]">
              <div className="poly-inner-brand p-[2px] bg-gradient-to-b from-[#b8b8b8] to-[#4a4a4a]">
                <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#8e8e8e] to-[#5c5c5c] px-10 py-3">
                  <h2 className="font-chatopia text-2xl sm:text-4xl tracking-wider uppercase">
                    CREDITS
                  </h2>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-7">
            {/* 1st (Higher & Glowing Gold): TheMainChatter with root avatar on left */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ type: 'spring', stiffness: 150, damping: 20 }}
              whileHover={{ scale: 1.02, y: -3 }}
              className="vfx-gold-aura"
            >
              <div className="poly-section-plate p-[2.5px] bg-gradient-to-r from-[#fef08a] via-[#eab308] to-[#fef08a]">
                <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#54471c] via-[#382f14] to-[#211c0d] px-6 sm:px-9 py-5 sm:py-6 flex flex-col sm:flex-row items-center gap-6">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-yellow-300 shadow-[0_0_20px_rgba(250,204,21,0.65)] shrink-0 bg-black">
                    <img
                      src="/IMG_20261108_012259_125.jpg"
                      alt="TheMainChatter"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="text-center sm:text-left">
                    <h3 className="font-chatopia-gold text-3xl sm:text-5xl tracking-wider leading-none mb-2">
                      THEMAINCHATTER
                    </h3>
                    <p className="font-chatopia text-sm sm:text-lg tracking-wider opacity-90">
                      FOUNDER / LEAD DEVELOPER
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* 2nd (Below TheMainChatter): Chickedream (Clickable -> Opens Contact Menu) */}
            <motion.div
              role="button"
              tabIndex={0}
              aria-label="Open Chickedream Contact Menu"
              onClick={() => setIsContactOpen(true)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  setIsContactOpen(true);
                }
              }}
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{
                type: 'spring',
                stiffness: 150,
                damping: 20,
                delay: 0.08,
              }}
              whileHover={{ scale: 1.025, y: -4 }}
              whileTap={{ scale: 0.98 }}
              className="filter drop-shadow-[0_12px_18px_rgba(0,0,0,0.75)] cursor-pointer group"
            >
              <div className="poly-section-plate p-[2px] bg-gradient-to-b from-[#c8c8c8] to-[#484848] group-hover:from-[#ffffff] group-hover:to-[#666666] transition-colors">
                <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#848484] via-[#686868] to-[#4c4c4c] group-hover:from-[#949494] group-hover:via-[#747474] group-hover:to-[#565656] px-6 sm:px-9 py-5 flex flex-col sm:flex-row items-center justify-between gap-6 transition-colors">
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-[#9a9a9a] to-[#525252] border border-white/35 flex items-center justify-center shrink-0 shadow-md">
                      <span className="font-chatopia text-3xl sm:text-4xl">
                        C
                      </span>
                    </div>

                    <div className="text-center sm:text-left">
                      <h3 className="font-chatopia text-2xl sm:text-4xl tracking-wider leading-none mb-2">
                        CHICKEDREAM
                      </h3>
                      <p className="font-chatopia text-sm sm:text-lg tracking-wider opacity-90">
                        DEVELOPER / PLACE BUILDER
                      </p>
                    </div>
                  </div>

                  <div className="poly-inner-brand px-5 py-2 bg-gradient-to-b from-[#a6a6a6] to-[#585858] group-hover:from-[#bcbcbc] group-hover:to-[#6a6a6a] shrink-0 shadow">
                    <span className="font-chatopia text-sm sm:text-lg tracking-wider uppercase">
                      CONTACT
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.section>

        {/* 2.5. DOWNLOAD WIDGETS: ITCH.IO & GAME JOLT FRAMES */}
        <section id="downloads" className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: false, amount: 0.35 }}
            transition={{ type: 'spring', stiffness: 160, damping: 20 }}
            className="flex justify-center mb-10"
          >
            <div className="filter drop-shadow-[0_10px_14px_rgba(0,0,0,0.7)]">
              <div className="poly-inner-brand p-[2px] bg-gradient-to-b from-[#b8b8b8] to-[#4a4a4a]">
                <div className="poly-inner-brand vfx-shimmer bg-gradient-to-b from-[#8e8e8e] to-[#5c5c5c] px-8 sm:px-10 py-3">
                  <h2 className="font-chatopia text-2xl sm:text-4xl tracking-wider uppercase text-center">
                    DOWNLOAD CHATOPIA
                  </h2>
                </div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-8">
            {/* Itch.io Decorated Frame */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.25 }}
              transition={{ type: 'spring', stiffness: 150, damping: 20 }}
              whileHover={{ y: -4, scale: 1.01 }}
              className="filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.82)]"
            >
              <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#848484] to-[#3f3f3f]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8a8a8a] via-[#686868] to-[#464646] p-4 sm:p-6 space-y-4">
                  {/* Frame Header Bar */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#9c9c9c] via-[#7e7e7e] to-[#5c5c5c] px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#fa5c5c] shadow-[0_0_10px_#fa5c5c] shrink-0" />
                      <span className="font-chatopia text-lg sm:text-2xl tracking-wider uppercase">
                        ITCH.IO // ANDROID & CLIENT
                      </span>
                    </div>
                    <a
                      href="https://chickedream.itch.io/chatopia"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="poly-inner-brand vfx-shimmer px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5a5a5a] hover:from-[#bcbcbc] hover:to-[#6e6e6e] transition-transform active:scale-95"
                    >
                      <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                        OPEN ITCH.IO
                      </span>
                    </a>
                  </div>

                  {/* Centered Embed Container */}
                  <div className="rounded-2xl bg-gradient-to-b from-[#2b2b2b] to-[#171717] border-2 border-black/80 p-3 sm:p-5 flex justify-center items-center overflow-x-auto shadow-inner">
                    <iframe
                      frameBorder={0}
                      src="https://itch.io/embed/4650524"
                      width="552"
                      height="167"
                      title="ChatOpia — Android Roblox Revival by Chickedream on Itch.io"
                      className="max-w-full rounded-lg shadow-lg shrink-0"
                    >
                      <a href="https://chickedream.itch.io/chatopia">
                        ChatOpia — Android Roblox Revival by Chickedream
                      </a>
                    </iframe>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Game Jolt Decorated Frame */}
            <motion.div
              initial={{ opacity: 0, y: 36, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: false, amount: 0.25 }}
              transition={{
                type: 'spring',
                stiffness: 150,
                damping: 20,
                delay: 0.08,
              }}
              whileHover={{ y: -4, scale: 1.01 }}
              className="filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.82)]"
            >
              <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#848484] to-[#3f3f3f]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8a8a8a] via-[#686868] to-[#464646] p-4 sm:p-6 space-y-4">
                  {/* Frame Header Bar */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#9c9c9c] via-[#7e7e7e] to-[#5c5c5c] px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#ccff00] shadow-[0_0_10px_#ccff00] shrink-0" />
                      <span className="font-chatopia text-lg sm:text-2xl tracking-wider uppercase">
                        GAME JOLT // OFFICIAL PACKAGE
                      </span>
                    </div>
                    <a
                      href="https://gamejolt.com/games/Chatopiarevival/1075649"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="poly-inner-brand vfx-shimmer px-4 py-1.5 bg-gradient-to-b from-[#a8a8a8] to-[#5a5a5a] hover:from-[#bcbcbc] hover:to-[#6e6e6e] transition-transform active:scale-95"
                    >
                      <span className="font-chatopia text-xs sm:text-sm tracking-wider uppercase">
                        OPEN GAME JOLT
                      </span>
                    </a>
                  </div>

                  {/* Centered Embed Container */}
                  <div className="rounded-2xl bg-gradient-to-b from-[#2b2b2b] to-[#171717] border-2 border-black/80 p-3 sm:p-5 flex justify-center items-center overflow-x-auto shadow-inner">
                    <iframe
                      src="https://widgets.gamejolt.com/package/v1?key=QD9DCGpX"
                      frameBorder={0}
                      width="500"
                      height="245"
                      title="ChatOpia Game Jolt Package"
                      className="max-w-full rounded-lg shadow-lg shrink-0"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* 3. IN-GAME SCREENSHOTS IN SIGNATURE CHATOPIA FRAMES (The Chatting Zone & SFOTH) */}
        <section id="places" className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10">
            {FEATURED_SCREENS.map((item, idx) => (
              <motion.article
                key={item.id}
                role="button"
                tabIndex={0}
                aria-label={`Open ${item.title}`}
                onClick={() => setPreviewScreen(item)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setPreviewScreen(item);
                  }
                }}
                initial={{ opacity: 0, y: 44, scale: 0.94 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: false, amount: 0.25 }}
                transition={{
                  type: 'spring',
                  stiffness: 145,
                  damping: 20,
                  delay: idx * 0.12,
                }}
                whileHover={{ y: -6, scale: 1.015 }}
                whileTap={{ scale: 0.985 }}
                className="group filter drop-shadow-[0_18px_32px_rgba(0,0,0,0.85)] cursor-pointer"
              >
                <div className="poly-window-shell p-[2.5px] bg-gradient-to-b from-[#d0d0d0] via-[#848484] to-[#3c3c3c] group-hover:from-[#ffffff] group-hover:via-[#9a9a9a] group-hover:to-[#4f4f4f] transition-colors">
                  <div className="poly-window-shell vfx-shimmer bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#444444] p-4 sm:p-5 space-y-4">
                    {/* Top Signature Place Header */}
                    <div className="poly-top-bar bg-gradient-to-b from-[#9e9e9e] via-[#808080] to-[#5e5e5e] px-4 sm:px-5 py-2 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#fde047] shadow-[0_0_8px_#fde047] shrink-0" />
                        <span className="font-chatopia text-base sm:text-xl tracking-wider uppercase truncate">
                          {item.title}
                        </span>
                      </div>
                      <span className="font-chatopia text-xs tracking-wider opacity-80 uppercase shrink-0">
                        PLACE
                      </span>
                    </div>

                    {/* Rounded Inner Screenshot Frame */}
                    <div className="aspect-[16/10] w-full rounded-2xl overflow-hidden border-2 border-black/85 bg-black shadow-inner">
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>

                    {/* Bottom Author Plate */}
                    <div className="flex justify-center pt-0.5">
                      <div className="poly-inner-brand px-6 py-2 bg-gradient-to-b from-[#989898] via-[#767676] to-[#525252] shadow-md">
                        <p className="font-chatopia text-sm sm:text-lg tracking-wider uppercase">
                          {item.author}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </section>
      </main>

      {/* BOTTOM LEGAL FOOTER: Signature Chamfered Frame, White OldRobloxFont on Black */}
      <footer className="relative z-20 w-full px-4 sm:px-8 pb-10 sm:pb-14">
        <motion.div
          initial={{ opacity: 0, y: 28, scale: 0.96 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ type: 'spring', stiffness: 150, damping: 22 }}
          className="max-w-4xl mx-auto filter drop-shadow-[0_16px_28px_rgba(0,0,0,0.9)]"
        >
          <div className="poly-section-plate p-[2.5px] bg-gradient-to-b from-[#cccccc] via-[#808080] to-[#3b3b3b]">
            <div className="poly-section-plate vfx-shimmer bg-gradient-to-b from-[#141414] via-[#080808] to-[#000000] px-6 sm:px-12 py-7 sm:py-9 text-center space-y-3">
              <p className="font-chatopia text-sm sm:text-lg md:text-xl tracking-wider leading-relaxed">
                &copy; 2020&ndash;2026 ChatOPIA Revivals LLC. All rights
                reserved.
              </p>
              <p className="font-chatopia text-xs sm:text-base tracking-wider leading-relaxed opacity-90">
                All third-party trademarks, logos, and brand names are the
                property of their respective owners.
              </p>
            </div>
          </div>
        </motion.div>
      </footer>

      {/* DRAGGABLE WEB VIEW WINDOW (chatopia-game.pages.dev) */}
      <DraggableWebViewWindow
        isOpen={isWebViewOpen}
        isMinimized={isWebViewMinimized}
        onMinimizeChange={setIsWebViewMinimized}
        onClose={() => {
          setIsWebViewOpen(false);
          setIsWebViewMinimized(false);
        }}
        url="https://chatopia-game.pages.dev"
      />

      {/* CHICKEDREAM CONTACT MENU MODAL */}
      <AnimatePresence>
        {isContactOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Contact Chickedream"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setIsContactOpen(false)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.92, y: 24, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.92, y: 24, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 240, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-2xl w-full filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.92)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#3d3d3d]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-5 sm:p-7 space-y-5 max-h-[88vh] overflow-y-auto">
                  {/* Modal Header */}
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-[#9c9c9c] to-[#525252] border border-white/40 flex items-center justify-center shrink-0">
                        <span className="font-chatopia text-2xl leading-none">
                          C
                        </span>
                      </div>
                      <div>
                        <h3 className="font-chatopia text-xl sm:text-3xl tracking-wider uppercase leading-none">
                          CONTACT // CHICKEDREAM
                        </h3>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsContactOpen(false)}
                      className="poly-inner-brand px-4 sm:px-5 py-2 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <span className="font-chatopia text-sm sm:text-base tracking-wider">
                        CLOSE
                      </span>
                    </button>
                  </div>

                  {/* Contact Items Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
                    {/* TikTok (2 accounts) */}
                    <div className="sm:col-span-2 rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          TIKTOK (2 ACCOUNTS)
                        </span>
                        <div className="flex flex-wrap items-center gap-3 mt-1">
                          <a
                            href="https://www.tiktok.com/@chickedream"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline"
                          >
                            @chickedream
                          </a>
                          <span className="font-chatopia text-lg opacity-60">
                            /
                          </span>
                          <a
                            href="https://www.tiktok.com/@chickedream_fdt"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline"
                          >
                            @chickedream_fdt
                          </a>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyText('@chickedream', 'tiktok1')
                          }
                          className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'tiktok1' ? 'COPIED' : 'COPY #1'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyText('@chickedream_fdt', 'tiktok2')
                          }
                          className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer"
                        >
                          <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                            {copiedLabel === 'tiktok2' ? 'COPIED' : 'COPY #2'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Telegram */}
                    <div className="rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          TELEGRAM
                        </span>
                        <a
                          href="https://t.me/chickedream"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                        >
                          @chickedream
                        </a>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyText('@chickedream', 'tg')}
                        className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                          {copiedLabel === 'tg' ? 'COPIED' : 'COPY'}
                        </span>
                      </button>
                    </div>

                    {/* YouTube */}
                    <div className="rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          YOUTUBE
                        </span>
                        <a
                          href="https://www.youtube.com/@chickedream"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                        >
                          @chickedream
                        </a>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopyText('@chickedream', 'yt')}
                        className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                          {copiedLabel === 'yt' ? 'COPIED' : 'COPY'}
                        </span>
                      </button>
                    </div>

                    {/* Email */}
                    <div className="sm:col-span-2 rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          EMAIL
                        </span>
                        <a
                          href="mailto:chickedream@gmail.com"
                          className="font-chatopia text-lg sm:text-2xl tracking-wider hover:underline block truncate mt-0.5"
                        >
                          chickedream@gmail.com
                        </a>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          handleCopyText('chickedream@gmail.com', 'email')
                        }
                        className="poly-inner-brand px-4 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0 self-start sm:self-center"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                          {copiedLabel === 'email' ? 'COPIED' : 'COPY EMAIL'}
                        </span>
                      </button>
                    </div>

                    {/* Roblox */}
                    <div className="rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          ROBLOX
                        </span>
                        <span className="font-chatopia text-lg sm:text-2xl tracking-wider block truncate mt-0.5">
                          @4effrey_d4hm9r
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          handleCopyText('4effrey_d4hm9r', 'roblox')
                        }
                        className="poly-inner-brand px-3.5 py-1.5 bg-gradient-to-b from-[#989898] to-[#565656] hover:from-[#b0b0b0] hover:to-[#686868] cursor-pointer shrink-0"
                      >
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider">
                          {copiedLabel === 'roblox' ? 'COPIED' : 'COPY'}
                        </span>
                      </button>
                    </div>

                    {/* Country */}
                    <div className="rounded-2xl bg-gradient-to-b from-[#5e5e5e] to-[#3b3b3b] border border-white/25 p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <span className="font-chatopia text-xs sm:text-sm tracking-wider opacity-80 uppercase block">
                          COUNTRY / СТРАНА
                        </span>
                        <span className="font-chatopia text-lg sm:text-2xl tracking-wider block truncate mt-0.5">
                          UKRAINE (УКРАИНА)
                        </span>
                      </div>
                      <svg
                        width="28"
                        height="20"
                        viewBox="0 0 28 20"
                        aria-hidden="true"
                        className="rounded-sm border border-white/40 shrink-0 shadow"
                      >
                        <rect width="28" height="10" y="0" fill="#0057B7" />
                        <rect width="28" height="10" y="10" fill="#FFD700" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* FULLSCREEN SCREENSHOT MODAL */}
      <AnimatePresence>
        {previewScreen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={previewScreen.title}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={() => setPreviewScreen(null)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/85"
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-4xl w-full filter drop-shadow-[0_24px_48px_rgba(0,0,0,0.92)]"
            >
              <div className="poly-window-shell p-[3px] bg-gradient-to-b from-[#d8d8d8] via-[#8c8c8c] to-[#3d3d3d]">
                <div className="poly-window-shell bg-gradient-to-b from-[#8c8c8c] via-[#686868] to-[#424242] p-4 sm:p-6 space-y-4">
                  <div className="poly-top-bar bg-gradient-to-b from-[#a2a2a2] via-[#848484] to-[#606060] px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <h3 className="font-chatopia text-xl sm:text-3xl uppercase truncate">
                        {previewScreen.title}
                      </h3>
                      <p className="font-chatopia text-xs sm:text-sm tracking-wider opacity-85">
                        {previewScreen.author}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setPreviewScreen(null)}
                      className="poly-inner-brand px-4 sm:px-5 py-2 bg-gradient-to-b from-[#a44c4c] to-[#632424] hover:from-[#c05858] hover:to-[#7a2c2c] cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <span className="font-chatopia text-sm sm:text-base">
                        CLOSE
                      </span>
                    </button>
                  </div>

                  <div className="rounded-2xl overflow-hidden border-2 border-black bg-black">
                    <img
                      src={previewScreen.imageUrl}
                      alt={previewScreen.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-auto max-h-[74vh] object-contain mx-auto"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
