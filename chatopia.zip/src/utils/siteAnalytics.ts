import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import type { FontMode, SiteLang } from '../i18n';

export type AnalyticsEventType =
  | 'page_view'
  | 'try_web'
  | 'info_open'
  | 'contact_open'
  | 'discord_click'
  | 'telegram_click'
  | 'itch_click'
  | 'gamejolt_click'
  | 'place_preview'
  | 'lang_switch'
  | 'font_switch';

export type DeviceCategory = 'desktop' | 'mobile' | 'tablet';

export interface ActiveSessionRecord {
  sessionId: string;
  visitorId: string;
  dateKey: string;
  lang: SiteLang;
  fontMode: FontMode;
  deviceType: DeviceCategory;
  viewport: string;
  referrerHost: string;
  durationSec: number;
  actionsCount: number;
  startedAtMs: number;
  lastSeenAtMs: number;
}

export interface ActivityEventRecord {
  id: string;
  sessionId: string;
  eventType: AnalyticsEventType;
  target: string;
  lang: SiteLang;
  fontMode: FontMode;
  deviceType: DeviceCategory;
  viewport: string;
  referrerHost: string;
  dateKey: string;
  createdAtMs: number;
}

export interface HourlyBucket {
  hourLabel: string;
  visits: number;
  actions: number;
}

export interface AnalyticsSnapshotSummary {
  onlineNow: number;
  totalVisits: number;
  todayVisits: number;
  uniqueVisitors: number;
  todayUniqueVisitors: number;
  totalSessions: number;
  avgDurationSec: number;
  maxDurationSec: number;
  engagementRatePct: number;
  totalActions: number;
  eventCounts: Record<AnalyticsEventType, number>;
  placeCounts: Record<string, number>;
  langCounts: Record<SiteLang, number>;
  fontCounts: Record<FontMode, number>;
  deviceCounts: Record<DeviceCategory, number>;
  topReferrers: Array<{ name: string; count: number }>;
  topViewports: Array<{ name: string; count: number }>;
  hourlyTimeline: HourlyBucket[];
  recentSessions: ActiveSessionRecord[];
  recentEvents: ActivityEventRecord[];
}

const VISITOR_STORAGE_KEY = 'chatopia_visitor_id_v1';
const HEARTBEAT_INTERVAL_MS = 45000;
const ONLINE_WINDOW_MS = 120000;

function randomId(prefix: string): string {
  const bytes = new Uint8Array(12);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
  return `${prefix}_${hex}`.slice(0, 64);
}

function getOrCreateVisitorId(): string {
  try {
    const existing = localStorage.getItem(VISITOR_STORAGE_KEY);
    if (
      existing &&
      existing.length >= 8 &&
      existing.length <= 64 &&
      /^[a-zA-Z0-9_-]+$/.test(existing)
    ) {
      return existing;
    }
    const created = randomId('vis');
    localStorage.setItem(VISITOR_STORAGE_KEY, created);
    return created;
  } catch {
    return randomId('vis');
  }
}

function getUtcDateKey(date = new Date()): string {
  return date.toISOString().slice(0, 10);
}

function detectDeviceType(): DeviceCategory {
  if (typeof window === 'undefined') return 'desktop';
  const width = window.innerWidth;
  const ua = (navigator.userAgent || '').toLowerCase();
  if (/ipad|tablet|playbook|silk/.test(ua) || (width >= 640 && width < 1024 && 'ontouchstart' in window)) {
    return 'tablet';
  }
  if (
    /mobi|android|iphone|ipod|blackberry|iemobile|opera mini/.test(ua) ||
    width < 640
  ) {
    return 'mobile';
  }
  return 'desktop';
}

function getViewportString(): string {
  if (typeof window === 'undefined') return '0x0';
  return `${Math.max(0, Math.round(window.innerWidth))}x${Math.max(0, Math.round(window.innerHeight))}`.slice(0, 24);
}

function getSanitizedReferrer(): string {
  if (typeof document === 'undefined' || !document.referrer) return 'direct';
  try {
    const url = new URL(document.referrer);
    const host = url.hostname.trim().toLowerCase();
    if (!host || host === window.location.hostname.toLowerCase()) {
      return 'direct';
    }
    return host.slice(0, 100);
  } catch {
    return 'direct';
  }
}

class SiteAnalyticsClient {
  private sessionId: string | null = null;
  private visitorId: string | null = null;
  private dateKey = getUtcDateKey();
  private deviceType: DeviceCategory = 'desktop';
  private referrerHost = 'direct';
  private startedAtEpoch = Date.now();
  private actionsCount = 0;
  private currentLang: SiteLang = 'en';
  private currentFont: FontMode = 'oldroblox';
  private sessionCreated = false;
  private heartbeatTimer: number | null = null;
  private isStarted = false;

  start(initialLang: SiteLang, initialFont: FontMode): () => void {
    if (this.isStarted) {
      this.currentLang = initialLang;
      this.currentFont = initialFont;
      return () => {};
    }
    this.isStarted = true;
    this.currentLang = initialLang;
    this.currentFont = initialFont;
    this.sessionId = randomId('sess');
    this.visitorId = getOrCreateVisitorId();
    this.dateKey = getUtcDateKey();
    this.deviceType = detectDeviceType();
    this.referrerHost = getSanitizedReferrer();
    this.startedAtEpoch = Date.now();
    this.actionsCount = 0;

    void this.initSessionAndPageView();

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        void this.sendHeartbeat();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    this.heartbeatTimer = window.setInterval(() => {
      if (document.visibilityState === 'visible') {
        void this.sendHeartbeat();
      }
    }, HEARTBEAT_INTERVAL_MS);

    return () => {
      if (this.heartbeatTimer !== null) {
        window.clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
      }
      document.removeEventListener('visibilitychange', onVisibilityChange);
      this.isStarted = false;
    };
  }

  updatePreferences(lang: SiteLang, fontMode: FontMode) {
    this.currentLang = lang;
    this.currentFont = fontMode;
  }

  private async initSessionAndPageView() {
    if (!this.sessionId || !this.visitorId) return;
    const sessionPath = `active_sessions/${this.sessionId}`;
    try {
      await setDoc(doc(db, 'active_sessions', this.sessionId), {
        sessionId: this.sessionId,
        visitorId: this.visitorId,
        dateKey: this.dateKey,
        lang: this.currentLang,
        fontMode: this.currentFont,
        deviceType: this.deviceType,
        viewport: getViewportString(),
        referrerHost: this.referrerHost,
        durationSec: 0,
        actionsCount: 0,
        startedAt: serverTimestamp(),
        lastSeenAt: serverTimestamp(),
      });
      this.sessionCreated = true;
    } catch (error) {
      try {
        handleFirestoreError(error, OperationType.CREATE, sessionPath);
      } catch {
        // Logged via handleFirestoreError; avoid breaking visitor UI
      }
    }

    await this.writeEvent('page_view', 'landing');
  }

  private async sendHeartbeat() {
    if (!this.sessionId || !this.sessionCreated) return;
    const elapsedSec = Math.min(
      86400,
      Math.max(0, Math.round((Date.now() - this.startedAtEpoch) / 1000))
    );
    const sessionPath = `active_sessions/${this.sessionId}`;
    try {
      await updateDoc(doc(db, 'active_sessions', this.sessionId), {
        lang: this.currentLang,
        fontMode: this.currentFont,
        viewport: getViewportString(),
        durationSec: elapsedSec,
        actionsCount: Math.min(10000, this.actionsCount),
        lastSeenAt: serverTimestamp(),
      });
    } catch (error) {
      try {
        handleFirestoreError(error, OperationType.UPDATE, sessionPath);
      } catch {
        // Logged via handleFirestoreError
      }
    }
  }

  track(eventType: AnalyticsEventType, target = '') {
    if (!this.sessionId) return;
    if (eventType !== 'page_view') {
      this.actionsCount = Math.min(10000, this.actionsCount + 1);
    }
    void this.writeEvent(eventType, target);
    if (this.sessionCreated) {
      void this.sendHeartbeat();
    }
  }

  private async writeEvent(eventType: AnalyticsEventType, target: string) {
    if (!this.sessionId) return;
    const eventId = randomId('evt');
    const eventPath = `activity_events/${eventId}`;
    const safeTarget = target.trim().slice(0, 64);
    try {
      await setDoc(doc(db, 'activity_events', eventId), {
        sessionId: this.sessionId,
        eventType,
        target: safeTarget,
        lang: this.currentLang,
        fontMode: this.currentFont,
        deviceType: this.deviceType,
        viewport: getViewportString(),
        referrerHost: this.referrerHost,
        dateKey: getUtcDateKey(),
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      try {
        handleFirestoreError(error, OperationType.CREATE, eventPath);
      } catch {
        // Logged via handleFirestoreError
      }
    }
  }
}

export const siteAnalytics = new SiteAnalyticsClient();

function toMillis(val: unknown): number {
  if (val instanceof Timestamp) return val.toMillis();
  if (val && typeof val === 'object' && 'toMillis' in val && typeof (val as { toMillis: unknown }).toMillis === 'function') {
    return (val as { toMillis: () => number }).toMillis();
  }
  return Date.now();
}

export function subscribeToOwnerAnalytics(
  onUpdate: (summary: AnalyticsSnapshotSummary) => void,
  onError: (err: unknown) => void
): () => void {
  let sessions: ActiveSessionRecord[] = [];
  let events: ActivityEventRecord[] = [];
  let sessionsReady = false;
  let eventsReady = false;

  const emit = () => {
    if (!sessionsReady && !eventsReady) return;
    const now = Date.now();
    const todayKey = getUtcDateKey(new Date(now));

    const onlineNow = sessions.filter(
      (s) => now - s.lastSeenAtMs <= ONLINE_WINDOW_MS
    ).length;

    const uniqueVisitorSet = new Set<string>();
    const todayVisitorSet = new Set<string>();
    let todaySessions = 0;
    let durationSum = 0;
    let maxDurationSec = 0;
    let engagedSessions = 0;

    const langCounts: Record<SiteLang, number> = { en: 0, ru: 0 };
    const fontCounts: Record<FontMode, number> = { oldroblox: 0, boblox: 0 };
    const deviceCounts: Record<DeviceCategory, number> = {
      desktop: 0,
      mobile: 0,
      tablet: 0,
    };
    const referrerMap = new Map<string, number>();
    const viewportMap = new Map<string, number>();

    for (const s of sessions) {
      uniqueVisitorSet.add(s.visitorId);
      if (s.dateKey === todayKey) {
        todaySessions++;
        todayVisitorSet.add(s.visitorId);
      }
      durationSum += s.durationSec;
      if (s.durationSec > maxDurationSec) maxDurationSec = s.durationSec;
      if (s.actionsCount > 0 || s.durationSec >= 15) engagedSessions++;

      langCounts[s.lang] = (langCounts[s.lang] || 0) + 1;
      fontCounts[s.fontMode] = (fontCounts[s.fontMode] || 0) + 1;
      deviceCounts[s.deviceType] = (deviceCounts[s.deviceType] || 0) + 1;

      const refName = s.referrerHost || 'direct';
      referrerMap.set(refName, (referrerMap.get(refName) || 0) + 1);
      if (s.viewport) {
        viewportMap.set(s.viewport, (viewportMap.get(s.viewport) || 0) + 1);
      }
    }

    const eventCounts: Record<AnalyticsEventType, number> = {
      page_view: 0,
      try_web: 0,
      info_open: 0,
      contact_open: 0,
      discord_click: 0,
      telegram_click: 0,
      itch_click: 0,
      gamejolt_click: 0,
      place_preview: 0,
      lang_switch: 0,
      font_switch: 0,
    };
    const placeCounts: Record<string, number> = {};
    let todayPageViews = 0;

    // 12 two-hour buckets across the last 24h
    const hourlyBuckets: HourlyBucket[] = [];
    const twoHoursMs = 2 * 60 * 60 * 1000;
    const currentBucketStart = Math.floor(now / twoHoursMs) * twoHoursMs;
    const bucketIndexMap = new Map<number, number>();
    for (let i = 11; i >= 0; i--) {
      const start = currentBucketStart - i * twoHoursMs;
      const d = new Date(start);
      const label = `${String(d.getHours()).padStart(2, '0')}:00`;
      bucketIndexMap.set(start, hourlyBuckets.length);
      hourlyBuckets.push({ hourLabel: label, visits: 0, actions: 0 });
    }

    let totalActions = 0;
    for (const ev of events) {
      eventCounts[ev.eventType] = (eventCounts[ev.eventType] || 0) + 1;
      if (ev.eventType === 'page_view') {
        if (ev.dateKey === todayKey) todayPageViews++;
      } else {
        totalActions++;
      }
      if (ev.eventType === 'place_preview' && ev.target) {
        placeCounts[ev.target] = (placeCounts[ev.target] || 0) + 1;
      }
      const bucketStart = Math.floor(ev.createdAtMs / twoHoursMs) * twoHoursMs;
      const bIdx = bucketIndexMap.get(bucketStart);
      if (bIdx !== undefined) {
        if (ev.eventType === 'page_view') {
          hourlyBuckets[bIdx].visits++;
        } else {
          hourlyBuckets[bIdx].actions++;
        }
      }
    }

    const topReferrers = Array.from(referrerMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);

    const topViewports = Array.from(viewportMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 6);

    const totalSessions = sessions.length;
    const avgDurationSec =
      totalSessions > 0 ? Math.round(durationSum / totalSessions) : 0;
    const engagementRatePct =
      totalSessions > 0
        ? Math.round((engagedSessions / totalSessions) * 100)
        : 0;

    onUpdate({
      onlineNow,
      totalVisits: Math.max(eventCounts.page_view, totalSessions),
      todayVisits: Math.max(todayPageViews, todaySessions),
      uniqueVisitors: uniqueVisitorSet.size,
      todayUniqueVisitors: todayVisitorSet.size,
      totalSessions,
      avgDurationSec,
      maxDurationSec,
      engagementRatePct,
      totalActions,
      eventCounts,
      placeCounts,
      langCounts,
      fontCounts,
      deviceCounts,
      topReferrers,
      topViewports,
      hourlyTimeline: hourlyBuckets,
      recentSessions: sessions.slice(0, 40),
      recentEvents: events.slice(0, 60),
    });
  };

  const sessionsQuery = query(
    collection(db, 'active_sessions'),
    orderBy('lastSeenAt', 'desc'),
    limit(300)
  );

  const eventsQuery = query(
    collection(db, 'activity_events'),
    orderBy('createdAt', 'desc'),
    limit(600)
  );

  const unsubSessions = onSnapshot(
    sessionsQuery,
    (snap) => {
      sessions = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          sessionId: String(d.sessionId || docSnap.id),
          visitorId: String(d.visitorId || ''),
          dateKey: String(d.dateKey || ''),
          lang: d.lang === 'ru' ? 'ru' : 'en',
          fontMode: d.fontMode === 'boblox' ? 'boblox' : 'oldroblox',
          deviceType:
            d.deviceType === 'mobile' || d.deviceType === 'tablet'
              ? d.deviceType
              : 'desktop',
          viewport: String(d.viewport || ''),
          referrerHost: String(d.referrerHost || 'direct'),
          durationSec: Number(d.durationSec || 0),
          actionsCount: Number(d.actionsCount || 0),
          startedAtMs: toMillis(d.startedAt),
          lastSeenAtMs: toMillis(d.lastSeenAt),
        };
      });
      sessionsReady = true;
      emit();
    },
    (err) => {
      try {
        handleFirestoreError(err, OperationType.LIST, 'active_sessions');
      } catch (wrapped) {
        onError(wrapped);
      }
    }
  );

  const unsubEvents = onSnapshot(
    eventsQuery,
    (snap) => {
      events = snap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          sessionId: String(d.sessionId || ''),
          eventType: (d.eventType || 'page_view') as AnalyticsEventType,
          target: String(d.target || ''),
          lang: d.lang === 'ru' ? 'ru' : 'en',
          fontMode: d.fontMode === 'boblox' ? 'boblox' : 'oldroblox',
          deviceType:
            d.deviceType === 'mobile' || d.deviceType === 'tablet'
              ? d.deviceType
              : 'desktop',
          viewport: String(d.viewport || ''),
          referrerHost: String(d.referrerHost || 'direct'),
          dateKey: String(d.dateKey || ''),
          createdAtMs: toMillis(d.createdAt),
        };
      });
      eventsReady = true;
      emit();
    },
    (err) => {
      try {
        handleFirestoreError(err, OperationType.LIST, 'activity_events');
      } catch (wrapped) {
        onError(wrapped);
      }
    }
  );

  return () => {
    unsubSessions();
    unsubEvents();
  };
}
