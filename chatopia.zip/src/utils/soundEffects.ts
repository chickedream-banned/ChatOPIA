// Zero-latency Web Audio + HTMLAudio fallback SFX controller for Chatopia
const BUTTON_SFX_URL = '/button (1).wav';
const SPLAT_SFX_URL = '/splat.wav';

const INTERACTIVE_OR_PLATE_SELECTOR = [
  'button',
  'a',
  '[role="button"]',
  '.poly-top-bar',
  '.poly-inner-brand',
  '.poly-nostalgia-banner',
  '.poly-desc-box',
  '.poly-avatar-box',
  '.poly-section-plate',
  '.poly-window-shell',
  '.poly-square-btn',
  'article',
].join(', ');

export class SoundEffectsController {
  private ctx: AudioContext | null = null;
  private buttonBuffer: AudioBuffer | null = null;
  private splatBuffer: AudioBuffer | null = null;
  private loadingStarted = false;
  private disposed = false;
  private readonly events = new AbortController();

  constructor() {
    window.addEventListener('pointerdown', this.handleGlobalPointerDown, {
      signal: this.events.signal,
      capture: true,
    });
  }

  private ensureContext(): AudioContext | null {
    if (this.disposed) return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    if (this.ctx && !this.loadingStarted) {
      this.loadingStarted = true;
      this.loadBuffer(BUTTON_SFX_URL).then((buf) => {
        if (!this.disposed) this.buttonBuffer = buf;
      });
      this.loadBuffer(SPLAT_SFX_URL).then((buf) => {
        if (!this.disposed) this.splatBuffer = buf;
      });
    }
    return this.ctx;
  }

  private async loadBuffer(url: string): Promise<AudioBuffer | null> {
    try {
      if (!this.ctx) return null;
      const response = await fetch(encodeURI(url));
      if (!response.ok) return null;
      const arrayBuffer = await response.arrayBuffer();
      if (this.disposed || !this.ctx) return null;
      return await this.ctx.decodeAudioData(arrayBuffer);
    } catch {
      return null;
    }
  }

  private playSound(kind: 'button' | 'splat'): void {
    if (this.disposed) return;
    const ctx = this.ensureContext();
    const buffer = kind === 'button' ? this.buttonBuffer : this.splatBuffer;

    if (ctx && buffer) {
      try {
        const source = ctx.createBufferSource();
        const gain = ctx.createGain();
        gain.gain.value = kind === 'button' ? 0.42 : 0.4;
        source.buffer = buffer;
        source.connect(gain);
        gain.connect(ctx.destination);
        source.start(0);
        return;
      } catch {
        // Fallback to HTMLAudioElement below
      }
    }

    // Immediate fallback while AudioBuffer is decoding on the very first click
    try {
      const audio = new Audio(
        encodeURI(kind === 'button' ? BUTTON_SFX_URL : SPLAT_SFX_URL)
      );
      audio.volume = kind === 'button' ? 0.42 : 0.4;
      audio.play().catch(() => {});
    } catch {
      // Ignore audio errors if blocked by browser policy
    }
  }

  private handleGlobalPointerDown = (e: PointerEvent): void => {
    if (this.disposed) return;
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    const target = e.target as Element | null;
    if (target && target.closest(INTERACTIVE_OR_PLATE_SELECTOR)) {
      this.playSound('button');
    } else {
      this.playSound('splat');
    }
  };

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.events.abort();
    this.buttonBuffer = null;
    this.splatBuffer = null;
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}
